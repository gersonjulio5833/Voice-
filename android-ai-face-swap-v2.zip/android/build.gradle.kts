// Configuração raiz do projeto AI Face Live.
// As versões dos plugins ficam aqui; o módulo :app aplica-os.
plugins {
    id("com.android.application") version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.2.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.21" apply false
}
