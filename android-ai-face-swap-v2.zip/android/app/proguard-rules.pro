# Regras adicionais do ProGuard/R8 (o release não usa minificação por defeito).
# MediaPipe e CameraX trazem as suas próprias regras de consumo.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
