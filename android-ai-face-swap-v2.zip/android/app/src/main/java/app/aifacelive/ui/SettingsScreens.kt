package app.aifacelive.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.aifacelive.AppViewModel
import app.aifacelive.settings.Acceleration
import app.aifacelive.settings.Lens
import app.aifacelive.settings.Quality
import app.aifacelive.util.CheckResult
import app.aifacelive.util.CheckStatus
import app.aifacelive.util.Compatibility
import app.aifacelive.util.hasCameraPermission
import app.aifacelive.util.openAppSettings

@Composable
fun SettingsScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onCompatibility: () -> Unit,
) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val camera = rememberCameraPermission()

    Column(modifier = Modifier.fillMaxSize().navigationBarsPadding()) {
        AppTopBar(title = "Definições", onBack = onBack)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
        ) {
            SectionLabel("Permissões")
            AppCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CameraAlt, contentDescription = null, tint = AiSecondary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Câmara", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (camera.granted) "Concedida" else "Não concedida",
                            color = if (camera.granted) AiSuccess else AiWarning,
                            fontSize = 12.sp,
                        )
                    }
                    if (!camera.granted) {
                        GhostButton("Conceder", onClick = camera.request)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Galeria: o seletor do Android dá acesso apenas à foto escolhida, sem permissão extra.",
                    color = AiTextMuted,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                )
                Spacer(Modifier.height(12.dp))
                GhostButton("Abrir definições do Android", onClick = { context.openAppSettings() }, modifier = Modifier.fillMaxWidth())
            }

            SectionLabel("Câmara")
            AppCard {
                Lens.entries.forEach { lens ->
                    OptionRow(
                        title = if (lens == Lens.FRONT) "Câmara frontal" else "Câmara traseira",
                        subtitle = if (lens == Lens.FRONT) "Recomendada para chamadas e selfies" else "Usa a câmara principal",
                        selected = settings.lens == lens,
                        onClick = { vm.updateSettings { it.copy(lens = lens) } },
                    )
                }
            }

            SectionLabel("Qualidade de processamento")
            AppCard {
                Quality.entries.forEach { quality ->
                    OptionRow(
                        title = quality.label,
                        subtitle = quality.hint,
                        selected = settings.quality == quality,
                        onClick = { vm.updateSettings { it.copy(quality = quality) } },
                    )
                }
            }

            SectionLabel("Desempenho")
            AppCard {
                Acceleration.entries.forEach { acc ->
                    OptionRow(
                        title = acc.label,
                        subtitle = acc.hint,
                        selected = settings.acceleration == acc,
                        onClick = { vm.updateSettings { it.copy(acceleration = acc) } },
                    )
                }
                Spacer(Modifier.height(8.dp))
                ToggleRow(
                    title = "Painel de expressões",
                    subtitle = "Mostra boca, olhos, sorriso e sobrancelhas em tempo real",
                    checked = settings.showHud,
                    onChange = { vm.updateSettings { s -> s.copy(showHud = it) } },
                )
                ToggleRow(
                    title = "Espelhar pré-visualização",
                    subtitle = "Como num espelho. Não afeta a imagem guardada no sistema.",
                    checked = settings.mirror,
                    onChange = { vm.updateSettings { s -> s.copy(mirror = it) } },
                )
            }

            SectionLabel("Compatibilidade")
            AppCard {
                Text(
                    "Verifica OpenGL, câmaras, memória e se o modelo de rosto carrega neste telemóvel.",
                    color = AiTextMuted,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                )
                Spacer(Modifier.height(12.dp))
                GradientButton("Verificar compatibilidade", onClick = onCompatibility, modifier = Modifier.fillMaxWidth(), icon = Icons.Filled.Refresh)
            }

            SectionLabel("Sobre")
            AppCard {
                Text("AI Face Live · versão 1.0.0", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "• Sem root, sem desbloqueio de bootloader e sem formatação.\n" +
                        "• Nada é enviado para a internet: o processamento é local.\n" +
                        "• Não é possível substituir a câmara do WhatsApp ou do Messenger sem root. Os snapshots podem ser partilhados por qualquer app.\n" +
                        "• Usa apenas imagens de pessoas que autorizaram a utilização.",
                    color = AiTextMuted,
                    fontSize = 12.sp,
                    lineHeight = 18.sp,
                )
            }
        }
    }
}

@Composable
fun CompatibilityScreen(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val results by vm.compatResults.collectAsStateWithLifecycle()
    val running by vm.compatRunning.collectAsStateWithLifecycle()
    val deviceRows = remember { Compatibility.deviceRows(context) }
    val hasCamera = context.hasCameraPermission()

    Column(modifier = Modifier.fillMaxSize().navigationBarsPadding()) {
        AppTopBar(title = "Compatibilidade", onBack = onBack)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
        ) {
            SectionLabel("Aparelho")
            AppCard {
                deviceRows.forEach { (key, value) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Text(key, color = AiTextMuted, fontSize = 13.sp, modifier = Modifier.weight(0.42f))
                        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(0.58f))
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Text("Permissão câmara", color = AiTextMuted, fontSize = 13.sp, modifier = Modifier.weight(0.42f))
                    Text(
                        if (hasCamera) "Concedida" else "Não concedida",
                        color = if (hasCamera) AiSuccess else AiWarning,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(0.58f),
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            GradientButton(
                text = if (running) "A executar testes…" else "Executar testes",
                onClick = { vm.runCompatibilityChecks() },
                modifier = Modifier.fillMaxWidth(),
                enabled = !running,
                icon = Icons.Filled.Refresh,
            )

            if (running) {
                Spacer(Modifier.height(14.dp))
                CircularProgressIndicator(color = AiSecondary, modifier = Modifier.size(28.dp).align(Alignment.CenterHorizontally))
            }

            if (results.isNotEmpty()) {
                SectionLabel("Resultados")
                AppCard {
                    results.forEachIndexed { index, check ->
                        if (index > 0) Spacer(Modifier.height(12.dp))
                        CheckRow(check)
                    }
                }
                val failed = results.count { it.status == CheckStatus.FAIL }
                val warned = results.count { it.status == CheckStatus.WARN }
                Spacer(Modifier.height(12.dp))
                Text(
                    when {
                        failed > 0 -> "$failed teste(s) falharam. Consulta os detalhes acima."
                        warned > 0 -> "Funciona, com $warned aviso(s) que podem limitar o desempenho."
                        else -> "Tudo certo neste aparelho."
                    },
                    color = if (failed > 0) AiDanger else if (warned > 0) AiWarning else AiSuccess,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Estes testes medem o que este aparelho consegue fazer. Não garantem uma chamada compatível com WhatsApp ou Messenger, que não aceitam câmara virtual sem root.",
                color = AiTextMuted,
                fontSize = 11.sp,
                lineHeight = 16.sp,
            )
        }
    }
}

@Composable
private fun CheckRow(check: CheckResult) {
    Row(verticalAlignment = Alignment.Top) {
        CheckIcon(check.status)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(check.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(check.detail, color = AiTextMuted, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun OptionRow(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) Color(0x227C5CFF) else Color.Transparent)
            .padding(horizontal = 10.dp, vertical = 10.dp)
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = AiTextMuted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.width(10.dp))
        RadioButton(
            selected = selected,
            onClick = null,
            colors = RadioButtonDefaults.colors(selectedColor = AiPrimary, unselectedColor = AiTextMuted),
        )
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = AiTextMuted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = AiPrimary),
        )
    }
}
