package app.aifacelive.render

import android.graphics.Bitmap
import android.graphics.Matrix
import android.opengl.GLES20.*
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import app.aifacelive.face.FaceLandmarks
import app.aifacelive.face.SourcePhoto
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.min

/**
 * Renderer OpenGL ES 2.0 (compatível com praticamente todos os Android desde 2.3, e exigido pelo manifest).
 *
 * Passo 1 — fundo: frame da câmara (RGBA), com rotação EXIF/sensor e espelho aplicados nas coordenadas UV.
 * Passo 2 — rosto: a fotografia de origem é desenhada numa malha de Delaunay (478 vértices).
 *           Cada vértice desloca-se para o landmark correspondente do rosto ao vivo, por isso a fotografia
 *           acompanha a posição, inclinação, abertura da boca e olhos. O contorno tem alfa 0 (bordo suave).
 *
 * Limitação: é uma deformação geométrica, sem geração de textura nova nem correção de iluminação.
 */
class FaceSwapRenderer : GLSurfaceView.Renderer {

    /** Chamado (de qualquer thread) quando há um frame ou alteração para desenhar. */
    @Volatile
    var onNeedsRender: (() -> Unit)? = null

    @Volatile
    var glRendererName: String = "—"
        private set

    @Volatile
    var glVersionName: String = "—"
        private set

    // ---- Estado partilhado (protegido por lock) ----
    private val lock = Any()
    private var frameBuffer: ByteBuffer = ByteBuffer.allocateDirect(0)
    private var frameW = 0
    private var frameH = 0
    private var frameRotation = 0
    private var frameDirty = false
    private var mirror = true
    private var landmarks: FloatArray? = null
    private var source: SourcePhoto? = null
    private var sourceDirty = false
    private var swapEnabled = true
    private var snapshotCallback: ((Bitmap) -> Unit)? = null

    // ---- Estado GL (apenas thread de render) ----
    private var backgroundProgram = 0
    private var faceProgram = 0
    private var backgroundVbo = 0
    private var faceVbo = 0
    private var faceIbo = 0
    private var frameTexture = 0
    private var sourceTexture = 0
    private var frameTexW = 0
    private var frameTexH = 0
    private var hasFrameTexture = false
    private var hasSourceGeometry = false
    private var indexCount = 0
    private var viewW = 1
    private var viewH = 1

    /** Vértices do rosto: x, y (clip) · u, v (textura da fotografia) · alfa. */
    private var faceVertices = FloatArray(0)
    private var faceBuffer: FloatBuffer = floatBufferOf(0)
    private val backgroundVertices = FloatArray(16)
    private val backgroundBuffer: FloatBuffer = floatBufferOf(16)

    private class DrawState(
        val frameW: Int,
        val frameH: Int,
        val rotation: Int,
        val mirror: Boolean,
        val landmarks: FloatArray?,
        val hasSource: Boolean,
        val swap: Boolean,
        val snapshot: ((Bitmap) -> Unit)?,
    )

    /** Copia um frame RGBA compacto (width*height*4 bytes) para o renderer. Chamado pela thread de análise. */
    fun submitFrame(src: ByteBuffer, width: Int, height: Int, rotation: Int, lmk: FloatArray?, mirrorDisplay: Boolean) {
        val bytes = width * height * 4
        synchronized(lock) {
            if (frameBuffer.capacity() < bytes) {
                frameBuffer = ByteBuffer.allocateDirect(bytes)
            }
            val view = src.duplicate()
            view.clear()
            view.limit(bytes)
            frameBuffer.clear()
            frameBuffer.put(view)
            frameBuffer.flip()
            frameW = width
            frameH = height
            frameRotation = rotation
            landmarks = lmk
            mirror = mirrorDisplay
            frameDirty = true
        }
        onNeedsRender?.invoke()
    }

    fun setSource(photo: SourcePhoto?) {
        synchronized(lock) {
            source = photo
            sourceDirty = true
        }
        onNeedsRender?.invoke()
    }

    fun setSwapEnabled(enabled: Boolean) {
        synchronized(lock) { swapEnabled = enabled }
        onNeedsRender?.invoke()
    }

    /** Pede um snapshot do ecrã GL no próximo frame (inclui o efeito). */
    fun requestSnapshot(callback: (Bitmap) -> Unit) {
        synchronized(lock) { snapshotCallback = callback }
        onNeedsRender?.invoke()
    }

    // ------------------------------------------------------------------
    // GLSurfaceView.Renderer
    // ------------------------------------------------------------------

    override fun onSurfaceCreated(unused: GL10?, config: EGLConfig?) {
        glRendererName = glGetString(GL_RENDERER) ?: "desconhecido"
        glVersionName = glGetString(GL_VERSION) ?: "desconhecido"
        glClearColor(0f, 0f, 0f, 1f)

        backgroundProgram = buildProgram(BACKGROUND_VERTEX, BACKGROUND_FRAGMENT)
        faceProgram = buildProgram(FACE_VERTEX, FACE_FRAGMENT)

        val buffers = IntArray(3)
        glGenBuffers(3, buffers, 0)
        backgroundVbo = buffers[0]
        faceVbo = buffers[1]
        faceIbo = buffers[2]
        glBindBuffer(GL_ARRAY_BUFFER, backgroundVbo)
        glBufferData(GL_ARRAY_BUFFER, 16 * 4, null, GL_DYNAMIC_DRAW)

        // Um novo contexto GL invalida todas as texturas: marcar para voltar a enviar.
        frameTexture = 0
        sourceTexture = 0
        frameTexW = 0
        frameTexH = 0
        hasFrameTexture = false
        hasSourceGeometry = false
        synchronized(lock) {
            frameDirty = frameW > 0 && frameBuffer.capacity() >= frameW * frameH * 4
            sourceDirty = source != null
        }
    }

    override fun onSurfaceChanged(unused: GL10?, width: Int, height: Int) {
        glViewport(0, 0, width, height)
        viewW = width
        viewH = height
    }

    override fun onDrawFrame(unused: GL10?) {
        val state = synchronized(lock) {
            if (frameDirty) {
                uploadFrame(frameBuffer, frameW, frameH)
                frameDirty = false
            }
            if (sourceDirty) {
                source?.let { uploadSource(it) }
                sourceDirty = false
            }
            val snap = snapshotCallback
            snapshotCallback = null
            DrawState(
                frameW = frameW,
                frameH = frameH,
                rotation = frameRotation,
                mirror = mirror,
                landmarks = landmarks,
                hasSource = source != null,
                swap = swapEnabled,
                snapshot = snap,
            )
        }

        glClear(GL_COLOR_BUFFER_BIT)
        if (hasFrameTexture && state.frameW > 0) {
            val uprightAspect = if (state.rotation == 90 || state.rotation == 270) {
                state.frameH.toFloat() / state.frameW
            } else {
                state.frameW.toFloat() / state.frameH
            }
            val viewAspect = viewW.toFloat() / viewH
            // "Cover": preenche o ecrã e corta o excesso, sem distorcer.
            val scaleX: Float
            val scaleY: Float
            if (viewAspect > uprightAspect) {
                scaleX = 1f
                scaleY = viewAspect / uprightAspect
            } else {
                scaleX = uprightAspect / viewAspect
                scaleY = 1f
            }

            drawBackground(scaleX, scaleY, state.rotation, state.mirror)

            val lmk = state.landmarks
            if (state.swap && lmk != null && state.hasSource && hasSourceGeometry) {
                drawFace(lmk, scaleX, scaleY, state.mirror)
            }
        }

        state.snapshot?.let { readSnapshot(it) }
    }

    // ------------------------------------------------------------------
    // Upload de texturas e geometria (thread GL)
    // ------------------------------------------------------------------

    private fun uploadFrame(buffer: ByteBuffer, w: Int, h: Int) {
        if (frameTexture == 0) frameTexture = createTexture()
        glBindTexture(GL_TEXTURE_2D, frameTexture)
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
        buffer.position(0)
        if (w != frameTexW || h != frameTexH) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, buffer)
            frameTexW = w
            frameTexH = h
        } else {
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, buffer)
        }
        hasFrameTexture = true
    }

    private fun uploadSource(photo: SourcePhoto) {
        if (sourceTexture == 0) sourceTexture = createTexture()
        glBindTexture(GL_TEXTURE_2D, sourceTexture)
        GLUtils.texImage2D(GL_TEXTURE_2D, 0, photo.bitmap, 0)

        val n = photo.landmarks.size / 2
        faceVertices = FloatArray(n * 5)
        for (i in 0 until n) {
            val base = i * 5
            faceVertices[base + 2] = photo.landmarks[2 * i]
            faceVertices[base + 3] = photo.landmarks[2 * i + 1]
            faceVertices[base + 4] = if (FaceLandmarks.OVAL.contains(i)) 0f else 1f
        }
        faceBuffer = floatBufferOf(n * 5)

        glBindBuffer(GL_ARRAY_BUFFER, faceVbo)
        glBufferData(GL_ARRAY_BUFFER, n * 5 * 4, null, GL_DYNAMIC_DRAW)

        val indices = shortBufferOf(photo.triangles)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, faceIbo)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, photo.triangles.size * 2, indices, GL_STATIC_DRAW)
        indexCount = photo.triangles.size
        hasSourceGeometry = true
    }

    private fun createTexture(): Int {
        val ids = IntArray(1)
        glGenTextures(1, ids, 0)
        glBindTexture(GL_TEXTURE_2D, ids[0])
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
        return ids[0]
    }

    // ------------------------------------------------------------------
    // Desenho
    // ------------------------------------------------------------------

    private fun drawBackground(scaleX: Float, scaleY: Float, rotation: Int, mirror: Boolean) {
        val corners = arrayOf(floatArrayOf(0f, 0f), floatArrayOf(1f, 0f), floatArrayOf(0f, 1f), floatArrayOf(1f, 1f))
        for (i in 0 until 4) {
            val dx = corners[i][0]
            val dy = corners[i][1]
            val u = if (mirror) 1f - dx else dx
            val v = dy
            val (tu, tv) = uprightToTexture(u, v, rotation)
            backgroundVertices[i * 4] = (dx * 2f - 1f) * scaleX
            backgroundVertices[i * 4 + 1] = (1f - dy * 2f) * scaleY
            backgroundVertices[i * 4 + 2] = tu
            backgroundVertices[i * 4 + 3] = tv
        }

        glUseProgram(backgroundProgram)
        glBindBuffer(GL_ARRAY_BUFFER, backgroundVbo)
        backgroundBuffer.clear()
        backgroundBuffer.put(backgroundVertices)
        backgroundBuffer.flip()
        glBufferSubData(GL_ARRAY_BUFFER, 0, 16 * 4, backgroundBuffer)

        val aPos = glGetAttribLocation(backgroundProgram, "aPos")
        val aTex = glGetAttribLocation(backgroundProgram, "aTex")
        glEnableVertexAttribArray(aPos)
        glVertexAttribPointer(aPos, 2, GL_FLOAT, false, 16, 0)
        glEnableVertexAttribArray(aTex)
        glVertexAttribPointer(aTex, 2, GL_FLOAT, false, 16, 8)

        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, frameTexture)
        glUniform1i(glGetUniformLocation(backgroundProgram, "uTex"), 0)
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4)

        glDisableVertexAttribArray(aPos)
        glDisableVertexAttribArray(aTex)
    }

    private fun drawFace(lmk: FloatArray, scaleX: Float, scaleY: Float, mirror: Boolean) {
        val n = min(lmk.size / 2, faceVertices.size / 5)
        for (i in 0 until n) {
            val lx = lmk[2 * i]
            val ly = lmk[2 * i + 1]
            val dx = if (mirror) 1f - lx else lx
            val base = i * 5
            faceVertices[base] = (dx * 2f - 1f) * scaleX
            faceVertices[base + 1] = (1f - ly * 2f) * scaleY
        }
        faceBuffer.clear()
        faceBuffer.put(faceVertices)
        faceBuffer.flip()

        glUseProgram(faceProgram)
        glBindBuffer(GL_ARRAY_BUFFER, faceVbo)
        glBufferSubData(GL_ARRAY_BUFFER, 0, faceVertices.size * 4, faceBuffer)

        val stride = 5 * 4
        val aPos = glGetAttribLocation(faceProgram, "aPos")
        val aTex = glGetAttribLocation(faceProgram, "aTex")
        val aAlpha = glGetAttribLocation(faceProgram, "aAlpha")
        glEnableVertexAttribArray(aPos)
        glVertexAttribPointer(aPos, 2, GL_FLOAT, false, stride, 0)
        glEnableVertexAttribArray(aTex)
        glVertexAttribPointer(aTex, 2, GL_FLOAT, false, stride, 8)
        glEnableVertexAttribArray(aAlpha)
        glVertexAttribPointer(aAlpha, 1, GL_FLOAT, false, stride, 16)

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, faceIbo)
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, sourceTexture)
        glUniform1i(glGetUniformLocation(faceProgram, "uTex"), 0)

        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_SHORT, 0)
        glDisable(GL_BLEND)

        glDisableVertexAttribArray(aPos)
        glDisableVertexAttribArray(aTex)
        glDisableVertexAttribArray(aAlpha)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    /** Converte coordenadas "upright" (já rodadas) para coordenadas da textura do sensor. */
    private fun uprightToTexture(u: Float, v: Float, rotation: Int): Pair<Float, Float> = when (rotation) {
        90 -> Pair(v, 1f - u)
        180 -> Pair(1f - u, 1f - v)
        270 -> Pair(1f - v, u)
        else -> Pair(u, v)
    }

    private fun readSnapshot(callback: (Bitmap) -> Unit) {
        val w = viewW
        val h = viewH
        val buffer = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, buffer)
        buffer.rewind()
        val raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(buffer)
        // O OpenGL lê de baixo para cima; invertemos verticalmente.
        val flip = Matrix().apply { setScale(1f, -1f, 0f, h / 2f) }
        val upright = Bitmap.createBitmap(raw, 0, 0, w, h, flip, false)
        raw.recycle()
        callback(upright)
    }

    // ------------------------------------------------------------------
    // Utilitários GL
    // ------------------------------------------------------------------

    private fun buildProgram(vertexSource: String, fragmentSource: String): Int {
        val vs = compileShader(GL_VERTEX_SHADER, vertexSource)
        val fs = compileShader(GL_FRAGMENT_SHADER, fragmentSource)
        val program = glCreateProgram()
        glAttachShader(program, vs)
        glAttachShader(program, fs)
        glLinkProgram(program)
        val status = IntArray(1)
        glGetProgramiv(program, GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val log = glGetProgramInfoLog(program)
            glDeleteProgram(program)
            throw RuntimeException("Falha ao ligar shaders: $log")
        }
        glDeleteShader(vs)
        glDeleteShader(fs)
        return program
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = glCreateShader(type)
        glShaderSource(shader, source)
        glCompileShader(shader)
        val status = IntArray(1)
        glGetShaderiv(shader, GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = glGetShaderInfoLog(shader)
            glDeleteShader(shader)
            throw RuntimeException("Falha ao compilar shader: $log")
        }
        return shader
    }

    private companion object {
        const val BACKGROUND_VERTEX = """
            attribute vec2 aPos;
            attribute vec2 aTex;
            varying vec2 vTex;
            void main() {
                gl_Position = vec4(aPos, 0.0, 1.0);
                vTex = aTex;
            }
        """

        const val BACKGROUND_FRAGMENT = """
            precision mediump float;
            uniform sampler2D uTex;
            varying vec2 vTex;
            void main() {
                gl_FragColor = texture2D(uTex, vTex);
            }
        """

        const val FACE_VERTEX = """
            attribute vec2 aPos;
            attribute vec2 aTex;
            attribute float aAlpha;
            varying vec2 vTex;
            varying float vAlpha;
            void main() {
                gl_Position = vec4(aPos, 0.0, 1.0);
                vTex = aTex;
                vAlpha = aAlpha;
            }
        """

        const val FACE_FRAGMENT = """
            precision mediump float;
            uniform sampler2D uTex;
            varying vec2 vTex;
            varying float vAlpha;
            void main() {
                vec4 c = texture2D(uTex, vTex);
                gl_FragColor = vec4(c.rgb, c.a * vAlpha);
            }
        """

        fun floatBufferOf(size: Int): FloatBuffer =
            ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

        fun shortBufferOf(array: ShortArray): ShortBuffer {
            val buffer = ByteBuffer.allocateDirect(array.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
            buffer.put(array)
            buffer.position(0)
            return buffer
        }
    }
}
