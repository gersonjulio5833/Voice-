package app.aifacelive.util

import android.app.ActivityManager
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import java.util.Locale

enum class CheckStatus { PASS, WARN, FAIL }

data class CheckResult(val name: String, val status: CheckStatus, val detail: String)

/** Leitura de capacidades reais do aparelho (sem root, só APIs públicas). */
object Compatibility {

    fun glEsVersion(context: Context): Float = runCatching {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        am.deviceConfigurationInfo.glEsVersion.toFloat()
    }.getOrDefault(0f)

    fun totalRamGb(context: Context): Double = runCatching {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        info.totalMem / 1_073_741_824.0
    }.getOrDefault(0.0)

    /** Devolve (existe câmara frontal, existe câmara traseira). */
    fun cameraFacing(context: Context): Pair<Boolean, Boolean> = runCatching {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        var front = false
        var back = false
        for (id in cm.cameraIdList) {
            when (cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> front = true
                CameraCharacteristics.LENS_FACING_BACK -> back = true
            }
        }
        front to back
    }.getOrDefault(false to false)

    fun deviceRows(context: Context): List<Pair<String, String>> = listOf(
        "Fabricante" to Build.MANUFACTURER,
        "Modelo" to Build.MODEL,
        "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        "Arquitetura" to Build.SUPPORTED_ABIS.joinToString(", "),
        "Processador" to "${Runtime.getRuntime().availableProcessors()} núcleos",
        "Memória total" to String.format(Locale.US, "%.1f GB", totalRamGb(context)),
        "OpenGL ES" to String.format(Locale.US, "%.1f", glEsVersion(context)),
    )
}
