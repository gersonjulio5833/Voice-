package app.aifacelive.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import app.aifacelive.Candidate
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.aifacelive.AppViewModel
import app.aifacelive.face.SourcePhoto
import app.aifacelive.util.Compatibility
import app.aifacelive.util.hasCameraPermission
import app.aifacelive.util.openAppSettings
import androidx.compose.ui.platform.LocalContext

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E1248), AiBackground, AiBackground))),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            LogoBadge(size = 120.dp)
            Spacer(Modifier.height(28.dp))
            Text("AI Face Live", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Spacer(Modifier.height(6.dp))
            Text("Troca de rosto em tempo real", fontSize = 15.sp, color = AiTertiary)
            Spacer(Modifier.height(32.dp))
            Text(
                "Escolhe uma fotografia, ativa o efeito e pré-visualiza a transformação com a câmara do telemóvel.",
                fontSize = 14.sp,
                color = AiTextMuted,
                textAlign = TextAlign.Center,
                lineHeight = 21.sp,
            )
            Spacer(Modifier.height(48.dp))
            GradientButton("Começar", onClick = onStart, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            Text(
                "Android · sem root · processamento no dispositivo",
                fontSize = 11.sp,
                color = AiTextMuted,
            )
        }
    }
}

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onSelectPhoto: () -> Unit,
    onPreview: () -> Unit,
    onSettings: () -> Unit,
    onCompatibility: () -> Unit,
) {
    val source by vm.source.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LogoBadge(size = 40.dp)
            Spacer(Modifier.width(12.dp))
            Text("AI Face Live", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
            IconButton(onClick = onSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Definições", tint = Color.White)
            }
        }

        Spacer(Modifier.height(18.dp))

        // Cartão principal
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = Color.Transparent,
        ) {
            Column(
                modifier = Modifier
                    .background(Brush.linearGradient(listOf(Color(0xFF2A1A66), Color(0xFF122047))))
                    .padding(20.dp),
            ) {
                Text("Face swap em tempo real", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Usa uma fotografia da galeria como referência. O rosto da câmara segue a tua posição, expressão e movimento da boca.",
                    fontSize = 13.sp,
                    color = Color(0xFFC9C2E6),
                    lineHeight = 19.sp,
                )
                Spacer(Modifier.height(16.dp))
                GradientButton("Selecionar foto", onClick = onSelectPhoto, modifier = Modifier.fillMaxWidth(), icon = Icons.Filled.Photo)
            }
        }

        Spacer(Modifier.height(16.dp))

        AppCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val photo = source
                if (photo != null) {
                    PhotoPreview(
                        bitmap = photo.bitmap.asImageBitmap(),
                        description = "Fotografia de origem",
                        modifier = Modifier.size(72.dp),
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Fotografia ativa", fontWeight = FontWeight.SemiBold, color = Color.White)
                        Spacer(Modifier.height(4.dp))
                        Text(photo.label, color = AiTextMuted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        StatusChip("Rosto pronto", AiSuccess)
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(AiSurfaceVariant),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Filled.Face, contentDescription = null, tint = AiTextMuted, modifier = Modifier.size(32.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Nenhuma fotografia", fontWeight = FontWeight.SemiBold, color = Color.White)
                        Spacer(Modifier.height(4.dp))
                        Text("Escolhe uma foto frontal para começar.", color = AiTextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        MenuRow(
            title = "Pré-visualização",
            subtitle = if (source != null) "Ver o efeito com a câmara" else "Seleciona uma foto primeiro",
            icon = Icons.Filled.Face,
            enabled = source != null,
            onClick = onPreview,
        )
        MenuRow(
            title = "Definições e permissões",
            subtitle = "Câmara, qualidade, desempenho",
            icon = Icons.Filled.Settings,
            onClick = onSettings,
        )
        MenuRow(
            title = "Compatibilidade do aparelho",
            subtitle = "Testes reais de OpenGL, câmara e modelo",
            icon = Icons.Filled.Refresh,
            onClick = onCompatibility,
        )

        Spacer(Modifier.weight(1f))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x1AFBBF24))
                .padding(12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = AiWarning, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                "Simulação visual. Não é possível substituir o vídeo do WhatsApp ou do Messenger sem root. Usa a app para pré-visualizar e partilhar snapshots.",
                fontSize = 11.sp,
                color = Color(0xFFE9D9A6),
                lineHeight = 16.sp,
            )
        }
    }
}

@Composable
private fun MenuRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    enabled: Boolean = true,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = AiSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, AiOutline),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (enabled) AiSurfaceVariant else AiSurface),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = if (enabled) AiSecondary else AiTextMuted, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = if (enabled) Color.White else AiTextMuted, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(subtitle, color = AiTextMuted, fontSize = 12.sp)
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = AiTextMuted)
        }
    }
}

@Composable
fun SelectPhotoScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onConfirmed: () -> Unit,
) {
    val candidate by vm.candidate.collectAsStateWithLifecycle()
    var authorized by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            authorized = false
            vm.stagePhoto(uri)
        }
    }

    DisposableEffect(Unit) {
        onDispose { vm.cancelCandidate() }
    }

    Column(modifier = Modifier.fillMaxSize().navigationBarsPadding()) {
        AppTopBarCompat(title = "Selecionar foto", onBack = onBack)

        LazyColumn(
            modifier = Modifier.weight(1f).padding(horizontal = 20.dp),
            contentPadding = PaddingValues(bottom = 16.dp),
        ) {
            item {
                Text(
                    "Escolhe uma fotografia da galeria. Usa apenas imagens de pessoas que autorizaram esta utilização.",
                    color = AiTextMuted,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                )
                Spacer(Modifier.height(14.dp))
                GradientButton(
                    "Escolher da galeria",
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Filled.Photo,
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "O seletor do Android não precisa de permissão para ver a galeria.",
                    color = AiTextMuted,
                    fontSize = 11.sp,
                )
                Spacer(Modifier.height(18.dp))
            }

            when (val state = candidate) {
                Candidate.None -> item { TipsCard() }
                Candidate.Loading -> item {
                    AppCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = AiSecondary, strokeWidth = 2.dp)
                            Spacer(Modifier.width(14.dp))
                            Text("A procurar rosto na fotografia…", color = Color.White)
                        }
                    }
                }
                is Candidate.Failed -> item {
                    AppCard {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = AiDanger)
                            Spacer(Modifier.width(10.dp))
                            Text(state.reason, color = Color(0xFFFFD6DD), fontSize = 13.sp, lineHeight = 19.sp)
                        }
                    }
                }
                is Candidate.Ready -> item {
                    ReadyCandidate(
                        photo = state.photo,
                        authorized = authorized,
                        onAuthorizedChange = { authorized = it },
                        onConfirm = {
                            vm.confirmCandidate()
                            onConfirmed()
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun ReadyCandidate(
    photo: SourcePhoto,
    authorized: Boolean,
    onAuthorizedChange: (Boolean) -> Unit,
    onConfirm: () -> Unit,
) {
    Column {
        PhotoPreview(
            bitmap = photo.bitmap.asImageBitmap(),
            description = "Pré-visualização da fotografia escolhida",
            modifier = Modifier.fillMaxWidth().height(320.dp),
        )
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusChip("Rosto detetado · 478 pontos", AiSuccess)
        }
        Spacer(Modifier.height(14.dp))
        AppCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = authorized,
                    onCheckedChange = onAuthorizedChange,
                    colors = CheckboxDefaults.colors(checkedColor = AiPrimary, uncheckedColor = AiTextMuted),
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    "Confirmo que tenho autorização da pessoa desta fotografia para a usar nesta simulação.",
                    color = Color.White,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        GradientButton(
            "Confirmar fotografia",
            onClick = onConfirm,
            modifier = Modifier.fillMaxWidth(),
            enabled = authorized,
            icon = Icons.Filled.CheckCircle,
        )
    }
}

@Composable
private fun TipsCard() {
    AppCard {
        Text("Para um melhor resultado", fontWeight = FontWeight.SemiBold, color = Color.White)
        Spacer(Modifier.height(10.dp))
        listOf(
            "Rosto frontal, olhos abertos e boca visível",
            "Boa luz, sem contraluz forte",
            "Uma só pessoa na imagem",
            "Resolução mínima de 480 px no lado menor",
        ).forEach { tip ->
            Row(Modifier.padding(vertical = 3.dp)) {
                Text("•", color = AiSecondary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text(tip, color = AiTextMuted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun AppTopBarCompat(title: String, onBack: () -> Unit) {
    AppTopBar(title = title, onBack = onBack)
}
