package app.aifacelive.face

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Triangulação de Delaunay (Bowyer–Watson).
 *
 * É executada uma vez por fotografia de origem. A malha resultante liga os 478 pontos
 * faciais e é reutilizada em todos os frames para deformar a fotografia sobre o rosto ao vivo.
 */
object Delaunay {

    private class Triangle(val a: Int, val b: Int, val c: Int, x: DoubleArray, y: DoubleArray) {
        var cx = 0.0
        var cy = 0.0
        var r2 = -1.0

        init {
            val ax = x[a]; val ay = y[a]
            val bx = x[b]; val by = y[b]
            val qx = x[c]; val qy = y[c]
            val d = 2.0 * (ax * (by - qy) + bx * (qy - ay) + qx * (ay - by))
            if (abs(d) > 1e-12) {
                val a2 = ax * ax + ay * ay
                val b2 = bx * bx + by * by
                val c2 = qx * qx + qy * qy
                cx = (a2 * (by - qy) + b2 * (qy - ay) + c2 * (ay - by)) / d
                cy = (a2 * (qx - bx) + b2 * (ax - qx) + c2 * (bx - ax)) / d
                val dx = ax - cx
                val dy = ay - cy
                r2 = dx * dx + dy * dy
            }
        }

        /** Triângulos degenerados (colineares) nunca contêm pontos. */
        fun circumcircleContains(px: Double, py: Double): Boolean {
            if (r2 < 0.0) return false
            val dx = px - cx
            val dy = py - cy
            return dx * dx + dy * dy < r2
        }
    }

    /**
     * Devolve os triângulos como pares de índices sobre os pontos de entrada.
     * Triângulos que usam vértices do super-triângulo são descartados.
     */
    fun triangulate(x: DoubleArray, y: DoubleArray): List<IntArray> {
        val n = x.size
        require(y.size == n) { "x e y devem ter o mesmo tamanho" }
        if (n < 3) return emptyList()

        var minX = Double.MAX_VALUE
        var minY = Double.MAX_VALUE
        var maxX = -Double.MAX_VALUE
        var maxY = -Double.MAX_VALUE
        for (i in 0 until n) {
            minX = min(minX, x[i]); maxX = max(maxX, x[i])
            minY = min(minY, y[i]); maxY = max(maxY, y[i])
        }
        val span = max(max(maxX - minX, maxY - minY), 1.0)
        val midX = (minX + maxX) / 2.0
        val midY = (minY + maxY) / 2.0

        val px = DoubleArray(n + 3)
        val py = DoubleArray(n + 3)
        for (i in 0 until n) { px[i] = x[i]; py[i] = y[i] }
        px[n] = midX - 20.0 * span; py[n] = midY - span
        px[n + 1] = midX; py[n + 1] = midY + 20.0 * span
        px[n + 2] = midX + 20.0 * span; py[n + 2] = midY - span

        val triangles = mutableListOf(Triangle(n, n + 1, n + 2, px, py))

        for (i in 0 until n) {
            val bad = triangles.filter { it.circumcircleContains(px[i], py[i]) }
            if (bad.isEmpty()) continue

            // Arestas que pertencem a um único triângulo mau formam a cavidade.
            val edgeCount = HashMap<Long, Int>()
            val edgeEnds = HashMap<Long, Pair<Int, Int>>()
            for (t in bad) {
                for ((p, q) in listOf(t.a to t.b, t.b to t.c, t.c to t.a)) {
                    val key = edgeKey(p, q)
                    edgeCount[key] = (edgeCount[key] ?: 0) + 1
                    edgeEnds[key] = p to q
                }
            }
            val badSet = bad.toHashSet()
            triangles.removeAll { it in badSet }
            for ((key, count) in edgeCount) {
                if (count == 1) {
                    val (p, q) = edgeEnds.getValue(key)
                    triangles.add(Triangle(p, q, i, px, py))
                }
            }
        }

        return triangles
            .filter { it.a < n && it.b < n && it.c < n }
            .map { intArrayOf(it.a, it.b, it.c) }
    }

    /**
     * Triangula landmarks normalizados (x, y em [0, 1]) usando coordenadas em píxeis,
     * para que a geometria seja correta mesmo com proporções não quadradas.
     * Devolve índices como short (a malha tem 478 vértices).
     */
    fun triangulateLandmarks(points: FloatArray, width: Int, height: Int): ShortArray {
        val n = points.size / 2
        val xs = DoubleArray(n) { points[2 * it].toDouble() * width }
        val ys = DoubleArray(n) { points[2 * it + 1].toDouble() * height }
        val triangles = triangulate(xs, ys)
        val out = ShortArray(triangles.size * 3)
        triangles.forEachIndexed { t, tri ->
            out[t * 3] = tri[0].toShort()
            out[t * 3 + 1] = tri[1].toShort()
            out[t * 3 + 2] = tri[2].toShort()
        }
        return out
    }

    private fun edgeKey(p: Int, q: Int): Long {
        val lo = min(p, q).toLong()
        val hi = max(p, q).toLong()
        return (lo shl 32) or hi
    }
}
