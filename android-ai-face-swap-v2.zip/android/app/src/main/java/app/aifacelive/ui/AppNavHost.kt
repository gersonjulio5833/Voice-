package app.aifacelive.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import app.aifacelive.AppViewModel

private object Routes {
    const val WELCOME = "welcome"
    const val HOME = "home"
    const val SELECT = "select"
    const val PREVIEW = "preview"
    const val SETTINGS = "settings"
    const val COMPATIBILITY = "compatibility"
}

@Composable
fun AppNavHost() {
    val vm: AppViewModel = viewModel()
    val nav = rememberNavController()

    NavHost(
        navController = nav,
        startDestination = Routes.WELCOME,
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        composable(Routes.WELCOME) {
            WelcomeScreen(
                onStart = {
                    nav.navigate(Routes.HOME) {
                        popUpTo(Routes.WELCOME) { inclusive = true }
                    }
                },
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                vm = vm,
                onSelectPhoto = { nav.navigate(Routes.SELECT) },
                onPreview = { nav.navigate(Routes.PREVIEW) },
                onSettings = { nav.navigate(Routes.SETTINGS) },
                onCompatibility = { nav.navigate(Routes.COMPATIBILITY) },
            )
        }
        composable(Routes.SELECT) {
            SelectPhotoScreen(
                vm = vm,
                onBack = { nav.popBackStack() },
                onConfirmed = { nav.popBackStack() },
            )
        }
        composable(Routes.PREVIEW) {
            PreviewScreen(
                vm = vm,
                onBack = { nav.popBackStack() },
                onChangePhoto = { nav.navigate(Routes.SELECT) },
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                vm = vm,
                onBack = { nav.popBackStack() },
                onCompatibility = { nav.navigate(Routes.COMPATIBILITY) },
            )
        }
        composable(Routes.COMPATIBILITY) {
            CompatibilityScreen(vm = vm, onBack = { nav.popBackStack() })
        }
    }
}
