package app.aifacelive.engine

import android.content.Context
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import app.aifacelive.face.LiveFaceTracker
import app.aifacelive.face.SourcePhoto
import app.aifacelive.face.TrackResult
import app.aifacelive.render.FaceSwapRenderer
import app.aifacelive.settings.Acceleration
import app.aifacelive.settings.Lens
import app.aifacelive.settings.Quality
import com.google.mediapipe.framework.image.ByteBufferImageBuilder
import com.google.mediapipe.framework.image.MPImage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.nio.ByteBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Estado mostrado no ecrã de pré-visualização (atualizado ~2 vezes por segundo). */
data class EngineStats(
    val fps: Float = 0f,
    val latencyMs: Float = 0f,
    val faceDetected: Boolean = false,
    val blendshapes: Map<String, Float> = emptyMap(),
    val acceleration: Acceleration = Acceleration.CPU,
    val fellBack: Boolean = false,
    val error: String? = null,
    val frames: Long = 0L,
)

/**
 * Orquestra câmara → tracking → renderer.
 *
 * - CameraX entrega frames RGBA num executor dedicado (não bloqueia a UI).
 * - O frame é copiado para um buffer compacto, analisado pelo MediaPipe e enviado ao renderer GL.
 * - Se a GPU falhar, o motor muda para CPU automaticamente.
 */
class FaceSwapEngine(private val context: Context) {

    val renderer = FaceSwapRenderer()

    private val _stats = MutableStateFlow(EngineStats())
    val stats: StateFlow<EngineStats> = _stats.asStateFlow()

    private val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ai-face-analysis").apply { priority = Thread.NORM_PRIORITY + 1 }
    }

    @Volatile private var wantedAcceleration = Acceleration.CPU
    @Volatile private var mirror = true
    @Volatile private var forceCpu = false
    @Volatile private var extraRotation = 0

    // Usado apenas na thread de análise
    private var tracker: LiveFaceTracker? = null
    private var trackerAcceleration: Acceleration? = null
    private var staging: ByteBuffer = ByteBuffer.allocateDirect(0)
    private var windowStart = 0L
    private var windowFrames = 0
    private var latencySum = 0f
    private var totalFrames = 0L

    private var provider: ProcessCameraProvider? = null

    fun configure(acceleration: Acceleration, mirrorDisplay: Boolean, rotationOffset: Int = 0) {
        wantedAcceleration = acceleration
        mirror = mirrorDisplay
        extraRotation = ((rotationOffset % 360) + 360) % 360
    }

    fun setSource(photo: SourcePhoto?) = renderer.setSource(photo)

    fun setSwapEnabled(enabled: Boolean) = renderer.setSwapEnabled(enabled)

    /** Liga a câmara ao ciclo de vida do ecrã. Chamar no thread principal. */
    fun bind(owner: LifecycleOwner, quality: Quality, lens: Lens, onError: (String) -> Unit) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val cameraProvider = future.get()
                provider = cameraProvider
                cameraProvider.unbindAll()

                val selector = when (lens) {
                    Lens.FRONT -> CameraSelector.DEFAULT_FRONT_CAMERA
                    Lens.BACK -> CameraSelector.DEFAULT_BACK_CAMERA
                }
                if (!cameraProvider.hasCamera(selector)) {
                    onError("Esta câmara não existe neste telemóvel. Escolhe a outra câmara nas definições.")
                    return@addListener
                }

                val resolution = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                    .setResolutionStrategy(
                        ResolutionStrategy(
                            Size(quality.width, quality.height),
                            ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER,
                        ),
                    )
                    .build()

                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(resolution)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { image -> analyze(image) }

                cameraProvider.bindToLifecycle(owner, selector, analysis)
            } catch (e: Exception) {
                onError("Câmara indisponível: ${e.message ?: e.javaClass.simpleName}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun unbind() {
        provider?.unbindAll()
    }

    fun shutdown() {
        unbind()
        executor.execute {
            tracker?.close()
            tracker = null
        }
        executor.shutdown()
    }

    // ------------------------------------------------------------------
    // Thread de análise
    // ------------------------------------------------------------------

    private fun analyze(image: ImageProxy) {
        try {
            val w = image.width
            val h = image.height
            val rotation = (image.imageInfo.rotationDegrees + extraRotation) % 360

            ensureTracker()
            ensureStaging(w * h * 4)
            packRgba(image, w, h)

            // Buffer RGBA compacto (stride = w × 4), tal como sai do CameraX (OUTPUT_IMAGE_FORMAT_RGBA_8888).
            val mpImage: MPImage = ByteBufferImageBuilder(staging, w, h, MPImage.IMAGE_FORMAT_RGBA).build()
            val active = tracker ?: return
            val result = active.track(mpImage, rotation, SystemClock.uptimeMillis())

            renderer.submitFrame(staging, w, h, rotation, result.landmarks, mirror)
            recordStats(result, active)
        } catch (t: Throwable) {
            handleError(t)
        } finally {
            image.close()
        }
    }

    private fun ensureTracker() {
        val wanted = if (forceCpu) Acceleration.CPU else wantedAcceleration
        if (tracker == null || trackerAcceleration != wanted) {
            tracker?.close()
            tracker = LiveFaceTracker.create(context, wanted)
            trackerAcceleration = wanted
        }
    }

    private fun ensureStaging(bytes: Int) {
        if (staging.capacity() < bytes) {
            staging = ByteBuffer.allocateDirect(bytes)
        }
    }

    /** Copia o plano RGBA do CameraX para um buffer compacto (stride = largura × 4). */
    private fun packRgba(image: ImageProxy, w: Int, h: Int) {
        val plane = image.planes[0]
        val src = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val bytes = w * h * 4

        staging.clear()
        if (pixelStride == 4 && rowStride == w * 4) {
            val view = src.duplicate()
            view.clear()
            view.limit(bytes)
            staging.put(view)
        } else {
            for (y in 0 until h) {
                val rowStart = y * rowStride
                for (x in 0 until w) {
                    val idx = rowStart + x * pixelStride
                    staging.put(src.get(idx))
                    staging.put(src.get(idx + 1))
                    staging.put(src.get(idx + 2))
                    staging.put(src.get(idx + 3))
                }
            }
        }
        staging.flip()
    }

    private fun recordStats(result: TrackResult, active: LiveFaceTracker) {
        val now = SystemClock.elapsedRealtime()
        if (windowStart == 0L) windowStart = now
        windowFrames++
        totalFrames++
        latencySum += result.inferenceMs

        val elapsed = now - windowStart
        if (elapsed >= 500) {
            val fps = windowFrames * 1000f / elapsed
            _stats.value = EngineStats(
                fps = fps,
                latencyMs = latencySum / windowFrames,
                faceDetected = result.landmarks != null,
                blendshapes = result.blendshapes,
                acceleration = active.acceleration,
                fellBack = active.fellBack,
                error = null,
                frames = totalFrames,
            )
            windowStart = now
            windowFrames = 0
            latencySum = 0f
        }
    }

    private fun handleError(t: Throwable) {
        val current = tracker
        if (current != null && current.acceleration == Acceleration.GPU) {
            // GPU não suportada neste aparelho: continua em CPU sem parar a câmara.
            forceCpu = true
            current.close()
            tracker = null
            _stats.update { it.copy(error = "GPU não suportada neste aparelho. A usar CPU.", fellBack = true) }
        } else {
            _stats.update { it.copy(error = t.message ?: t.javaClass.simpleName, faceDetected = false) }
        }
    }
}
