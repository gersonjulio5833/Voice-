package app.aifacelive.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val AiBackground = Color(0xFF06040E)
val AiSurface = Color(0xFF120E22)
val AiSurfaceVariant = Color(0xFF1B1533)
val AiOutline = Color(0x26FFFFFF)
val AiPrimary = Color(0xFF7C5CFF)
val AiBlue = Color(0xFF3B82F6)
val AiSecondary = Color(0xFF22D3EE)
val AiTertiary = Color(0xFFA78BFA)
val AiTextMuted = Color(0xFF9C95B8)
val AiSuccess = Color(0xFF34D399)
val AiWarning = Color(0xFFFBBF24)
val AiDanger = Color(0xFFF43F5E)

val BrandBrush: Brush = Brush.horizontalGradient(listOf(AiPrimary, AiBlue))

private val AiScheme = darkColorScheme(
    primary = AiPrimary,
    onPrimary = Color.White,
    secondary = AiSecondary,
    onSecondary = Color(0xFF031016),
    tertiary = AiTertiary,
    background = AiBackground,
    onBackground = Color.White,
    surface = AiSurface,
    onSurface = Color.White,
    surfaceVariant = AiSurfaceVariant,
    onSurfaceVariant = AiTextMuted,
    outline = AiOutline,
    error = AiDanger,
)

@Composable
fun AiFaceLiveTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AiScheme, content = content)
}
