package app.aifacelive.face

import android.graphics.Bitmap

/**
 * Fotografia de origem já preparada para o motor:
 * - bitmap ARGB_8888 com a orientação EXIF corrigida;
 * - 478 landmarks normalizados (são também as coordenadas UV da textura);
 * - triângulos da malha de Delaunay (índices para os landmarks).
 */
class SourcePhoto(
    val bitmap: Bitmap,
    val landmarks: FloatArray,
    val triangles: ShortArray,
    val label: String,
)
