package app.aifacelive.face

import android.content.Context
import android.graphics.Bitmap
import app.aifacelive.settings.Acceleration
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult

/** Constantes do modelo MediaPipe Face Landmarker. */
object FaceLandmarks {
    const val COUNT = 478
    const val MODEL_ASSET = "face_landmarker.task"

    /** Contorno do rosto (FACEMESH_FACE_OVAL). Estes vértices recebem alfa 0 para o bordo suave. */
    val OVAL = intArrayOf(
        10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288,
        397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136,
        172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109,
    )
}

/** Resultado de um frame: landmarks normalizados (x0,y0,x1,y1,…) em orientação natural, ou null. */
class TrackResult(
    val landmarks: FloatArray?,
    val blendshapes: Map<String, Float>,
    val inferenceMs: Float,
)

private fun baseOptions(acceleration: Acceleration): BaseOptions =
    BaseOptions.builder()
        .setModelAssetPath(FaceLandmarks.MODEL_ASSET)
        .setDelegate(if (acceleration == Acceleration.GPU) Delegate.GPU else Delegate.CPU)
        .build()

private fun firstFaceLandmarks(result: FaceLandmarkerResult): FloatArray? {
    val face = result.faceLandmarks().firstOrNull() ?: return null
    val out = FloatArray(face.size * 2)
    face.forEachIndexed { i, p ->
        out[2 * i] = p.x()
        out[2 * i + 1] = p.y()
    }
    return out
}

private fun blendshapesOf(result: FaceLandmarkerResult): Map<String, Float> {
    val groups = result.faceBlendshapes().orElse(emptyList())
    val first = groups.firstOrNull() ?: return emptyMap()
    return first.associate { it.categoryName() to it.score() }
}

/**
 * Tracking ao vivo (modo VIDEO). Recebe frames da câmara e devolve os 478 pontos faciais
 * e os blendshapes (expressões: boca, olhos, sorriso, sobrancelhas).
 */
class LiveFaceTracker private constructor(
    private val landmarker: FaceLandmarker,
    val acceleration: Acceleration,
    val fellBack: Boolean,
) : AutoCloseable {

    private var lastTimestamp = -1L

    fun track(image: MPImage, rotationDegrees: Int, timestampMs: Long): TrackResult {
        // A rotação do CameraX (sentido horário) é a mesma convenção do MediaPipe.
        val options = ImageProcessingOptions.builder()
            .setRotationDegrees(rotationDegrees)
            .build()
        val ts = if (timestampMs <= lastTimestamp) lastTimestamp + 1 else timestampMs
        lastTimestamp = ts

        val start = System.nanoTime()
        val result = landmarker.detectForVideo(image, options, ts)
        val ms = (System.nanoTime() - start) / 1_000_000f
        return TrackResult(firstFaceLandmarks(result), blendshapesOf(result), ms)
    }

    override fun close() {
        landmarker.close()
    }

    companion object {
        /**
         * Cria o tracker. Se o GPU delegate falhar, cria automaticamente um tracker CPU
         * (flag [fellBack] fica a true).
         */
        fun create(context: Context, requested: Acceleration): LiveFaceTracker {
            return try {
                LiveFaceTracker(build(context, requested), requested, fellBack = false)
            } catch (e: Exception) {
                if (requested == Acceleration.CPU) throw e
                LiveFaceTracker(build(context, Acceleration.CPU), Acceleration.CPU, fellBack = true)
            }
        }

        private fun build(context: Context, acceleration: Acceleration): FaceLandmarker {
            val options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(baseOptions(acceleration))
                .setRunningMode(RunningMode.VIDEO)
                .setNumFaces(1)
                .setMinFaceDetectionConfidence(0.5f)
                .setMinFacePresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setOutputFaceBlendshapes(true)
                .setOutputFacialTransformationMatrixes(false)
                .build()
            return FaceLandmarker.createFromOptions(context, options)
        }
    }
}

/** Deteção em imagem fixa (fotografia de origem e testes de compatibilidade). Usa sempre CPU. */
class StillFaceDetector private constructor(private val landmarker: FaceLandmarker) : AutoCloseable {

    /** Devolve os 478 pontos normalizados do primeiro rosto encontrado, ou null. */
    fun detect(bitmap: Bitmap): FloatArray? {
        val image: MPImage = BitmapImageBuilder(bitmap).build()
        return firstFaceLandmarks(landmarker.detect(image))
    }

    override fun close() {
        landmarker.close()
    }

    companion object {
        fun create(context: Context): StillFaceDetector {
            val options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(baseOptions(Acceleration.CPU))
                .setRunningMode(RunningMode.IMAGE)
                .setNumFaces(1)
                .setMinFaceDetectionConfidence(0.4f)
                .setMinFacePresenceConfidence(0.4f)
                .setOutputFaceBlendshapes(false)
                .build()
            return StillFaceDetector(FaceLandmarker.createFromOptions(context, options))
        }
    }
}
