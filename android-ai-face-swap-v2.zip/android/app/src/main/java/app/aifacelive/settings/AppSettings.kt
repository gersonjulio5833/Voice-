package app.aifacelive.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Qualidade de processamento: define a resolução pedida à câmara (análise + render). */
enum class Quality(val label: String, val hint: String, val width: Int, val height: Int) {
    ECONOMY("Económico", "480 × 640 · menor carga, ideal para telemóveis antigos", 480, 640),
    BALANCED("Equilibrado", "720 × 960 · bom equilíbrio (recomendado)", 720, 960),
    MAX("Máximo", "1080 × 1440 · mais nítido, exige um telemóvel recente", 1080, 1440),
}

/** Delegate do MediaPipe. CPU é sempre suportado; GPU é tentado e cai para CPU se falhar. */
enum class Acceleration(val label: String, val hint: String) {
    CPU("CPU", "Mais compatível em qualquer telemóvel Android"),
    GPU("GPU", "Pode ser mais rápido; volta automaticamente à CPU se não for suportado"),
}

enum class Lens(val label: String) {
    FRONT("Frontal"),
    BACK("Traseira"),
}

data class AppSettings(
    val quality: Quality = Quality.BALANCED,
    val acceleration: Acceleration = Acceleration.CPU,
    val lens: Lens = Lens.FRONT,
    val showHud: Boolean = true,
    val mirror: Boolean = true,
    val rotation: Int = 0,
)

/** Persistência simples (SharedPreferences) das definições. Sem dados pessoais. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("ai_face_live_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(_state.value)
        _state.value = next
        prefs.edit()
            .putString(KEY_QUALITY, next.quality.name)
            .putString(KEY_ACCELERATION, next.acceleration.name)
            .putString(KEY_LENS, next.lens.name)
            .putBoolean(KEY_HUD, next.showHud)
            .putBoolean(KEY_MIRROR, next.mirror)
            .putInt(KEY_ROTATION, next.rotation)
            .apply()
    }

    private fun read(): AppSettings = AppSettings(
        quality = enumOrDefault(prefs.getString(KEY_QUALITY, null), Quality.BALANCED),
        acceleration = enumOrDefault(prefs.getString(KEY_ACCELERATION, null), Acceleration.CPU),
        lens = enumOrDefault(prefs.getString(KEY_LENS, null), Lens.FRONT),
        showHud = prefs.getBoolean(KEY_HUD, true),
        mirror = prefs.getBoolean(KEY_MIRROR, true),
        rotation = prefs.getInt(KEY_ROTATION, 0),
    )

    private inline fun <reified T : Enum<T>> enumOrDefault(raw: String?, default: T): T =
        if (raw == null) default else runCatching { enumValueOf<T>(raw) }.getOrDefault(default)

    private companion object {
        const val KEY_QUALITY = "quality"
        const val KEY_ACCELERATION = "acceleration"
        const val KEY_LENS = "lens"
        const val KEY_HUD = "show_hud"
        const val KEY_MIRROR = "mirror"
        const val KEY_ROTATION = "rotation"
    }
}
