package app.aifacelive.face

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.hypot
import kotlin.random.Random

/** Testes unitários JVM da triangulação (correm no GitHub Actions sem emulador). */
class DelaunayTest {

    @Test
    fun squareWithCenterGivesFourTriangles() {
        val x = doubleArrayOf(0.0, 10.0, 10.0, 0.0, 5.0)
        val y = doubleArrayOf(0.0, 0.0, 10.0, 10.0, 5.0)
        val triangles = Delaunay.triangulate(x, y)
        assertEquals(4, triangles.size)
        triangles.forEach { tri ->
            tri.forEach { idx -> assertTrue(idx in 0..4) }
        }
    }

    @Test
    fun trianglesAreDelaunay() {
        val random = Random(42)
        val n = 80
        val x = DoubleArray(n) { random.nextDouble(0.0, 100.0) }
        val y = DoubleArray(n) { random.nextDouble(0.0, 100.0) }
        val triangles = Delaunay.triangulate(x, y)
        assertTrue(triangles.isNotEmpty())

        // Propriedade de Delaunay: nenhum ponto está estritamente dentro do círculo circunscrito.
        for (tri in triangles) {
            val (cx, cy, r) = circumcircle(
                x[tri[0]], y[tri[0]],
                x[tri[1]], y[tri[1]],
                x[tri[2]], y[tri[2]],
            )
            for (p in 0 until n) {
                if (p in tri) continue
                val d = hypot(x[p] - cx, y[p] - cy)
                assertFalse("ponto $p dentro do círculo de $tri", d < r - 1e-6)
            }
        }
    }

    @Test
    fun landmarkTriangulationUsesValidIndices() {
        val count = 478
        val random = Random(7)
        val points = FloatArray(count * 2) { random.nextFloat() }
        val triangles = Delaunay.triangulateLandmarks(points, 640, 480)
        assertEquals(0, triangles.size % 3)
        assertTrue(triangles.size >= 3 * (count - 2))
        assertTrue(triangles.all { it >= 0 && it < count })
    }

    private fun circumcircle(ax: Double, ay: Double, bx: Double, by: Double, cx: Double, cy: Double): Triple<Double, Double, Double> {
        val d = 2.0 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
        val a2 = ax * ax + ay * ay
        val b2 = bx * bx + by * by
        val c2 = cx * cx + cy * cy
        val ux = (a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d
        val uy = (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d
        return Triple(ux, uy, hypot(ax - ux, ay - uy))
    }
}
