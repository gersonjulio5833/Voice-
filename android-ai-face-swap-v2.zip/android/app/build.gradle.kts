import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// ---------------------------------------------------------------------------
// Modelo MediaPipe Face Landmarker (≈4 MB, licença Apache 2.0 da Google).
// Não é versionado no Git: é descarregado automaticamente antes do build.
// ---------------------------------------------------------------------------
val faceModelUrl =
    "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task"
val faceModelFile = file("src/main/assets/face_landmarker.task")

val downloadFaceModel by tasks.registering {
    outputs.file(faceModelFile)
    outputs.upToDateWhen { faceModelFile.exists() && faceModelFile.length() > 1_000_000L }
    doLast {
        faceModelFile.parentFile.mkdirs()
        logger.lifecycle("A transferir modelo MediaPipe Face Landmarker...")
        URL(faceModelUrl).openStream().use { input ->
            faceModelFile.outputStream().use { output -> input.copyTo(output) }
        }
        check(faceModelFile.length() > 1_000_000L) { "Modelo descarregado incompleto." }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(downloadFaceModel)
}

android {
    namespace = "app.aifacelive"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.aifacelive"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        ndk {
            // MediaPipe traz bibliotecas nativas. Estas duas ABIs cobrem praticamente todos os telemóveis
            // Android (64 e 32 bits). Emuladores x86 ficam de fora para reduzir o tamanho do APK.
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = false
            // Assinado com a chave de debug para poder ser instalado sem configurar keystore.
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/versions/9/previous-compilation-data.bin"
            )
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2025.12.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.4")
    implementation("androidx.navigation:navigation-compose:2.9.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // CameraX: captura de frames (formato RGBA) para o motor de face swap
    val cameraX = "1.5.3"
    implementation("androidx.camera:camera-core:$cameraX")
    implementation("androidx.camera:camera-camera2:$cameraX")
    implementation("androidx.camera:camera-lifecycle:$cameraX")

    // MediaPipe Tasks Vision: Face Landmarker (478 pontos, blendshapes)
    implementation("com.google.mediapipe:tasks-vision:0.10.29")

    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.core:core:1.16.0")

    testImplementation("junit:junit:4.13.2")
}
