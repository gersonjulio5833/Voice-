# AI Face Live — projeto Android (Kotlin)

Aplicação Android nativa que faz **troca de rosto em tempo real** a partir de uma fotografia da galeria,
com acompanhamento de cabeça, boca, olhos, sobrancelhas e sorriso. Sem root, sem desbloquear o bootloader,
sem formatar o telemóvel e sem enviar imagens para a internet.

> **Leia primeiro a secção "O que funciona e o que não funciona".**
> Integrar o efeito dentro de chamadas do WhatsApp ou do Messenger **não é possível** sem root.

---

## 1. Estrutura do projeto

```
android/
├── settings.gradle.kts            Nome do projeto e repositórios
├── build.gradle.kts               Versões dos plugins (AGP 8.13.2, Kotlin 2.2.21)
├── gradle.properties              Memória do Gradle e opções AndroidX
├── gradle/wrapper/gradle-wrapper.properties   Gradle 8.13
├── app/
│   ├── build.gradle.kts           Dependências, SDK 26–35, ABIs ARM, download do modelo
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml   Permissão: só CAMERA
│       │   ├── assets/               (face_landmarker.task é descarregado no build)
│       │   ├── res/                  Tema, ícone adaptativo, FileProvider
│       │   └── java/app/aifacelive/
│       │       ├── MainActivity.kt
│       │       ├── AppViewModel.kt        Estado central da app
│       │       ├── settings/AppSettings.kt  Qualidade, delegate, câmara, HUD, espelho
│       │       ├── engine/FaceSwapEngine.kt CameraX → MediaPipe → renderer
│       │       ├── face/FaceTracker.kt      Face Landmarker (VIDEO e IMAGE)
│       │       ├── face/Delaunay.kt         Malha de 478 pontos (Bowyer–Watson)
│       │       ├── face/SourcePhoto.kt      Fotografia de origem preparada
│       │       ├── render/FaceSwapRenderer.kt  OpenGL ES 2.0: fundo + malha deformada
│       │       ├── capture/SnapshotSaver.kt    Snapshot com marca "SIMULAÇÃO" + partilha
│       │       ├── util/                    Compatibilidade, permissões, imagens EXIF
│       │       └── ui/                      Compose: ecrãs e componentes
│       └── test/java/app/aifacelive/face/DelaunayTest.kt   Testes unitários
└── README.md
```

Workflow de compilação: `../.github/workflows/android-build.yml` (tem de estar na raiz do repositório).

---

## 2. Como funciona o efeito

1. **Fotografia de origem**: a foto escolhida passa pelo Face Landmarker do MediaPipe (478 pontos).
   A malha de Delaunay liga esses pontos.
2. **Câmara ao vivo**: CameraX entrega frames RGBA. Cada frame é analisado pelo MediaPipe, que devolve
   os 478 pontos do rosto atual e os *blendshapes* (abertura da boca, piscar, sorriso, sobrancelhas).
3. **Render**: o OpenGL ES desenha o frame da câmara ao fundo e, por cima, a fotografia de origem
   numa malha cujos vértices seguem os pontos do rosto atual. Assim, a fotografia acompanha a posição,
   a inclinação, a boca e os olhos.

**Limitação técnica importante:** isto é uma **deformação geométrica** (warp), não um modelo generativo.
Não há mudança de iluminação, de cor de pele nem de cabelo, e a boca aberta pode ficar com textura esticada.
Um face swap fotorrealista exige um modelo de IA treinado (ex.: InsightFace/inswapper) com licença que permita
o uso pretendido. **Esse modelo não está incluído.** A arquitetura já está preparada para o receber no
`FaceSwapRenderer` (a textura da fotografia pode ser substituída por uma saída de inferência TFLite).

---

## 3. Compilar o APK com GitHub Actions (sem computador)

### Passo 1 — Criar o repositório
1. Entra em <https://github.com> e cria um repositório novo (pode ser **privado**).
2. Clica em **Add file → Upload files**.
3. Carrega **toda a pasta do projeto** (incluindo `android/` e `.github/`).
   - Na pasta `.github/workflows/` tem de ficar o ficheiro `android-build.yml`.
   - Se o GitHub não mostrar a pasta `.github`, verifica que o ficheiro está em `.github/workflows/`.
4. Clica em **Commit changes**.

### Passo 2 — Executar a compilação
1. No repositório, abre o separador **Actions**.
2. Se aparecer um aviso, clica em **I understand my workflows, go ahead and enable them**.
3. Escolhe **Build AI Face Live APK** no menu da esquerda.
4. Clica em **Run workflow** → **Run workflow**.
   (Também corre automaticamente em cada alteração à pasta `android/`.)
5. Aguarda 5 a 10 minutos. Fica verde ✅ quando termina.

### Passo 3 — Descarregar o APK
1. Abre a execução concluída.
2. Em **Artifacts**, descarrega **ai-face-live-debug** (um ficheiro ZIP).
3. No telemóvel, extrai o ZIP (com o gestor de ficheiros ou o browser) e obtém `app-debug.apk`.

> Se o artifact não aparecer, abre o passo **Compilar APK debug** para ver o erro.

---

## 4. Instalar no telemóvel

Requisitos: Android **8.0 (API 26)** ou superior, câmara frontal, de preferência 3 GB de RAM ou mais.

1. Abre **Definições → Segurança** (ou **Privacidade**) e ativa **Instalar apps de fontes desconhecidas**
   para o browser ou para o gestor de ficheiros que vais usar. (Em Android 8+ isto é feito por app.)
2. Abre o ficheiro `app-debug.apk` e toca em **Instalar**.
3. Se o Google Play Protect bloquear, toca em **Instalar mesmo assim** (é uma app de desenvolvimento,
   não publicada na Play Store). Confirma sempre que o APK veio do **teu** repositório.
4. Depois de instalar, **desativa de novo** a instalação de fontes desconhecidas.
5. Abre **AI Face Live**. Quando a app pedir acesso à câmara, aceita.

**Nome da app instalada:** `AI Face Live` (identificador `app.aifacelive.debug`).
Pode coexistir com outra versão.

**Se a instalação falhar com "App não instalada":** desinstala a versão anterior de AI Face Live
e tenta de novo.

**Desinstalar:** Definições → Apps → AI Face Live → Desinstalar. Nada mais é alterado no telemóvel.

---

## 5. Como usar

1. **Começar** → **Selecionar foto** → **Escolher da galeria**.
   Escolhe uma fotografia frontal, com boa luz e apenas uma pessoa.
   Marca a caixa de autorização e toca em **Confirmar fotografia**.
2. **Pré-visualização**: a câmara abre com o efeito ativo.
   - **Interruptor**: liga e desliga o efeito.
   - **Painel de expressões**: boca, olhos, sorriso e sobrancelhas em tempo real (ligar/desligar nas definições).
   - **Guardar**: grava um snapshot com marca "SIMULAÇÃO" na galeria (Imagens › AI Face Live) e abre o
     seletor de partilha do Android, onde podes enviar a imagem para o WhatsApp, Messenger, etc.
     **Isto envia uma fotografia, não a chamada em direto.**
3. **Definições**: câmara frontal ou traseira, qualidade (Económico / Equilibrado / Máximo),
   desempenho (CPU ou GPU), espelho e permissões.
4. **Compatibilidade**: mostra os dados do aparelho e executa testes reais:
   OpenGL ES, câmaras, memória, processador, carregamento do modelo MediaPipe e deteção na fotografia.

---

## 6. O que funciona e o que não funciona

| Pedido | Estado | Explicação |
|---|---|---|
| Escolher foto da galeria | ✅ Implementado | Seletor de fotos do Android (sem permissão de galeria). |
| Pré-visualizar o efeito com a câmara | ✅ Implementado | CameraX + MediaPipe + OpenGL ES 2.0. |
| Acompanhar cabeça, boca, olhos, expressões | ✅ Implementado | 478 landmarks + blendshapes do MediaPipe. |
| Ativar/desativar e trocar foto | ✅ Implementado | Interruptor e botão "Alterar foto". |
| Qualidade e desempenho configuráveis | ✅ Implementado | Resolução, CPU/GPU, fallback automático. |
| Seleção de câmara | ✅ Implementado | Frontal ou traseira. |
| Snapshot com marca de simulação | ✅ Implementado | Galeria + partilha pelo Android. |
| Vídeo processado dentro do WhatsApp/Messenger | ❌ Não possível | Sem root, nenhuma app pode substituir a câmara usada por outra. Qualquer app que prometa isso sem root é enganosa. |
| Face swap fotorrealista (iluminação, cor, cabelo) | ⚠️ Não incluído | Requer um modelo de IA treinado e licenciado. A arquitetura está preparada. |
| Gravação de vídeo com o efeito | ⚠️ Não implementado | Só snapshots. |

**Alternativa realista para chamadas:** uma videochamada própria (WebRTC) dentro desta app, em que a app
controla a câmara e o frame. Não está incluída nesta versão.

---

## 7. Testes realizados e honestidade sobre o que foi validado

**Validado nesta entrega:**
- Compilação do APK debug com **AGP 8.13.2, Kotlin 2.2.21, Gradle 8.13, JDK 17 e Android SDK 35**.
- Testes unitários da triangulação de Delaunay (3/3 passam), incluindo a propriedade de Delaunay
  sobre 80 pontos aleatórios.
- Assinatura do APK verificada (esquema v2) e permissões confirmadas (`CAMERA` apenas).
- Modelo `face_landmarker.task` (3,7 MB) incluído no APK.

**Não validado (precisa de um telemóvel real):**
- Execução no dispositivo: a app **não foi instalada nem testada num telemóvel ou emulador** nesta sessão.
- Qualidade do tracking e do warp em diferentes câmaras e iluminações.
- Desempenho (FPS e latência) em aparelhos de gama baixa, média e alta.
- Comportamento da GPU delegate do MediaPipe (fica por defeito em CPU, por ser o mais compatível).

**Testes de compatibilidade:** ao abrir **Compatibilidade → Executar testes**, a app mede o próprio aparelho.
Se algum teste falhar, o resultado diz qual e porquê. Envia esses resultados se encontrares um problema.

---

## 8. Resolução de problemas

| Sintoma | Causa provável | Solução |
|---|---|---|
| Workflow falha em "Compilar APK debug" com erro de download | GitHub sem acesso a `storage.googleapis.com` (raro) | Executa de novo (**Re-run jobs**). |
| "Não encontrámos nenhum rosto" | Foto com rosto pequeno, de perfil ou escura | Usa uma foto frontal, bem iluminada e com o rosto ocupando boa parte da imagem. |
| "Câmara indisponível" | Permissão negada ou câmara ocupada por outra app | Definições → Permissões → Câmara; fecha outras apps de câmara. |
| FPS baixos | Aparelho antigo ou qualidade alta | Definições → Qualidade → **Económico**. |
| Aviso "GPU não suportada" | GPU delegate não disponível | É normal; a app passa a CPU automaticamente. |
| Efeito "tremido" | Rosto parcialmente fora do ecrã ou pouca luz | Melhora a iluminação e mantém o rosto centrado. |

---

## 9. Para desenvolvedores

**Compilar localmente (opcional):** instala JDK 17 e o Android SDK 35 e corre:
```bash
cd android
gradle wrapper --gradle-version 8.13   # gera gradlew (uma vez)
./gradlew :app:testDebugUnitTest :app:assembleDebug
```
O APK fica em `app/build/outputs/apk/debug/app-debug.apk`.
O Gradle descarrega automaticamente o modelo `face_landmarker.task` antes do build (tarefa `downloadFaceModel`).

**Alterar a versão:** `app/build.gradle.kts` → `versionCode` e `versionName`.

**Trocar o motor de face swap:** substitui a textura da fotografia em `FaceSwapRenderer.uploadSource`
por uma saída de inferência (TFLite) alinhada com os 478 landmarks; a malha e o pipeline de câmara mantêm-se.

**Uso responsável:** usa apenas fotografias de pessoas que deram autorização. Mantém a marca de simulação
nos snapshots. Não uses para impersonação, fraude ou conteúdo não consentido.
