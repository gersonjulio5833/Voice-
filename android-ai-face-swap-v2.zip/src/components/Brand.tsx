type LogoMarkProps = {
  className?: string;
  /** Show the rounded gradient app tile around the mark. */
  tile?: boolean;
};

export function LogoMark({ className = "h-10 w-10", tile = true }: LogoMarkProps) {
  const mark = (
    <svg viewBox="0 0 48 48" fill="none" aria-hidden="true" className="h-full w-full">
      <path
        d="M8.5 16.5v-4a4 4 0 0 1 4-4h4M31.5 8.5h4a4 4 0 0 1 4 4v4M39.5 31.5v4a4 4 0 0 1-4 4h-4M16.5 39.5h-4a4 4 0 0 1-4-4v-4"
        stroke="white"
        strokeWidth="1.9"
        strokeLinecap="round"
      />
      <path
        d="M24 11.8c-6.1 0-10 4.3-10 11.6 0 4.9 1.9 8 5 9.5l.4 3.6h9.2l.4-3.6c3.1-1.5 5-4.6 5-9.5 0-7.3-3.9-11.6-10-11.6Z"
        stroke="white"
        strokeWidth="1.65"
        strokeLinejoin="round"
      />
      <path
        d="M18.2 22.2h2.2M27.6 22.2h2.2M24 22.2v4.6l-1.7 1.3M20.8 31c1.9 1.3 4.5 1.3 6.4 0"
        stroke="white"
        strokeWidth="1.45"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="19.3" cy="24.3" r="0.95" fill="#67e8f9" />
      <circle cx="28.7" cy="24.3" r="0.95" fill="#67e8f9" />
      <circle cx="13.6" cy="20.8" r="0.7" fill="#a78bfa" />
      <circle cx="34.4" cy="20.8" r="0.7" fill="#a78bfa" />
      <path d="M10.4 26.5h1.2M36.4 26.5h1.2" stroke="white" strokeOpacity=".6" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );

  if (!tile) {
    return <div className={className}>{mark}</div>;
  }

  return (
    <div
      className={`${className} relative overflow-hidden rounded-[30%] border border-white/20 bg-gradient-to-br from-[#8b6cff] via-[#5e4bff] to-[#2f7dff] p-[18%] shadow-[0_8px_28px_-8px_rgba(109,86,255,0.9)]`}
    >
      <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/25" />
      <div className="absolute -right-3 -top-3 h-8 w-8 rounded-full bg-cyan-300/25 blur-md" />
      {mark}
    </div>
  );
}

export function Wordmark({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <LogoMark className="h-9 w-9 shrink-0" />
      <div className="leading-none">
        <div className="font-display text-[15px] font-bold tracking-[0.02em] text-white">
          AI Face <span className="text-gradient">Live</span>
        </div>
        <div className="mt-1 font-mono text-[8px] uppercase tracking-[0.24em] text-white/52">
          Real-time face studio
        </div>
      </div>
    </div>
  );
}
