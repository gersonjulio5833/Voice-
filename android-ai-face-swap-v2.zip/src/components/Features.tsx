import type { ReactNode } from "react";
import {
  ArrowUpRight,
  Check,
  Cpu,
  Fingerprint,
  Gauge,
  Lock,
  ScanFace,
  ShieldCheck,
  SlidersHorizontal,
  Smartphone,
  SmartphoneNfc,
  Sparkles,
} from "lucide-react";
import { faces } from "@/data/content";
import { SectionHeading, StatusPill } from "@/components/ui";
import { cn } from "@/utils/cn";

export function Features() {
  return (
    <section id="produto" className="relative scroll-mt-24 py-20 sm:py-24">
      <div className="wrap">
        <SectionHeading
          eyebrow="O produto"
          title={
            <>
              Tudo o que precisas.
              <br />
              <span className="text-white/52">Nada de atalhos falsos.</span>
            </>
          }
          description="Uma app Android desenhada em torno de um pipeline real: câmara, landmarks, inferência local e renderização na GPU. Sem root, sem uploads e sem depender de uma única marca."
          aside={
            <a href="#demo" className="group inline-flex items-center gap-2 text-[12px] font-bold text-electric-soft transition hover:text-white">
              Ver em funcionamento
              <span className="flex h-7 w-7 items-center justify-center rounded-full border border-electric-soft/25 bg-electric/10 transition group-hover:bg-electric/20">
                <ArrowUpRight size={13} />
              </span>
            </a>
          }
        />

        <div className="mt-10 grid gap-3.5 lg:grid-cols-12">
          {/* Featured card */}
          <div className="card group relative overflow-hidden p-5 sm:p-7 lg:col-span-7 lg:row-span-2">
            <div className="pointer-events-none absolute -right-20 -top-24 h-56 w-56 rounded-full bg-electric/20 blur-3xl transition duration-500 group-hover:bg-electric/30" />
            <div className="pointer-events-none absolute -bottom-20 -left-16 h-48 w-48 rounded-full bg-aqua/10 blur-3xl" />

            <div className="relative">
              <div className="flex items-center justify-between">
                <span className="mono-label flex items-center gap-1.5">
                  <Sparkles size={11} className="text-electric-soft" />
                  Face engine
                </span>
                <StatusPill tone="info" dot>pipeline local</StatusPill>
              </div>

              <h3 className="mt-4 max-w-[420px] font-display text-[1.55rem] font-semibold leading-tight tracking-[-0.03em] text-white sm:text-[1.8rem]">
                A fotografia fica.
                <br />
                <span className="text-gradient">O rosto acompanha-te.</span>
              </h3>
              <p className="mt-3 max-w-[440px] text-[12.5px] leading-relaxed text-white/45">
                A expressão é tua; o rosto vem da fotografia. O pipeline alinha a fonte à pose atual
                em cada frame e mistura a cor para o resultado não parecer colado.
              </p>

              <div className="relative mt-5 overflow-hidden rounded-2xl border border-white/[0.08] bg-black/25 p-3">
                <div className="pointer-events-none absolute inset-0 bg-grid opacity-20" />
                <div className="relative flex items-stretch gap-2.5">
                  <div className="flex w-[46px] shrink-0 flex-col gap-2">
                    {faces.slice(0, 3).map((f, i) => (
                      <div
                        key={f.id}
                        className={cn(
                          "relative overflow-hidden rounded-lg border transition",
                          i === 0
                            ? "border-electric-soft/70 shadow-[0_0_0_2px_rgba(124,92,255,0.2)]"
                            : "border-white/10 opacity-65"
                        )}
                      >
                        <img src={f.thumb} alt="" className="aspect-[4/5] w-full object-cover object-top" loading="lazy" />
                        {i === 0 ? (
                          <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-mint" />
                        ) : null}
                      </div>
                    ))}
                    <span className="flex h-7 items-center justify-center rounded-lg border border-dashed border-white/15 text-[10px] font-bold text-white/45">
                      +3
                    </span>
                  </div>

                  <div className="relative min-w-0 flex-1 overflow-hidden rounded-xl border border-white/12">
                    <img
                      src={faces[0].url}
                      alt="Exemplo de rosto selecionado para a transformação"
                      className="h-full min-h-[172px] w-full object-cover object-top"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                    <div className="absolute left-1/2 top-[42%] h-[46%] w-[46%] -translate-x-1/2 -translate-y-1/2 rounded-[45%] border border-aqua/60">
                      <span className="absolute -left-0.5 -top-0.5 h-2 w-2 border-l-2 border-t-2 border-aqua" />
                      <span className="absolute -right-0.5 -top-0.5 h-2 w-2 border-r-2 border-t-2 border-aqua" />
                      <span className="absolute -bottom-0.5 -left-0.5 h-2 w-2 border-b-2 border-l-2 border-aqua" />
                      <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 border-b-2 border-r-2 border-aqua" />
                      <span className="absolute left-1/2 top-1/2 h-px w-[130%] -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-transparent via-aqua/80 to-transparent" />
                      {[
                        ["20%", "38%"], ["80%", "38%"], ["50%", "54%"],
                        ["32%", "72%"], ["68%", "72%"], ["50%", "88%"],
                      ].map(([left, top]) => (
                        <span
                          key={`${left}-${top}`}
                          className="absolute h-1 w-1 rounded-full bg-cyan-200 shadow-[0_0_6px_rgba(103,232,249,0.9)]"
                          style={{ left, top }}
                        />
                      ))}
                    </div>
                    <div className="absolute inset-x-2 bottom-2 flex flex-wrap items-center gap-1">
                      {["olhos", "boca", "sobrancelhas"].map((label) => (
                        <span
                          key={label}
                          className="rounded-full border border-white/12 bg-black/40 px-1.5 py-0.5 font-mono text-[6.5px] uppercase tracking-wider text-white/65 backdrop-blur"
                        >
                          {label}
                        </span>
                      ))}
                    </div>
                    <span className="absolute right-2 top-2 rounded-full border border-mint/25 bg-black/50 px-1.5 py-0.5 font-mono text-[6px] uppercase tracking-[0.12em] text-mint backdrop-blur">
                      sync
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2">
                {["Expressões acompanhadas", "Alinhamento por frame", "Correção de mistura"].map((item) => (
                  <span key={item} className="inline-flex items-center gap-1 text-[9.5px] font-semibold text-white/45">
                    <Check size={10} className="text-mint" />
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Tracking */}
          <FeatureCard
            className="lg:col-span-5"
            icon={<ScanFace size={17} />}
            eyebrow="MediaPipe"
            title="Tracking de expressões"
            body="A malha facial acompanha os movimentos que interessam numa chamada."
          >
            <div className="mt-4 space-y-2">
              {[
                { label: "Olhos e pestanas", width: "96%" },
                { label: "Abertura da boca", width: "92%" },
                { label: "Inclinação da cabeça", width: "98%" },
              ].map((row) => (
                <div key={row.label} className="flex items-center gap-2.5">
                  <span className="w-[124px] shrink-0 text-[10px] font-medium text-white/45">{row.label}</span>
                  <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/[0.08]">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-electric to-aqua opacity-70"
                      style={{ width: row.width }}
                    />
                  </div>
                  <span className="font-mono text-[8px] text-white/32">{row.width}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 font-mono text-[8px] uppercase tracking-[0.12em] text-white/20">
              Capacidade do pipeline · não é uma medição
            </p>
          </FeatureCard>

          {/* Privacy */}
          <div className="card group relative overflow-hidden p-5 lg:col-span-5">
            <div className="pointer-events-none absolute -right-14 -top-14 h-40 w-40 rounded-full bg-mint/10 blur-3xl" />
            <div className="relative">
              <div className="flex items-center justify-between">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-mint/20 bg-mint/[0.08] text-mint">
                  <ShieldCheck size={17} />
                </div>
                <StatusPill tone="success" dot>on-device</StatusPill>
              </div>
              <h3 className="mt-4 font-display text-[1.05rem] font-semibold tracking-tight text-white">Privado por defeito</h3>
              <div className="mt-3 flex items-end gap-4">
                <div className="relative flex h-16 w-16 shrink-0 items-center justify-center rounded-full border-[5px] border-white/[0.07]">
                  <div className="absolute inset-[-5px] rounded-full border-[5px] border-transparent border-t-mint/70 border-r-mint/30" />
                  <div className="text-center">
                    <span className="block font-display text-lg font-semibold leading-none text-white">0</span>
                    <span className="font-mono text-[6px] uppercase tracking-wider text-white/45">uploads</span>
                  </div>
                </div>
                <div className="min-w-0">
                  <p className="text-[11.5px] leading-relaxed text-white/45">
                    Fotografia, landmarks e frames ficam na memória do dispositivo. Sem conta, sem
                    servidor e sem telemetria de imagem.
                  </p>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {["Sem conta", "Sem cloud", "Sem root"].map((t) => (
                  <span key={t} className="inline-flex items-center gap-1 rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-1 font-mono text-[7.5px] uppercase tracking-wider text-white/45">
                    <Lock size={8} />
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <FeatureCard
            className="lg:col-span-4"
            icon={<Cpu size={17} />}
            eyebrow="Render pipeline"
            title="GPU em primeiro"
            body="OpenGL ES para warp e blending; TFLite com delegates para a inferência."
          >
            <div className="mt-4 grid grid-cols-2 gap-1.5">
              {["OpenGL ES 3.0", "TFLite GPU", "CameraX", "EGL / GLES"].map((tag) => (
                <span key={tag} className="rounded-lg border border-white/[0.08] bg-white/[0.03] px-2 py-1.5 text-center font-mono text-[8px] text-white/52">
                  {tag}
                </span>
              ))}
            </div>
          </FeatureCard>

          <FeatureCard
            className="lg:col-span-4"
            icon={<SmartphoneNfc size={17} />}
            eyebrow="Compatibilidade"
            title="Vários fabricantes"
            body="Sem dependência de uma marca. CameraX abstrai as diferenças entre câmaras."
          >
            <div className="mt-4 rounded-lg border border-white/[0.07] bg-white/[0.025] p-2.5">
              <div className="flex justify-between font-mono text-[7.5px] uppercase tracking-wider text-white/32">
                <span>API 26</span>
                <span>API 35</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                <div className="h-full w-[86%] rounded-full bg-gradient-to-r from-electric to-aqua" />
              </div>
              <p className="mt-2 text-[8.5px] text-white/42">Android 8.0 → Android 15 · validação por dispositivo</p>
            </div>
          </FeatureCard>

          <FeatureCard
            className="lg:col-span-4"
            icon={<Gauge size={17} />}
            eyebrow="Desempenho"
            title="Adapta-se ao telemóvel"
            body="Qualidade, resolução e frequência ajustáveis para não transformar a chamada num slideshow."
          >
            <div className="mt-4 flex gap-1.5">
              {[
                { label: "Eco", active: false },
                { label: "Médio", active: true },
                { label: "Máx.", active: false },
              ].map((p) => (
                <span
                  key={p.label}
                  className={cn(
                    "flex-1 rounded-lg border px-2 py-2 text-center font-mono text-[8px] uppercase tracking-wider",
                    p.active
                      ? "border-electric-soft/40 bg-electric/15 text-white"
                      : "border-white/[0.07] bg-white/[0.02] text-white/42"
                  )}
                >
                  {p.label}
                </span>
              ))}
            </div>
          </FeatureCard>
        </div>

        {/* Small feature strip */}
        <div className="mt-3.5 grid gap-3.5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: Fingerprint, title: "Identidade visual", body: "Marca de simulação e consentimento visível." },
            { icon: SlidersHorizontal, title: "Controlo fino", body: "Intensidade, espelho, câmara e tracking." },
            { icon: Sparkles, title: "Sem filtros falsos", body: "O que a app mostra é o que o pipeline gera." },
            { icon: Smartphone, title: "Instalação simples", body: "APK de debug gerado pelo GitHub Actions." },
          ].map(({ icon: Icon, title, body }) => (
            <div key={title} className="flex gap-3 rounded-2xl border border-white/[0.06] bg-white/[0.018] p-4">
              <Icon size={15} className="mt-0.5 shrink-0 text-electric-soft/70" />
              <div>
                <p className="text-[11.5px] font-bold text-white/70">{title}</p>
                <p className="mt-1 text-[10px] leading-relaxed text-white/42">{body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FeatureCard({
  icon,
  eyebrow,
  title,
  body,
  children,
  className,
}: {
  icon: ReactNode;
  eyebrow: string;
  title: string;
  body: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("card group relative overflow-hidden p-5 transition duration-300 hover:border-white/[0.15]", className)}>
      <div className="pointer-events-none absolute -right-14 -top-14 h-32 w-32 rounded-full bg-electric/10 opacity-0 blur-2xl transition duration-500 group-hover:opacity-100" />
      <div className="relative">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/[0.045] text-electric-soft">
          {icon}
        </div>
        <p className="mono-label mt-4">{eyebrow}</p>
        <h3 className="mt-1 font-display text-[1.05rem] font-semibold tracking-tight text-white">{title}</h3>
        <p className="mt-2 text-[11.5px] leading-relaxed text-white/52">{body}</p>
        {children}
      </div>
    </div>
  );
}
