import { useEffect, useState } from "react";
import {
  BatteryFull,
  MoreHorizontal,
  Mic,
  MicOff,
  PhoneOff,
  ShieldCheck,
  Signal,
  Sparkles,
  Video,
  VideoOff,
  Wifi,
  X,
} from "lucide-react";
import type { FaceSample } from "@/data/content";
import { feedImage } from "@/data/content";
import { FaceScanOverlay, Toggle } from "@/components/ui";
import { LogoMark } from "@/components/Brand";
import { cn } from "@/utils/cn";

type PhoneMockupProps = {
  face: FaceSample;
  swap: boolean;
  onSwapChange: (next: boolean) => void;
  tracking?: boolean;
  intensity?: number;
  mirror?: boolean;
  className?: string;
  compactControls?: boolean;
};

function formatTimer(total: number) {
  const mins = Math.floor(total / 60)
    .toString()
    .padStart(2, "0");
  const secs = (total % 60).toString().padStart(2, "0");
  return `${mins}:${secs}`;
}

export function PhoneMockup({
  face,
  swap,
  onSwapChange,
  tracking = true,
  intensity = 82,
  mirror = true,
  className,
  compactControls = false,
}: PhoneMockupProps) {
  const [muted, setMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(false);
  const [ended, setEnded] = useState(false);
  const [seconds, setSeconds] = useState(24);

  useEffect(() => {
    if (ended) return;
    const id = window.setInterval(() => {
      setSeconds((s) => (s >= 3599 ? 0 : s + 1));
    }, 1000);
    return () => window.clearInterval(id);
  }, [ended]);

  const mainImage = swap ? face.url : feedImage;
  const pipImage = swap ? feedImage : face.url;
  const pipLabel = swap ? "câmara" : "fonte";

  const resetCall = () => {
    setEnded(false);
    setMuted(false);
    setCameraOff(false);
    setSeconds(0);
  };

  return (
    <div className={cn("relative mx-auto w-full max-w-[332px]", className)}>
      <div className="pointer-events-none absolute -inset-10 -z-10 rounded-full bg-[radial-gradient(circle,rgba(124,92,255,0.24),transparent_66%)] blur-2xl" />

      <div className="phone-shell relative rounded-[3.25rem] bg-gradient-to-b from-[#3a3350] via-[#1b1630] to-[#0a0812] p-[7px]">
        {/* Physical buttons */}
        <div className="absolute -left-[2px] top-[118px] h-8 w-[3px] rounded-l bg-white/20" />
        <div className="absolute -left-[2px] top-[164px] h-12 w-[3px] rounded-l bg-white/15" />
        <div className="absolute -right-[2px] top-[140px] h-16 w-[3px] rounded-r bg-white/20" />

        <div className="relative aspect-[9/19.1] overflow-hidden rounded-[2.85rem] bg-[#080611]">
          {/* Camera feed / swapped result */}
          {!cameraOff ? (
            <img
              src={mainImage}
              alt={
                swap
                  ? `Pré-visualização simulada com a fotografia de ${face.name}`
                  : "Pré-visualização da câmara original"
              }
              className={cn(
                "absolute inset-0 h-full w-full object-cover object-top transition-opacity duration-500",
                mirror && "-scale-x-100"
              )}
              draggable={false}
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-[radial-gradient(circle_at_50%_35%,#211940,#080611_70%)] px-8 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full border border-white/10 bg-white/[0.04]">
                <VideoOff size={22} className="text-white/52" />
              </div>
              <p className="mt-4 text-xs font-bold text-white/80">Câmara desligada</p>
              <p className="mt-1 text-[10px] leading-relaxed text-white/45">
                O efeito continua pronto para quando voltares a ligar.
              </p>
            </div>
          )}

          <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/55 via-transparent to-black/90" />
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(4,2,10,0.5))]" />

          {tracking && swap && !cameraOff ? <FaceScanOverlay compact={compactControls} /> : null}

          {/* Dynamic island */}
          <div className="absolute left-1/2 top-2 z-30 h-[22px] w-[86px] -translate-x-1/2 rounded-full bg-black">
            <span className="absolute right-3 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-[#15132a] ring-1 ring-white/10" />
          </div>

          {/* Status bar */}
          <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex h-9 items-center justify-between px-5 pt-1.5">
            <span className="font-display text-[9px] font-semibold tracking-wide text-white/90">9:41</span>
            <div className="flex items-center gap-1 text-white/85">
              <Signal size={9} strokeWidth={2.6} />
              <Wifi size={9} strokeWidth={2.6} />
              <BatteryFull size={12} strokeWidth={2.2} />
            </div>
          </div>

          {/* Call header */}
          <div className="absolute inset-x-0 top-9 z-30 flex items-start justify-between px-3.5">
            <div className="flex items-center gap-2">
              <LogoMark className="h-7 w-7 rounded-lg" />
              <div>
                <p className="font-display text-[10.5px] font-semibold leading-tight text-white">
                  AI Face Live
                </p>
                <p className="mt-0.5 font-mono text-[8px] tracking-wide text-white/60">
                  demo · {formatTimer(seconds)}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <span className="rounded-full border border-white/15 bg-black/30 px-2 py-1 backdrop-blur-md">
                <LockIcon />
              </span>
              <span className="flex h-7 w-7 items-center justify-center rounded-full border border-white/15 bg-black/30 backdrop-blur-md">
                <MoreHorizontal size={12} className="text-white/80" />
              </span>
            </div>
          </div>

          {/* Simulation watermark */}
          <div className="absolute left-3.5 top-[78px] z-30 inline-flex items-center gap-1 rounded-full border border-amber-200/30 bg-black/40 px-2 py-1 backdrop-blur-md">
            <span className="h-1 w-1 rounded-full bg-amber-300" />
            <span className="font-mono text-[7px] uppercase tracking-[0.16em] text-amber-100/90">
              Simulação
            </span>
          </div>

          {/* Audio activity */}
          <div className="absolute right-3.5 top-[80px] z-30 flex items-end gap-[2px]" aria-hidden="true">
            {[5, 9, 6, 12, 8, 4].map((h, i) => (
              <span
                key={i}
                className="w-[2px] rounded-full bg-white/45"
                style={{
                  height: h,
                  animation: `pulse-soft ${1.1 + i * 0.15}s ease-in-out ${i * 0.08}s infinite`,
                }}
              />
            ))}
          </div>

          {/* Original source / camera PiP */}
          <div className="absolute right-3.5 top-[104px] z-30 w-[64px]">
            <div className="overflow-hidden rounded-xl border-2 border-white/70 bg-black shadow-[0_8px_20px_rgba(0,0,0,0.5)]">
              <img
                src={pipImage}
                alt={pipLabel}
                className="aspect-[3/4] w-full object-cover object-top"
                draggable={false}
              />
            </div>
            <p className="mt-1 text-center font-mono text-[6.5px] uppercase tracking-[0.14em] text-white/60">
              {pipLabel}
            </p>
          </div>

          {/* Source label */}
          <div className="absolute left-3.5 top-[46%] z-30 max-w-[140px]">
            <div className="inline-flex items-center gap-1.5 rounded-full border border-white/12 bg-black/35 px-2 py-1 backdrop-blur-md">
              <span className="h-1.5 w-1.5 rounded-full bg-mint" />
              <span className="font-mono text-[7.5px] uppercase tracking-[0.12em] text-white/75">
                {swap ? `rosto: ${face.name}` : "efeito desligado"}
              </span>
            </div>
          </div>

          {/* Call controls */}
          <div className="absolute inset-x-3 bottom-3 z-30">
            <div className="rounded-[1.3rem] border border-white/12 bg-[#0b0815]/72 p-2 shadow-[0_12px_40px_rgba(0,0,0,0.45)] backdrop-blur-xl">
              <div className="flex items-center gap-2 px-1">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-gradient-to-br from-electric to-azure">
                  <Sparkles size={11} className="text-white" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-bold leading-tight text-white">Face swap</p>
                  <p className="text-[8px] leading-tight text-white/45">
                    {swap ? "Efeito ativo · sincronizado" : "Efeito desativado"}
                  </p>
                </div>
                <Toggle
                  checked={swap}
                  onChange={onSwapChange}
                  label="Ativar face swap na pré-visualização"
                  size="sm"
                />
              </div>

              <div className="mt-1.5 h-[3px] overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-electric-soft to-aqua transition-all duration-500"
                  style={{ width: `${swap ? intensity : 0}%` }}
                />
              </div>

              <div className="mt-2 grid grid-cols-4 gap-1.5">
                <CallButton
                  active={!muted}
                  label={muted ? "Ativar microfone" : "Silenciar microfone"}
                  onClick={() => setMuted((v) => !v)}
                >
                  {muted ? <MicOff size={14} /> : <Mic size={14} />}
                </CallButton>
                <CallButton
                  active={!cameraOff}
                  label={cameraOff ? "Ligar câmara" : "Desligar câmara"}
                  onClick={() => setCameraOff((v) => !v)}
                >
                  {cameraOff ? <VideoOff size={14} /> : <Video size={14} />}
                </CallButton>
                <button
                  type="button"
                  onClick={() => setEnded(true)}
                  aria-label="Terminar chamada de demonstração"
                  className="flex h-9 items-center justify-center rounded-full bg-gradient-to-b from-[#f2445b] to-[#d91f3c] text-white shadow-[0_6px_18px_-4px_rgba(225,29,72,0.7)] transition hover:brightness-110 active:scale-95"
                >
                  <PhoneOff size={14} />
                </button>
                <CallButton label="Mais opções" onClick={() => setEnded(false)}>
                  <MoreHorizontal size={14} />
                </CallButton>
              </div>
            </div>

            <div className="mx-auto mt-2 h-1 w-24 rounded-full bg-white/40" />
          </div>

          {/* End-call overlay */}
          {ended ? (
            <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-[#080611]/92 px-6 text-center backdrop-blur-md">
              <LogoMark className="h-12 w-12" />
              <h3 className="mt-5 font-display text-base font-semibold text-white">Demonstração terminada</h3>
              <p className="mt-2 text-[10.5px] leading-relaxed text-white/50">
                Nenhuma chamada real foi feita. O vídeo desta demo nunca sai do browser.
              </p>
              <button
                type="button"
                onClick={resetCall}
                className="mt-5 rounded-full bg-white px-4 py-2 text-[11px] font-bold text-[#0b0815] transition hover:bg-white/90 active:scale-[0.98]"
              >
                Repetir demonstração
              </button>
              <button
                type="button"
                onClick={() => setEnded(false)}
                aria-label="Fechar ecrã de chamada terminada"
                className="mt-3 inline-flex items-center gap-1 text-[10px] text-white/52 hover:text-white/70"
              >
                <X size={11} /> Voltar à pré-visualização
              </button>
            </div>
          ) : null}
        </div>
      </div>

      <p className="mt-3 text-center font-mono text-[9px] uppercase tracking-[0.2em] text-white/42">
        Interface de demonstração
      </p>
    </div>
  );
}

function CallButton({
  children,
  label,
  onClick,
  active = true,
}: {
  children: React.ReactNode;
  label: string;
  onClick: () => void;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className={cn(
        "flex h-9 items-center justify-center rounded-full border transition active:scale-95",
        active
          ? "border-white/10 bg-white/12 text-white hover:bg-white/20"
          : "border-transparent bg-white text-[#0b0815] hover:bg-white/90"
      )}
    >
      {children}
    </button>
  );
}

function LockIcon() {
  return <ShieldCheck size={11} className="text-mint/90" />;
}
