import type { ReactNode } from "react";
import { cn } from "@/utils/cn";

export function Eyebrow({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <span className={cn("eyebrow text-electric-soft/90", className)}>
      <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-electric-soft to-aqua shadow-[0_0_10px_rgba(167,139,250,0.9)]" />
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  className,
  aside,
}: {
  eyebrow: string;
  title: ReactNode;
  description?: ReactNode;
  align?: "left" | "center";
  className?: string;
  aside?: ReactNode;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-5",
        align === "center" && "items-center text-center",
        aside && "lg:flex-row lg:items-end lg:justify-between",
        className
      )}
    >
      <div className={cn("max-w-2xl", align === "center" && "mx-auto")}>
        <Eyebrow>{eyebrow}</Eyebrow>
        <h2 className="section-title mt-4">{title}</h2>
        {description ? (
          <p className="body-copy mt-4 max-w-xl">{description}</p>
        ) : null}
      </div>
      {aside ? <div className="shrink-0">{aside}</div> : null}
    </div>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
  size = "md",
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  size?: "sm" | "md";
}) {
  const small = size === "sm";
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative shrink-0 rounded-full border transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-soft/70 focus-visible:ring-offset-2 focus-visible:ring-offset-night",
        small ? "h-5 w-9" : "h-[26px] w-[46px]",
        checked
          ? "border-transparent bg-gradient-to-r from-electric to-azure shadow-[0_0_18px_-4px_rgba(124,92,255,0.85)]"
          : "border-white/15 bg-white/10"
      )}
    >
      <span
        className={cn(
          "absolute top-1/2 -translate-y-1/2 rounded-full bg-white shadow-sm transition-all duration-200",
          small ? "h-3.5 w-3.5" : "h-5 w-5",
          checked ? (small ? "left-[18px]" : "left-[23px]") : "left-[3px]"
        )}
      />
    </button>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  label,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (next: T) => void;
  label: string;
}) {
  return (
    <div
      role="radiogroup"
      aria-label={label}
      className="grid gap-1 rounded-xl border border-white/10 bg-black/25 p-1"
      style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}
    >
      {options.map((opt) => {
        const active = opt.value === value;
        return (
          <button
            key={opt.value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(opt.value)}
            className={cn(
              "rounded-lg px-2 py-2 text-[10.5px] font-bold transition-all sm:text-[11px]",
              active
                ? "bg-white/12 text-white shadow-[inset_0_0_0_1px_rgba(255,255,255,0.12)]"
                : "text-white/45 hover:text-white/80"
            )}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}

export function StatusPill({
  tone = "neutral",
  children,
  dot = true,
}: {
  tone?: "success" | "warn" | "danger" | "info" | "neutral";
  children: ReactNode;
  dot?: boolean;
}) {
  const tones = {
    success: "border-mint/25 bg-mint/10 text-[#8ef0c6]",
    warn: "border-amber-300/25 bg-amber-300/10 text-amber-200",
    danger: "border-rose-400/25 bg-rose-400/10 text-rose-200",
    info: "border-aqua/25 bg-aqua/10 text-[#93edfb]",
    neutral: "border-white/12 bg-white/[0.05] text-white/65",
  };
  const dots = {
    success: "bg-mint",
    warn: "bg-amber-300",
    danger: "bg-rose-400",
    info: "bg-aqua",
    neutral: "bg-white/50",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[9px] uppercase tracking-[0.1em]",
        tones[tone]
      )}
    >
      {dot ? <span className={cn("h-1.5 w-1.5 rounded-full", dots[tone])} /> : null}
      {children}
    </span>
  );
}

/** Animated face landmark overlay used in the phone preview. */
export function FaceScanOverlay({ compact = false }: { compact?: boolean }) {
  const points: [number, number, number][] = [
    [150, 92, 0], [128, 102, 0.2], [172, 102, 0.4], [110, 122, 0.6],
    [190, 122, 0.8], [102, 150, 1], [198, 150, 0.1], [104, 178, 0.3],
    [196, 178, 0.5], [112, 204, 0.7], [188, 204, 0.9], [126, 222, 0.2],
    [174, 222, 0.45], [150, 232, 0.65], [139, 146, 0.15], [161, 146, 0.35],
    [136, 141, 0.55], [164, 141, 0.75], [150, 160, 0.25], [144, 174, 0.5],
    [156, 174, 0.7], [150, 184, 0.85], [137, 192, 0], [163, 192, 0.3],
    [150, 202, 0.6], [124, 168, 0.9], [176, 168, 0.2], [118, 186, 0.4],
    [182, 186, 0.65], [131, 207, 0.85], [169, 207, 0.1], [141, 214, 0.5],
    [159, 214, 0.8], [150, 126, 0.35], [118, 134, 0.55], [182, 134, 0.75],
  ];

  return (
    <div className="pointer-events-none absolute inset-0 z-20 overflow-hidden">
      <svg
        viewBox="0 0 300 400"
        preserveAspectRatio="xMidYMid slice"
        className={cn("h-full w-full", compact ? "opacity-80" : "opacity-95")}
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="scanFrame" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#a78bfa" />
            <stop offset="100%" stopColor="#22d3ee" />
          </linearGradient>
          <radialGradient id="scanGlow">
            <stop offset="0%" stopColor="#7c5cff" stopOpacity=".26" />
            <stop offset="100%" stopColor="#7c5cff" stopOpacity="0" />
          </radialGradient>
        </defs>

        <ellipse cx="150" cy="172" rx="110" ry="142" fill="url(#scanGlow)" />
        <rect
          x="82"
          y="72"
          width="136"
          height="176"
          rx="62"
          fill="none"
          stroke="url(#scanFrame)"
          strokeWidth="1.1"
          strokeDasharray="5 7"
          opacity=".75"
        />
        <path
          d="M82 118V96a8 8 0 0 1 8-8h20M218 118V96a8 8 0 0 0-8-8h-20M82 202v22a8 8 0 0 0 8 8h20M218 202v22a8 8 0 0 1-8 8h-20"
          fill="none"
          stroke="white"
          strokeWidth="2.4"
          strokeLinecap="round"
          opacity=".9"
        />
        <path
          d="M126 143c4-4 10-4 14 0M160 143c4-4 10-4 14 0"
          fill="none"
          stroke="#67e8f9"
          strokeWidth="1.4"
          strokeLinecap="round"
        />
        <path
          d="M150 168c-2 4-3 8 0 10m-12 12c8 5 16 5 24 0"
          fill="none"
          stroke="url(#scanFrame)"
          strokeWidth="1.3"
          strokeLinecap="round"
        />
        <path
          d="M150 66v-10M150 268v10M76 172h-10M234 172h10"
          stroke="white"
          strokeOpacity=".45"
          strokeWidth="1"
        />
        {points.map(([x, y, delay], i) => (
          <g key={`${x}-${y}`}>
            <circle
              cx={x}
              cy={y}
              r="3.4"
              fill="#22d3ee"
              opacity="0.13"
              style={{ animation: `pulse-soft 2.8s ease-in-out ${delay}s infinite` }}
            />
            <circle cx={x} cy={y} r="1.15" fill={i % 5 === 0 ? "#a78bfa" : "#dffbff"} opacity="0.9" />
          </g>
        ))}
      </svg>

      <div className="absolute left-4 top-[24%] flex items-center gap-1.5 rounded-full border border-mint/30 bg-black/45 px-2 py-1 backdrop-blur-md">
        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-mint" />
        <span className="font-mono text-[8px] uppercase tracking-[0.12em] text-[#a8f5d7]">
          Tracking 478
        </span>
      </div>

      <div
        className="absolute inset-x-[16%] h-16 bg-gradient-to-b from-transparent via-aqua/20 to-transparent"
        style={{ animation: "scan 5s ease-in-out infinite", top: "14%" }}
      >
        <div className="h-px w-full bg-gradient-to-r from-transparent via-cyan-300/80 to-transparent shadow-[0_0_14px_rgba(34,211,238,0.8)]" />
      </div>
    </div>
  );
}
