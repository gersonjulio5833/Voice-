import { useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Code2,
  Lock,
  Menu,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { LogoMark, Wordmark } from "@/components/Brand";
import { imageCredits } from "@/data/content";
import { cn } from "@/utils/cn";

const navLinks = [
  { href: "#produto", label: "Produto" },
  { href: "#demo", label: "Demonstração" },
  { href: "#arquitetura", label: "Arquitetura" },
  { href: "#compatibilidade", label: "Compatibilidade" },
  { href: "#projeto", label: "Código & APK" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50">
      <div className="border-b border-white/[0.06] bg-[#0a0716]/90 backdrop-blur-xl">
        <div className="wrap flex h-[68px] items-center justify-between gap-4">
          <a href="#top" aria-label="AI Face Live — início" className="shrink-0">
            <Wordmark />
          </a>

          <nav aria-label="Navegação principal" className="hidden items-center gap-6 lg:flex">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-[12.5px] font-semibold text-white/55 transition hover:text-white"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a href="#demo" className="btn-secondary hidden !px-4 !py-2.5 text-xs xl:inline-flex">
              Testar demo
            </a>
            <a href="#projeto" className="btn-primary hidden !px-4 !py-2.5 text-xs sm:inline-flex">
              Código &amp; build
              <ArrowUpRight size={13} />
            </a>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-navigation"
              aria-label={open ? "Fechar menu" : "Abrir menu"}
              className="icon-btn h-10 w-10 lg:hidden"
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
      </div>

      <div
        id="mobile-navigation"
        className={cn(
          "overflow-hidden border-b border-white/10 bg-[#0a0716]/97 backdrop-blur-xl transition-all duration-300 lg:hidden",
          open ? "max-h-[480px] opacity-100" : "max-h-0 opacity-0"
        )}
      >
        <nav aria-label="Navegação móvel" className="wrap grid gap-1 py-4">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="flex items-center justify-between rounded-xl px-3 py-3 text-sm font-semibold text-white/70 transition hover:bg-white/[0.05] hover:text-white"
            >
              {link.label}
              <ArrowRight size={14} className="text-white/32" />
            </a>
          ))}
          <div className="mt-2 grid grid-cols-2 gap-2">
            <a href="#demo" onClick={() => setOpen(false)} className="btn-secondary !py-3 text-xs">
              Testar demo
            </a>
            <a href="#projeto" onClick={() => setOpen(false)} className="btn-primary !py-3 text-xs">
              Código &amp; build
            </a>
          </div>
        </nav>
      </div>

      <div className="h-0.5 w-full bg-gradient-to-r from-electric/0 via-electric/60 to-aqua/0" />
    </header>
  );
}

export function FinalCta() {
  return (
    <section className="wrap pb-20 pt-8 sm:pb-24">
      <div className="gradient-border relative overflow-hidden rounded-[2rem] bg-[#0d0a1c] px-6 py-10 sm:px-10 sm:py-12 lg:px-14">
        <div className="pointer-events-none absolute -right-24 -top-32 h-80 w-80 rounded-full bg-electric/25 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-40 left-1/3 h-80 w-80 rounded-full bg-azure/15 blur-3xl" />
        <div className="pointer-events-none absolute inset-0 bg-grid opacity-[0.35] [mask-image:linear-gradient(to_bottom,black,transparent)]" />

        <div className="relative flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-xl">
            <div className="flex items-center gap-3">
              <LogoMark className="h-11 w-11" />
              <span className="eyebrow text-white/50">AI FACE LIVE · ANDROID</span>
            </div>
            <h2 className="mt-5 font-display text-[1.8rem] font-semibold leading-tight tracking-[-0.03em] text-white sm:text-[2.2rem]">
              Um rosto novo. <span className="text-gradient">As tuas expressões.</span>
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-white/45">
              Explora o estúdio interativo, verifica as limitações reais e leva a arquitetura e o
              workflow de compilação contigo.
            </p>
          </div>

          <div className="flex flex-col gap-2.5 sm:flex-row lg:flex-col xl:flex-row">
            <a href="#demo" className="btn-primary whitespace-nowrap">
              <Sparkles size={15} />
              Experimentar o estúdio
            </a>
            <a href="#projeto" className="btn-secondary whitespace-nowrap">
              <Code2 size={15} />
              Ver código & build
            </a>
          </div>
        </div>

        <div className="relative mt-9 flex flex-wrap items-center gap-x-6 gap-y-3 border-t border-white/[0.08] pt-6">
          {[
            { icon: Lock, text: "Processamento on-device" },
            { icon: ShieldCheck, text: "Sem root · sem formatação" },
            { icon: Code2, text: "GitHub Actions incluído" },
          ].map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-2 text-[11px] font-semibold text-white/50">
              <Icon size={13} className="text-electric-soft" />
              {text}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-white/[0.07] bg-[#070510]">
      <div className="wrap py-12 sm:py-16">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Wordmark />
            <p className="mt-5 max-w-xs text-[13px] leading-relaxed text-white/52">
              Projeto Android de face swap em tempo real, com tracking de expressões, privacidade
              on-device e compilação automática. Documentado sem promessas impossíveis.
            </p>
            <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-white/[0.08] bg-white/[0.03] px-3 py-1.5">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-mint opacity-60" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-mint" />
              </span>
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/45">
                Protótipo web · v0.9.0
              </span>
            </div>
          </div>

          <FooterColumn
            title="Produto"
            links={[
              { label: "Funcionalidades", href: "#produto" },
              { label: "Demonstração", href: "#demo" },
              { label: "Compatibilidade", href: "#compatibilidade" },
              { label: "Perguntas frequentes", href: "#faq" },
            ]}
          />
          <FooterColumn
            title="Técnico"
            links={[
              { label: "Arquitetura", href: "#arquitetura" },
              { label: "Código & build", href: "#projeto" },
              { label: "Guia de instalação", href: "#instalar" },
              { label: "Segurança", href: "#seguranca" },
            ]}
          />
          <FooterColumn
            title="Transparência"
            links={[
              { label: "O que é real", href: "#compatibilidade" },
              { label: "Limitações", href: "#compatibilidade" },
              { label: "Uso responsável", href: "#faq" },
              { label: "Privacidade local", href: "#seguranca" },
            ]}
          />
        </div>

        <div className="mt-12 flex flex-col gap-4 border-t border-white/[0.07] pt-6 text-[10.5px] leading-relaxed text-white/42 sm:flex-row sm:items-start sm:justify-between">
          <p className="max-w-2xl">
            © 2026 AI Face Live. Demonstração independente de produto. Não é afiliada ao WhatsApp,
            Meta ou Messenger. Esta página não gera nem distribui APK assinado. Rostos de exemplo
            são modelos de banco de imagens, não pessoas reais do projeto. {imageCredits}
          </p>
          <p className="shrink-0 font-mono uppercase tracking-[0.12em] sm:text-right">
            Android · Kotlin
            <br />
            Made for the honest web
          </p>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({
  title,
  links,
}: {
  title: string;
  links: { label: string; href: string }[];
}) {
  return (
    <div>
      <h3 className="font-mono text-[9px] uppercase tracking-[0.2em] text-white/42">{title}</h3>
      <ul className="mt-4 space-y-2.5">
        {links.map((link) => (
          <li key={link.label}>
            <a
              href={link.href}
              className="text-[12.5px] font-medium text-white/50 transition hover:text-white"
            >
              {link.label}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
