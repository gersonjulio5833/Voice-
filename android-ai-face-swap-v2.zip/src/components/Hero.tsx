import { ArrowRight, ArrowUpRight, Check, Cpu, ScanFace, ShieldCheck, Sparkles } from "lucide-react";
import type { FaceSample } from "@/data/content";
import { faces } from "@/data/content";
import { PhoneMockup } from "@/components/PhoneMockup";
import { StatusPill } from "@/components/ui";

const heroStats = [
  { value: "478", label: "landmarks faciais", sub: "MediaPipe Face Landmarker" },
  { value: "0", label: "imagens enviadas", sub: "processamento on-device" },
  { value: "30", label: "fps objetivo", sub: "dependente do hardware" },
  { value: "8.0+", label: "Android compatível", sub: "minSdk 26 · sem root" },
];

export function Hero({
  face,
  swap,
  onSwapChange,
}: {
  face: FaceSample;
  swap: boolean;
  onSwapChange: (next: boolean) => void;
}) {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="hero-glow pointer-events-none absolute inset-0" />
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-[0.18] [mask-image:radial-gradient(ellipse_75%_70%_at_50%_35%,black,transparent)]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />

      <div className="wrap relative">
        <div className="grid items-center gap-14 pb-12 pt-14 lg:grid-cols-[1.04fr_0.96fr] lg:gap-8 lg:pb-16 lg:pt-20">
          <div className="relative z-10 max-w-[600px]">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="inline-flex items-center gap-2 rounded-full border border-electric-soft/20 bg-electric/10 px-3 py-1.5">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-electric-soft opacity-70" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-electric-soft" />
                </span>
                <span className="font-mono text-[9px] uppercase tracking-[0.16em] text-[#c5b8ff]">
                  Android · protótipo v0.9
                </span>
              </span>
              <span className="hidden items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.035] px-3 py-1.5 sm:inline-flex">
                <Cpu size={10} className="text-aqua" />
                <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/45">
                  on-device AI
                </span>
              </span>
            </div>

            <h1 className="mt-7 font-display text-[2.75rem] font-semibold leading-[0.96] tracking-[-0.045em] text-white sm:text-[3.85rem] lg:text-[4.4rem]">
              Troca o rosto.
              <br />
              <span className="text-gradient">Mantém a expressão.</span>
            </h1>

            <p className="mt-6 max-w-[510px] text-[15px] leading-relaxed text-[#aaa3c0] sm:text-base">
              Face swap em tempo real para Android. Escolhe uma fotografia, ativa o efeito e mantém
              olhos, boca e inclinação da cabeça sincronizados — com o processamento a acontecer
              dentro do dispositivo.
            </p>

            <div className="mt-8 flex flex-col gap-2.5 sm:flex-row sm:items-center">
              <a href="#demo" className="btn-primary group sm:!px-7 sm:!py-4">
                <Sparkles size={16} className="transition group-hover:rotate-12" />
                Experimentar a demo
                <ArrowRight size={15} className="ml-0.5 transition group-hover:translate-x-0.5" />
              </a>
              <a href="#arquitetura" className="btn-secondary sm:!px-6 sm:!py-4">
                Ver a arquitetura
                <ArrowUpRight size={15} />
              </a>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2.5">
              {["Sem root", "Sem uploads", "GitHub Actions"].map((item) => (
                <span key={item} className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-white/45">
                  <span className="flex h-3.5 w-3.5 items-center justify-center rounded-full bg-mint/12">
                    <Check size={9} className="text-mint" strokeWidth={3} />
                  </span>
                  {item}
                </span>
              ))}
            </div>

            <div className="mt-9 flex items-center gap-3.5">
              <div className="flex -space-x-2.5">
                {faces.slice(0, 4).map((f) => (
                  <img
                    key={f.id}
                    src={f.thumb}
                    alt=""
                    className="h-9 w-9 rounded-full border-2 border-[#0b0816] object-cover object-top"
                    loading="lazy"
                  />
                ))}
                <span className="flex h-9 w-9 items-center justify-center rounded-full border-2 border-[#0b0816] bg-white/[0.07] font-mono text-[9px] font-semibold text-white/60">
                  +2
                </span>
              </div>
              <p className="text-[11px] leading-snug text-white/52">
                Banco de rostos de demonstração
                <br />
                <a href="#demo" className="font-semibold text-white/65 underline decoration-white/20 underline-offset-4 transition hover:text-white">
                  ou carrega a tua fotografia
                </a>
              </p>
            </div>
          </div>

          {/* Phone composition */}
          <div className="relative z-10 mx-auto w-full max-w-[430px] lg:pl-6">
            <div className="relative mx-auto w-full max-w-[332px]">
              <div className="pointer-events-none absolute -inset-x-16 -top-10 bottom-0 -z-10 opacity-60">
                <div className="absolute left-1/2 top-1/2 h-[520px] w-[520px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/[0.06]" />
                <div className="absolute left-1/2 top-1/2 h-[400px] w-[400px] -translate-x-1/2 -translate-y-1/2 animate-spin-slow rounded-full border border-dashed border-electric-soft/15" />
                <div className="absolute left-1/2 top-1/2 h-[300px] w-[300px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-electric/10 blur-3xl" />
              </div>

              <div className="absolute -right-3 top-[16%] z-20 hidden rotate-[-8deg] sm:block lg:-right-9">
                <div className="glass flex items-center gap-2 rounded-xl px-2.5 py-2 shadow-[0_12px_30px_rgba(0,0,0,0.4)]">
                  <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-mint/12">
                    <ShieldCheck size={12} className="text-mint" />
                  </span>
                  <div>
                    <p className="text-[9px] font-bold leading-tight text-white">On-device</p>
                    <p className="font-mono text-[7px] uppercase tracking-wider text-white/45">0 uploads</p>
                  </div>
                </div>
              </div>

              <PhoneMockup
                face={face}
                swap={swap}
                onSwapChange={onSwapChange}
                tracking
                intensity={82}
              />

              <div className="absolute -left-4 bottom-[18%] z-20 hidden w-[178px] -rotate-2 sm:block lg:-left-14">
                <div className="glass rounded-2xl p-3 shadow-[0_18px_40px_rgba(0,0,0,0.5)]">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <ScanFace size={12} className="text-aqua" />
                      <span className="text-[9px] font-bold text-white/80">Rastreamento</span>
                    </div>
                    <StatusPill tone="success" dot>live</StatusPill>
                  </div>
                  <div className="mt-2.5 space-y-1.5">
                    {[
                      { label: "Olhos", val: "98%" },
                      { label: "Boca", val: "94%" },
                      { label: "Inclinação", val: "91%" },
                    ].map((row) => (
                      <div key={row.label} className="flex items-center gap-2">
                        <span className="w-14 font-mono text-[7px] uppercase tracking-wider text-white/45">
                          {row.label}
                        </span>
                        <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/10">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-electric-soft to-aqua"
                            style={{ width: row.val }}
                          />
                        </div>
                        <span className="font-mono text-[7px] text-white/45">{row.val}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="absolute -top-3 right-6 z-20 sm:-right-5">
                <div className="flex items-center gap-1.5 rounded-full border border-white/10 bg-[#0c0918]/90 px-2.5 py-1.5 backdrop-blur-xl">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-mint" />
                  <span className="font-mono text-[8px] uppercase tracking-[0.14em] text-white/50">
                    preview local
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="relative mb-14 lg:mb-20">
          <div className="pointer-events-none absolute inset-0 -mx-4 rounded-3xl bg-gradient-to-r from-electric/[0.06] via-transparent to-azure/[0.06]" />
          <div className="relative grid grid-cols-2 gap-y-7 rounded-2xl border border-white/[0.08] bg-white/[0.018] px-5 py-6 backdrop-blur-sm sm:px-7 lg:grid-cols-4 lg:gap-y-0 lg:divide-x lg:divide-white/[0.08]">
            {heroStats.map((stat) => (
              <div key={stat.label} className="lg:px-6 lg:first:pl-0 lg:last:pr-0">
                <div className="flex items-baseline gap-2">
                  <span className="font-display text-[1.55rem] font-semibold tracking-[-0.04em] text-white sm:text-[1.8rem]">
                    {stat.value}
                  </span>
                  <span className="text-[11px] font-semibold text-white/55">{stat.label}</span>
                </div>
                <p className="mt-1 font-mono text-[8px] uppercase tracking-[0.13em] text-white/32">
                  {stat.sub}
                </p>
              </div>
            ))}
          </div>
          <p className="mt-3 flex items-start gap-1.5 px-1 text-[10px] leading-relaxed text-white/32">
            <ArrowUpRight size={11} className="mt-0.5 shrink-0" />
            Valores de arquitetura e objetivos de desempenho — não são resultados medidos num
            dispositivo. A demo no browser é uma simulação visual, não processamento de IA.
          </p>
        </div>
      </div>
    </section>
  );
}
