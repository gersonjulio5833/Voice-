import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  Check,
  CheckCircle2,
  Clipboard,
  Code2,
  Copy,
  Download,
  FileCode2,
  FileText,
  FolderTree,
  GitBranch,
  Info,
  Lock,
  Package,
  ShieldCheck,
  Smartphone,
  Terminal,
  Workflow,
  X,
} from "lucide-react";
import { buildFiles, downloadGuide, installSteps, projectTree } from "@/data/content";
import { SectionHeading, StatusPill } from "@/components/ui";
import { cn } from "@/utils/cn";

const firstFile = buildFiles[0];

const installIcons = [Code2, GitBranch, Package, Smartphone];

const requirements = [
  "Telemóvel Android 8.0 ou superior",
  "Câmara frontal funcional",
  "OpenGL ES 3.0 (recomendado)",
  "3 GB de RAM ou mais para o preset equilibrado",
];

const safety = [
  "Sem root ou bootloader desbloqueado",
  "Sem formatação ou perda de dados",
  "Permissões de câmara e fotos apenas",
  "APK de debug apenas para testes",
];

export function BuildSection() {
  const [activeFile, setActiveFile] = useState(firstFile.id);
  const [toast, setToast] = useState<string | null>(null);

  const file = buildFiles.find((f) => f.id === activeFile) ?? firstFile;

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 3000);
    return () => window.clearTimeout(id);
  }, [toast]);

  const downloadText = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    setToast(`${filename} descarregado.`);
  };

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(file.code);
      setToast(`${file.label} copiado para a área de transferência.`);
    } catch {
      setToast("O browser bloqueou o acesso à área de transferência.");
    }
  };

  return (
    <section id="projeto" className="relative scroll-mt-24 py-20 sm:py-24">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute -left-48 top-40 h-[460px] w-[460px] rounded-full bg-electric/[0.08] blur-3xl" />
      </div>

      <div className="wrap relative">
        <SectionHeading
          eyebrow="Repositório & build"
          title={
            <>
              Sem Android Studio.
              <br />
              <span className="text-white/52">Sem desculpas.</span>
            </>
          }
          description="O projeto está organizado para ser compilado na nuvem: Gradle, manifest, workflow do GitHub Actions e instruções de instalação. Leva o guia técnico contigo para começares o repositório."
          aside={
            <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.035] px-3 py-1.5">
              <Terminal size={12} className="text-mint" />
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/52">
                JDK 17 · Gradle
              </span>
            </div>
          }
        />

        <div className="mt-10 grid gap-3.5 lg:grid-cols-[0.85fr_1.15fr]">
          {/* Left: tree + downloads */}
          <div className="flex flex-col gap-3.5">
            <div className="card overflow-hidden">
              <div className="flex items-center justify-between border-b border-white/[0.07] px-4 py-3">
                <div className="flex items-center gap-2">
                  <FolderTree size={13} className="text-electric-soft" />
                  <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/45">
                    estrutura prevista
                  </span>
                </div>
                <div className="flex gap-1">
                  <span className="h-2 w-2 rounded-full bg-rose-400/40" />
                  <span className="h-2 w-2 rounded-full bg-amber-300/40" />
                  <span className="h-2 w-2 rounded-full bg-mint/40" />
                </div>
              </div>
              <pre className="overflow-x-auto p-4 font-mono text-[9.5px] leading-[1.85] text-white/45 sm:text-[10px]">
                {projectTree}
              </pre>
              <div className="flex items-center gap-1.5 border-t border-white/[0.07] px-4 py-2.5">
                <Info size={10} className="shrink-0 text-white/20" />
                <p className="text-[8.5px] text-white/32">
                  Estrutura de referência do repositório Android; os ficheiros deste site são
                  excertos representativos.
                </p>
              </div>
            </div>

            <div className="card gradient-border p-5">
              <div className="flex items-center gap-2">
                <Download size={13} className="text-aqua" />
                <span className="mono-label">documentação offline</span>
              </div>
              <h3 className="mt-2 font-display text-[1.05rem] font-semibold tracking-tight text-white">
                Leva a arquitetura contigo
              </h3>
              <p className="mt-1.5 text-[10.5px] leading-relaxed text-white/45">
                Guia técnico com árvore do projeto, snippets de Gradle e manifest, workflow completo
                e passos de instalação no telemóvel.
              </p>
              <div className="mt-4 grid gap-2">
                <button
                  type="button"
                  onClick={() => downloadText(downloadGuide, "AI-FACE-LIVE-guia-tecnico.md", "text/markdown;charset=utf-8")}
                  className="btn-primary !rounded-xl !py-3 text-[11px]"
                >
                  <FileText size={13} />
                  Descarregar guia (.md)
                </button>
                <button
                  type="button"
                  onClick={() => downloadText(firstFile.code, "build.yml", "text/yaml;charset=utf-8")}
                  className="btn-secondary !rounded-xl !py-3 text-[11px]"
                >
                  <Workflow size={13} />
                  Descarregar workflow (.yml)
                </button>
              </div>
              <div className="mt-3 rounded-xl border border-amber-200/15 bg-amber-200/[0.045] px-3 py-2.5">
                <p className="flex items-start gap-1.5 text-[9px] leading-relaxed text-amber-100/50">
                  <Info size={11} className="mt-0.5 shrink-0" />
                  <span>
                    <strong className="font-bold text-amber-100/75">Isto não é um APK.</strong>{" "}
                    Nenhum binário Android é gerado nesta página. O workflow produz o APK quando o
                    código completo está num repositório GitHub.
                  </span>
                </p>
              </div>
            </div>
          </div>

          {/* Right: code viewer */}
          <div className="card overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.07] px-3 py-2.5">
              <div className="flex flex-wrap items-center gap-1">
                {buildFiles.map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setActiveFile(f.id)}
                    aria-pressed={f.id === activeFile}
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 font-mono text-[9px] transition",
                      f.id === activeFile
                        ? "bg-white/[0.08] text-white"
                        : "text-white/45 hover:bg-white/[0.04] hover:text-white/65"
                    )}
                  >
                    <FileCode2 size={10} />
                    {f.label}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={copyCode}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.08] bg-white/[0.03] px-2.5 py-1.5 text-[9px] font-semibold text-white/45 transition hover:border-white/20 hover:text-white"
              >
                <Copy size={10} />
                Copiar
              </button>
            </div>

            <div className="flex items-center justify-between gap-2 border-b border-white/[0.06] bg-black/25 px-4 py-2">
              <div className="flex items-center gap-1.5 overflow-hidden">
                <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-mint/60" />
                <code className="truncate font-mono text-[8.5px] text-white/42">{file.path}</code>
              </div>
              <span className="shrink-0 font-mono text-[7.5px] uppercase tracking-[0.12em] text-white/20">
                {file.language}
              </span>
            </div>

            <div className="relative max-h-[470px] overflow-auto bg-[#080611]">
              <div className="flex">
                <div className="sticky left-0 shrink-0 select-none border-r border-white/[0.05] bg-[#080611] px-2.5 py-3.5 text-right font-mono text-[10px] leading-[20px] text-white/15">
                  {file.code.split("\n").map((_, i) => (
                    <div key={i}>{i + 1}</div>
                  ))}
                </div>
                <pre className="code-block whitespace-pre px-4 py-3.5 [line-height:20px]">
                  {file.code}
                </pre>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.07] px-4 py-3">
              <div className="flex items-center gap-1.5">
                <Clipboard size={11} className="text-white/32" />
                <span className="font-mono text-[8px] uppercase tracking-[0.1em] text-white/32">
                  excerto · não substitui o repositório completo
                </span>
              </div>
              <button
                type="button"
                onClick={() => downloadText(file.code, file.label, "text/plain;charset=utf-8")}
                className="inline-flex items-center gap-1 text-[9px] font-bold text-electric-soft/80 transition hover:text-white"
              >
                <Download size={10} />
                Descarregar ficheiro
              </button>
            </div>
          </div>
        </div>

        {/* Artifact status */}
        <div className="mt-3.5 grid gap-3.5 sm:grid-cols-3">
          {[
            {
              label: "Workflow",
              value: "incluído",
              icon: Workflow,
              body: "Build de debug + upload do artifact com retenção de 30 dias.",
              tone: "success" as const,
            },
            {
              label: "APK de demonstração",
              value: "não gerado",
              icon: Package,
              body: "A compilação Android corre no teu repositório, não nesta sandbox web.",
              tone: "warn" as const,
            },
            {
              label: "Assinatura Play Store",
              value: "não incluída",
              icon: Lock,
              body: "O APK de debug não serve para distribuição pública. Adiciona um keystore em secrets.",
              tone: "neutral" as const,
            },
          ].map((item) => (
            <div key={item.label} className="card flex items-start gap-3 p-4">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-white/52">
                <item.icon size={14} />
              </span>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[10.5px] font-bold text-white/65">{item.label}</span>
                  <StatusPill tone={item.tone}>{item.value}</StatusPill>
                </div>
                <p className="mt-1.5 text-[9.5px] leading-relaxed text-white/42">{item.body}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Install */}
        <div id="instalar" className="mt-16 scroll-mt-24 sm:mt-20">
          <div className="flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
            <div>
              <span className="eyebrow text-electric-soft/90">
                <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-electric-soft to-aqua" />
                Instalação
              </span>
              <h3 className="mt-3 font-display text-[1.6rem] font-semibold leading-tight tracking-[-0.03em] text-white sm:text-[2rem]">
                Do GitHub para o telemóvel.
              </h3>
              <p className="mt-2 max-w-xl text-[12px] leading-relaxed text-white/45">
                Sem computador. O GitHub Actions compila o APK na nuvem e tu descarregas o artifact
                diretamente no Android.
              </p>
            </div>
            <a
              href="https://docs.github.com/en/actions/using-workflows/storing-workflow-data-as-artifacts"
              target="_blank"
              rel="noreferrer noopener"
              className="inline-flex items-center gap-1.5 text-[10.5px] font-bold text-white/52 transition hover:text-white"
            >
              Docs de artifacts do GitHub
              <ArrowUpRight size={12} />
            </a>
          </div>

          <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {installSteps.map((step, i) => {
              const Icon = installIcons[i];
              return (
                <div key={step.n} className="card group relative p-5">
                  <div className="flex items-center justify-between">
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-electric-soft">
                      <Icon size={15} />
                    </span>
                    <span className="font-display text-xl font-semibold tracking-tight text-white/[0.12]">
                      {step.n}
                    </span>
                  </div>
                  <h4 className="mt-4 text-[11.5px] font-bold text-white/75">{step.title}</h4>
                  <p className="mt-1.5 text-[10px] leading-relaxed text-white/32">{step.body}</p>
                  {i < installSteps.length - 1 ? (
                    <span className="absolute -right-[9px] top-[34px] z-10 hidden h-4 w-4 items-center justify-center rounded-full border border-white/10 bg-[#0d0a19] text-white/42 lg:flex">
                      <ArrowUpRight size={9} />
                    </span>
                  ) : null}
                </div>
              );
            })}
          </div>

          <div className="mt-3.5 grid gap-3.5 sm:grid-cols-2">
            <div className="card p-5">
              <div className="flex items-center gap-2">
                <Smartphone size={13} className="text-aqua" />
                <span className="mono-label">requisitos</span>
              </div>
              <ul className="mt-3 space-y-2">
                {requirements.map((req) => (
                  <li key={req} className="flex items-start gap-2 text-[10.5px] leading-relaxed text-white/52">
                    <Check size={11} className="mt-0.5 shrink-0 text-mint" />
                    {req}
                  </li>
                ))}
              </ul>
            </div>
            <div className="card p-5">
              <div className="flex items-center gap-2">
                <ShieldCheck size={13} className="text-mint" />
                <span className="mono-label">segurança</span>
              </div>
              <ul className="mt-3 space-y-2">
                {safety.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-[10.5px] leading-relaxed text-white/52">
                    <CheckCircle2 size={11} className="mt-0.5 shrink-0 text-mint" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-3.5 rounded-xl border border-white/[0.07] bg-white/[0.02] px-4 py-3">
            <p className="flex items-start gap-2 text-[9.5px] leading-relaxed text-white/32">
              <Info size={11} className="mt-0.5 shrink-0" />
              Nota de desenvolvimento: a árvore, o workflow e os excertos mostram a arquitetura e a
              configuração previstas. O motor de face swap requer um modelo compatível com licença.
              Não é possível validar uma integração real com WhatsApp ou Messenger no âmbito deste
              projeto sem root.
            </p>
          </div>
        </div>
      </div>

      {toast ? (
        <div
          role="status"
          className="fixed bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/15 bg-[#171226]/95 px-4 py-2.5 text-[11px] font-semibold text-white shadow-2xl backdrop-blur-xl"
        >
          <Check size={13} className="text-mint" />
          {toast}
          <button
            type="button"
            onClick={() => setToast(null)}
            aria-label="Fechar notificação"
            className="ml-1 text-white/42 hover:text-white"
          >
            <X size={12} />
          </button>
        </div>
      ) : null}

    </section>
  );
}
