import { Activity, ArrowRight, Boxes, Camera, Cpu, GitBranch, Info, Layers, MonitorPlay, ScanFace, ShieldCheck, Smartphone } from "lucide-react";
import { pipeline, stack } from "@/data/content";
import { SectionHeading, StatusPill } from "@/components/ui";

const stepIcons = [Camera, ScanFace, Layers, MonitorPlay];
const frameBudget = [
  { label: "Captura CameraX", ms: 3, width: "8%" },
  { label: "Landmarks MediaPipe", ms: 8, width: "21%" },
  { label: "Inferência TFLite", ms: 24, width: "62%" },
  { label: "Render OpenGL", ms: 4, width: "10%" },
];

const statusRows = [
  { label: "Fluxo de UI e seleção", value: "protótipo", tone: "info" as const },
  { label: "CameraX · ImageAnalysis", value: "a integrar", tone: "neutral" as const },
  { label: "MediaPipe · Face Landmarker", value: "a integrar", tone: "neutral" as const },
  { label: "Motor TFLite · face swap", value: "modelo em falta", tone: "warn" as const },
  { label: "Render OpenGL ES", value: "esqueleto", tone: "info" as const },
];

export function Pipeline() {
  return (
    <section id="arquitetura" className="relative scroll-mt-24 py-20 sm:py-24">
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-[0.09] [mask-image:radial-gradient(ellipse_65%_60%_at_50%_50%,black,transparent)]" />

      <div className="wrap relative">
        <SectionHeading
          eyebrow="Arquitetura técnica"
          title={
            <>
              Da fotografia
              <br />
              <span className="text-white/52">ao frame final.</span>
            </>
          }
          description="Quatro módulos, um único sentido: manter o vídeo na GPU e nunca bloquear a captura. Esta é a arquitetura proposta para o APK Android, não o funcionamento da demo no browser."
          aside={
            <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.035] px-3 py-1.5">
              <GitBranch size={12} className="text-electric-soft" />
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/52">
                pipeline on-device
              </span>
            </div>
          }
        />

        {/* Pipeline steps */}
        <div className="relative mt-10">
          <div className="pointer-events-none absolute left-[8%] right-[8%] top-[54px] hidden h-px bg-gradient-to-r from-electric/10 via-electric-soft/50 to-aqua/20 lg:block" />
          <div className="grid gap-3.5 sm:grid-cols-2 lg:grid-cols-4">
            {pipeline.map((step, i) => {
              const Icon = stepIcons[i];
              return (
                <div key={step.step} className="card group relative p-5 transition hover:border-white/[0.16]">
                  <div className="relative flex items-center justify-between">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-gradient-to-b from-white/[0.08] to-white/[0.02] text-electric-soft shadow-[inset_0_1px_0_rgba(255,255,255,0.12)]">
                      <Icon size={18} />
                    </span>
                    <span className="font-mono text-[10px] tracking-[0.14em] text-white/20">{step.step}</span>
                  </div>
                  {i < pipeline.length - 1 ? (
                    <ArrowRight
                      size={13}
                      className="absolute -right-[13px] top-[56px] z-10 hidden text-white/20 lg:block"
                    />
                  ) : null}
                  <h3 className="mt-4 font-display text-[1.02rem] font-semibold tracking-tight text-white">
                    {step.title}
                  </h3>
                  <p className="mt-1.5 text-[11px] leading-relaxed text-white/52">{step.body}</p>
                  <div className="mt-4 flex flex-wrap items-center gap-1.5">
                    <span className="rounded-md border border-electric-soft/20 bg-electric/[0.09] px-1.5 py-1 font-mono text-[7.5px] uppercase tracking-wider text-electric-soft/85">
                      {step.tech}
                    </span>
                    <span className="rounded-md border border-white/[0.07] bg-white/[0.025] px-1.5 py-1 font-mono text-[7px] text-white/42">
                      {step.detail}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-3.5 grid gap-3.5 lg:grid-cols-[1.05fr_0.95fr]">
          {/* Frame budget */}
          <div className="card overflow-hidden p-5 sm:p-6">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <Activity size={13} className="text-aqua" />
                  <span className="mono-label">orçamento de frame</span>
                </div>
                <h3 className="mt-2 font-display text-[1.15rem] font-semibold tracking-tight text-white">
                  Onde vive cada milissegundo
                </h3>
              </div>
              <StatusPill tone="warn" dot>estimativa</StatusPill>
            </div>

            <div className="mt-5 space-y-3">
              {frameBudget.map((row) => (
                <div key={row.label}>
                  <div className="flex items-center justify-between">
                    <span className="text-[10.5px] font-medium text-white/50">{row.label}</span>
                    <span className="font-mono text-[9px] text-white/42">{row.ms} ms</span>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-electric via-[#8b5cf6] to-aqua opacity-80"
                      style={{ width: row.width }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-5 flex items-center justify-between gap-3 rounded-xl border border-white/[0.07] bg-white/[0.025] px-3.5 py-3">
              <div className="flex items-center gap-2">
                <Cpu size={13} className="text-white/45" />
                <span className="text-[10.5px] leading-tight text-white/45">
                  Total teórico por frame
                  <span className="block font-mono text-[7.5px] uppercase tracking-wider text-white/20">
                    mid-range · GPU delegate
                  </span>
                </span>
              </div>
              <span className="font-display text-lg font-semibold tracking-tight text-white">≈ 39 ms</span>
            </div>

            <p className="mt-3 flex items-start gap-1.5 text-[9px] leading-relaxed text-white/22">
              <Info size={10} className="mt-0.5 shrink-0" />
              Estimativas de projeto para um dispositivo intermédio. Latência real, tempo de
              inicialização do modelo, temperatura e consumo variam por fabricante. O modo
              Económico pode reduzir a resolução e inferir a cada 2 frames.
            </p>
          </div>

          {/* Stack + status */}
          <div className="grid gap-3.5">
            <div className="card p-5 sm:p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Boxes size={13} className="text-electric-soft" />
                  <span className="mono-label">stack do APK</span>
                </div>
                <span className="font-mono text-[8px] uppercase tracking-[0.12em] text-white/32">minSdk 26</span>
              </div>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {stack.map((tech) => (
                  <span
                    key={tech}
                    className="rounded-lg border border-white/[0.08] bg-white/[0.035] px-2.5 py-1.5 font-mono text-[9px] text-white/55"
                  >
                    {tech}
                  </span>
                ))}
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2">
                {[
                  { icon: ShieldCheck, label: "Sem root" },
                  { icon: Smartphone, label: "CameraX" },
                  { icon: Cpu, label: "GPU-first" },
                ].map(({ icon: Icon, label }) => (
                  <div key={label} className="rounded-lg border border-white/[0.07] bg-white/[0.02] px-2 py-2.5 text-center">
                    <Icon size={13} className="mx-auto text-white/45" />
                    <p className="mt-1.5 font-mono text-[7.5px] uppercase tracking-wider text-white/42">{label}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="card p-5 sm:p-6" id="seguranca">
              <div className="flex items-center gap-2">
                <GitBranch size={13} className="text-mint" />
                <span className="mono-label">estado honesto</span>
              </div>
              <div className="mt-3 divide-y divide-white/[0.06]">
                {statusRows.map((row) => (
                  <div key={row.label} className="flex items-center justify-between gap-2 py-2 first:pt-0 last:pb-0">
                    <span className="text-[10px] text-white/52">{row.label}</span>
                    <StatusPill tone={row.tone} dot={false}>{row.value}</StatusPill>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-3.5 flex items-start gap-2.5 rounded-2xl border border-amber-200/15 bg-amber-200/[0.04] p-4">
          <Info size={14} className="mt-0.5 shrink-0 text-amber-200/70" />
          <p className="text-[10px] leading-relaxed text-amber-100/55">
            <strong className="font-bold text-amber-100/80">Sobre o modelo de IA:</strong> um motor
            de face swap real precisa de pesos compatíveis com TFLite e de uma licença que permita
            distribuição. Este projeto não inclui esses pesos. O código apresentado é o esqueleto de
            orquestração, não um modelo treinado nem um resultado validado em hardware.
          </p>
        </div>
      </div>
    </section>
  );
}
