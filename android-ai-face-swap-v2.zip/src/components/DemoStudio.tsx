import { useEffect, useRef, useState } from "react";
import {
  Activity,
  ArrowUpRight,
  Camera,
  Check,
  ImagePlus,
  Images,
  Info,
  Laptop,
  Layers,
  Mic,
  RotateCcw,
  Save,
  ScanFace,
  SlidersHorizontal,
  Sparkles,
  Upload,
} from "lucide-react";
import type { FaceSample, QualityKey } from "@/data/content";
import { faces, qualityModes } from "@/data/content";
import { PhoneMockup } from "@/components/PhoneMockup";
import { SectionHeading, Segmented, StatusPill, Toggle } from "@/components/ui";
import { cn } from "@/utils/cn";

type DemoStudioProps = {
  face: FaceSample;
  setFace: (face: FaceSample) => void;
};

const qualityOptions: { value: QualityKey; label: string }[] = [
  { value: "economy", label: "Económico" },
  { value: "balanced", label: "Equilibrado" },
  { value: "max", label: "Máximo" },
];

const cameraOptions: { value: "front" | "back"; label: string }[] = [
  { value: "front", label: "Frontal" },
  { value: "back", label: "Traseira" },
];

type Preset = {
  swap: boolean;
  tracking: boolean;
  intensity: number;
  quality: QualityKey;
  camera: "front" | "back";
  mirror: boolean;
};

const defaultPreset: Preset = {
  swap: true,
  tracking: true,
  intensity: 82,
  quality: "balanced",
  camera: "front",
  mirror: true,
};

const STORAGE_KEY = "ai-face-live-demo-preset";

export function DemoStudio({ face, setFace }: DemoStudioProps) {
  const [swap, setSwap] = useState(defaultPreset.swap);
  const [tracking, setTracking] = useState(defaultPreset.tracking);
  const [intensity, setIntensity] = useState(defaultPreset.intensity);
  const [quality, setQuality] = useState<QualityKey>(defaultPreset.quality);
  const [camera, setCamera] = useState<"front" | "back">(defaultPreset.camera);
  const [mirror, setMirror] = useState(defaultPreset.mirror);
  const [toast, setToast] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const uploadedUrl = useRef<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const loaded = JSON.parse(raw) as Partial<Preset>;
      if (typeof loaded.swap === "boolean") setSwap(loaded.swap);
      if (typeof loaded.tracking === "boolean") setTracking(loaded.tracking);
      if (typeof loaded.intensity === "number") {
        setIntensity(Math.min(100, Math.max(0, loaded.intensity)));
      }
      if (loaded.quality && loaded.quality in qualityModes) setQuality(loaded.quality);
      if (loaded.camera === "front" || loaded.camera === "back") setCamera(loaded.camera);
      if (typeof loaded.mirror === "boolean") setMirror(loaded.mirror);
    } catch {
      /* localStorage can be disabled; the demo keeps working. */
    }
  }, []);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 3200);
    return () => window.clearTimeout(id);
  }, [toast]);

  useEffect(() => {
    return () => {
      if (uploadedUrl.current) URL.revokeObjectURL(uploadedUrl.current);
    };
  }, []);

  const handleUpload = (file: File | undefined) => {
    if (!file) return;
    setUploadError(null);
    if (!file.type.startsWith("image/")) {
      setUploadError("Escolhe um ficheiro de imagem (JPG, PNG ou WebP).");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setUploadError("A imagem deve ter menos de 8 MB nesta demonstração.");
      return;
    }
    if (uploadedUrl.current) URL.revokeObjectURL(uploadedUrl.current);
    const url = URL.createObjectURL(file);
    uploadedUrl.current = url;
    setFace({
      id: "uploaded",
      name: file.name.replace(/\.[^.]+$/, "").slice(0, 22) || "A tua foto",
      tag: "Carregada localmente",
      url,
      thumb: url,
      accent: "#22d3ee",
    });
    setToast("Fotografia carregada apenas neste browser.");
  };

  const persistPreset = () => {
    const preset: Preset = { swap, tracking, intensity, quality, camera, mirror };
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(preset));
      setToast("Predefinição guardada neste browser.");
    } catch {
      setToast("O browser bloqueou o armazenamento local.");
    }
  };

  const resetPreset = () => {
    setSwap(defaultPreset.swap);
    setTracking(defaultPreset.tracking);
    setIntensity(defaultPreset.intensity);
    setQuality(defaultPreset.quality);
    setCamera(defaultPreset.camera);
    setMirror(defaultPreset.mirror);
    setToast("Controlos repostos.");
  };

  return (
    <section id="demo" className="relative scroll-mt-24 py-20 sm:py-24">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-24 h-[520px] w-[820px] -translate-x-1/2 rounded-full bg-electric/[0.07] blur-3xl" />
      </div>

      <div className="wrap relative">
        <SectionHeading
          eyebrow="Estúdio interativo"
          title={
            <>
              Escolhe um rosto.
              <br />
              <span className="text-white/45">Vê a interface ganhar vida.</span>
            </>
          }
          description="Uma simulação completa do fluxo da app: seleção de fotografia, pré-visualização, tracking e controlos de desempenho. Mexe em tudo — nada sai do teu browser."
          aside={
            <div className="flex flex-col items-start gap-2 lg:items-end">
              <StatusPill tone="warn" dot>
                demonstração visual
              </StatusPill>
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/32">
                sem processamento de vídeo
              </span>
            </div>
          }
        />

        <div className="mt-10 grid items-start gap-8 lg:grid-cols-[minmax(0,1fr)_370px] lg:gap-12 xl:grid-cols-[minmax(0,1fr)_382px]">
          {/* Controls */}
          <div className="card gradient-border relative overflow-hidden p-4 sm:p-6">
            <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-electric/[0.07] to-transparent" />

            <div className="relative flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <SlidersHorizontal size={13} className="text-electric-soft" />
                  <span className="mono-label text-white/55">Sessão 001</span>
                </div>
                <h3 className="mt-2 font-display text-lg font-semibold tracking-tight text-white">
                  Fotografia de origem
                </h3>
              </div>
              <StatusPill tone="success" dot>
                local
              </StatusPill>
            </div>

            <div className="relative mt-4 grid grid-cols-4 gap-2 sm:gap-2.5">
              {faces.map((sample) => {
                const active = sample.id === face.id;
                return (
                  <button
                    key={sample.id}
                    type="button"
                    onClick={() => {
                      setFace(sample);
                      setUploadError(null);
                    }}
                    aria-pressed={active}
                    aria-label={`Usar o rosto de ${sample.name} na demonstração`}
                    className={cn(
                      "group relative aspect-square overflow-hidden rounded-xl border-2 text-left transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-soft focus-visible:ring-offset-2 focus-visible:ring-offset-night",
                      active
                        ? "border-electric-soft shadow-[0_0_0_3px_rgba(124,92,255,0.18)]"
                        : "border-transparent opacity-80 hover:border-white/25 hover:opacity-100"
                    )}
                  >
                    <img
                      src={sample.thumb}
                      alt={`Retrato de exemplo ${sample.name}`}
                      className="h-full w-full object-cover object-top transition duration-300 group-hover:scale-105"
                      loading="lazy"
                    />
                    <span className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                    <span className="absolute inset-x-1.5 bottom-1 truncate text-[8.5px] font-bold text-white/85">
                      {sample.name}
                    </span>
                    {active ? (
                      <span className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-gradient-to-br from-electric to-azure text-white shadow">
                        <Check size={9} strokeWidth={3.5} />
                      </span>
                    ) : null}
                  </button>
                );
              })}

              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                aria-label="Carregar uma fotografia do dispositivo"
                className="group flex aspect-square flex-col items-center justify-center gap-1.5 rounded-xl border-2 border-dashed border-white/15 bg-white/[0.025] text-white/52 transition hover:border-electric-soft/50 hover:bg-electric/[0.07] hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-electric-soft focus-visible:ring-offset-2 focus-visible:ring-offset-night"
              >
                <ImagePlus size={17} strokeWidth={1.7} className="transition group-hover:scale-110" />
                <span className="text-[8.5px] font-bold">Carregar</span>
              </button>
              <input
                ref={inputRef}
                type="file"
                accept="image/jpeg,image/png,image/webp,image/*"
                className="sr-only"
                onChange={(e) => {
                  handleUpload(e.target.files?.[0]);
                  e.currentTarget.value = "";
                }}
              />
            </div>

            <a
              href="#preview-demo"
              className="mt-2.5 flex items-center justify-between gap-2 rounded-lg border border-white/[0.06] bg-white/[0.02] px-2.5 py-1.5 text-[9px] font-bold text-white/45 transition hover:text-white lg:hidden"
            >
              Ver pré-visualização atualizada
              <span aria-hidden="true">↓</span>
            </a>

            {uploadError ? (
              <p role="alert" className="mt-2.5 rounded-lg border border-rose-400/20 bg-rose-400/10 px-3 py-2 text-[10.5px] text-rose-200">
                {uploadError}
              </p>
            ) : null}

            <div className="mt-3 flex items-center gap-2.5 rounded-xl border border-white/[0.07] bg-black/20 p-2">
              <div className="h-9 w-9 shrink-0 overflow-hidden rounded-lg border border-white/10">
                <img src={face.thumb} alt="" className="h-full w-full object-cover object-top" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[10.5px] font-bold text-white/80">{face.name}</p>
                <p className="truncate font-mono text-[8px] uppercase tracking-[0.12em] text-white/42">
                  {face.tag}
                </p>
              </div>
              <button
                type="button"
                onClick={() => inputRef.current?.click()}
                className="inline-flex items-center gap-1 rounded-lg border border-white/10 bg-white/[0.04] px-2 py-1.5 text-[9px] font-bold text-white/55 transition hover:border-white/20 hover:text-white"
              >
                <Upload size={10} />
                Trocar
              </button>
            </div>

            <div className="hairline my-5" />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles size={13} className="text-aqua" />
                <span className="mono-label text-white/55">Controlos de efeito</span>
              </div>
              <button
                type="button"
                onClick={resetPreset}
                className="inline-flex items-center gap-1 text-[9.5px] font-semibold text-white/45 transition hover:text-white/70"
              >
                <RotateCcw size={10} />
                Repor
              </button>
            </div>

            <div className="mt-4 space-y-2.5">
              <ControlRow
                icon={<Sparkles size={13} />}
                title="Face swap"
                hint={swap ? `Intensidade ${intensity}%` : "Efeito desligado"}
              >
                <Toggle checked={swap} onChange={setSwap} label="Ativar face swap" />
              </ControlRow>

              <ControlRow
                icon={<ScanFace size={13} />}
                title="Overlay de tracking"
                hint={tracking ? "478 landmarks visíveis" : "Oculto na pré-visualização"}
              >
                <Toggle checked={tracking} onChange={setTracking} label="Mostrar overlay de tracking" />
              </ControlRow>

              <div
                className={cn(
                  "rounded-xl border border-white/[0.07] bg-white/[0.022] p-3.5 transition",
                  !swap && "opacity-45"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-white/75">Intensidade da mistura</span>
                  <span className="font-mono text-[10px] text-electric-soft">{intensity}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  step={1}
                  value={intensity}
                  disabled={!swap}
                  onChange={(e) => setIntensity(Number(e.target.value))}
                  aria-label="Intensidade da mistura do face swap"
                  className="range mt-3"
                  style={{
                    background: `linear-gradient(to right, #7c5cff 0%, #22d3ee ${intensity}%, rgba(255,255,255,0.1) ${intensity}%, rgba(255,255,255,0.1) 100%)`,
                  }}
                />
                <div className="mt-1.5 flex justify-between font-mono text-[7.5px] uppercase tracking-wider text-white/32">
                  <span>Só original</span>
                  <span>Máximo</span>
                </div>
              </div>

              <div className="grid gap-2.5 sm:grid-cols-2">
                <div className="rounded-xl border border-white/[0.07] bg-white/[0.022] p-3">
                  <div className="mb-2 flex items-center gap-1.5">
                    <Activity size={11} className="text-white/52" />
                    <span className="text-[10px] font-bold text-white/60">Qualidade</span>
                  </div>
                  <Segmented
                    options={qualityOptions}
                    value={quality}
                    onChange={setQuality}
                    label="Qualidade de processamento"
                  />
                </div>
                <div className="rounded-xl border border-white/[0.07] bg-white/[0.022] p-3">
                  <div className="mb-2 flex items-center gap-1.5">
                    <Camera size={11} className="text-white/52" />
                    <span className="text-[10px] font-bold text-white/60">Câmara</span>
                  </div>
                  <Segmented
                    options={cameraOptions}
                    value={camera}
                    onChange={setCamera}
                    label="Seleção de câmara"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-2 rounded-xl border border-white/[0.07] bg-white/[0.022] px-3.5 py-3 sm:flex-row sm:items-center sm:justify-between">
                <ControlLabel
                  icon={<Laptop size={13} />}
                  title="Espelhar pré-visualização"
                  hint="Só afeta o ecrã, não o vídeo guardado"
                />
                <Toggle checked={mirror} onChange={setMirror} label="Espelhar pré-visualização" size="sm" />
              </div>

              <div className="flex items-center justify-between gap-3 rounded-xl border border-white/[0.07] bg-white/[0.022] px-3.5 py-2.5">
                <span className="flex items-center gap-1.5 font-mono text-[8.5px] uppercase tracking-[0.12em] text-white/45">
                  <Activity size={10} />
                  {qualityModes[quality].hint}
                </span>
                <span className="font-mono text-[9px] text-aqua">{qualityModes[quality].latency}</span>
              </div>
            </div>

            <div className="mt-4 flex gap-2.5 rounded-xl border border-amber-200/15 bg-amber-200/[0.055] p-3">
              <Info size={14} className="mt-px shrink-0 text-amber-200/80" />
              <p className="text-[10px] leading-relaxed text-amber-100/65">
                <strong className="font-bold text-amber-100/90">Simulação no browser.</strong> A imagem
                muda de fotografia para ilustrar o efeito; não há IA a processar vídeo. Nenhum frame é
                enviado ou usado para treinar modelos. Usa apenas imagens que tenhas autorização para
                utilizar.
              </p>
            </div>

            <div className="mt-4 flex flex-col gap-2 sm:flex-row">
              <button type="button" onClick={persistPreset} className="btn-secondary flex-1 !rounded-xl !py-3 text-[11px]">
                <Save size={13} />
                Guardar predefinição
              </button>
              <a href="#compatibilidade" className="btn-primary flex-1 !rounded-xl !py-3 text-[11px]">
                Ver limitações reais
                <ArrowUpRight size={13} />
              </a>
            </div>

            {toast ? (
              <div
                role="status"
                className="mt-3 flex items-center gap-2 rounded-xl border border-mint/20 bg-mint/[0.08] px-3 py-2 text-[10.5px] font-semibold text-[#a6f3d4]"
              >
                <Check size={12} />
                {toast}
              </div>
            ) : null}
          </div>

          {/* Live preview */}
          <div id="preview-demo" className="relative scroll-mt-24 lg:sticky lg:top-24">
            <div className="mb-4 flex items-center justify-between">
              <span className="mono-label">Pré-visualização</span>
              <div className="flex items-center gap-1.5">
                <span
                  className={cn(
                    "h-1.5 w-1.5 rounded-full",
                    swap ? "animate-pulse bg-mint" : "bg-white/25"
                  )}
                />
                <span className="font-mono text-[8px] uppercase tracking-[0.12em] text-white/45">
                  {swap ? "efeito ativo" : "efeito desligado"}
                </span>
              </div>
            </div>
            <PhoneMockup
              face={face}
              swap={swap}
              onSwapChange={setSwap}
              tracking={tracking}
              intensity={intensity}
              mirror={mirror}
              compactControls
            />
            <div className="mx-auto mt-5 flex max-w-[330px] items-start gap-2 rounded-xl border border-white/[0.07] bg-white/[0.022] px-3 py-2.5">
              <Info size={13} className="mt-px shrink-0 text-white/42" />
              <p className="text-[9.5px] leading-relaxed text-white/45">
                Marca de simulação sempre visível. O ecrã de chamada é uma <strong className="font-semibold text-white/55">representação da interface da app</strong>,
                não uma chamada de WhatsApp ou Messenger.
              </p>
            </div>

            <div className="mx-auto mt-3 max-w-[330px] rounded-xl border border-white/[0.07] bg-white/[0.022] p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-mint" aria-hidden="true" />
                  <span className="mono-label text-white/55">Definições & permissões</span>
                </div>
                <span className="font-mono text-[7px] uppercase tracking-[0.12em] text-white/32">sem root</span>
              </div>
              <div className="mt-2.5 divide-y divide-white/[0.055]">
                {[
                  { icon: Camera, label: "Câmara", hint: "Necessária", status: "concedida", tone: "mint" },
                  { icon: Images, label: "Fotografias", hint: "Só a selecionada", status: "concedida", tone: "mint" },
                  { icon: Mic, label: "Microfone", hint: "Só em chamadas", status: "opcional", tone: "warn" },
                  { icon: Layers, label: "Sobreposição", hint: "Não utilizada", status: "não pedida", tone: "muted" },
                ].map(({ icon: Icon, label, hint, status, tone }) => (
                  <div key={label} className="flex items-center justify-between gap-2 py-2 first:pt-0 last:pb-0">
                    <span className="flex min-w-0 items-center gap-2">
                      <Icon size={11} className="shrink-0 text-white/32" />
                      <span className="truncate text-[10px] font-semibold text-white/60">{label}</span>
                      <span className="hidden truncate text-[8.5px] text-white/28 sm:inline">{hint}</span>
                    </span>
                    <span
                      className={cn(
                        "shrink-0 font-mono text-[7.5px] uppercase tracking-[0.1em]",
                        tone === "mint" ? "text-mint/75" : tone === "warn" ? "text-amber-200/65" : "text-white/28"
                      )}
                    >
                      {status}
                    </span>
                  </div>
                ))}
              </div>
              <p className="mt-2.5 border-t border-white/[0.055] pt-2 text-[8px] leading-relaxed text-white/28">
                Ecrã de definições da app. No Android, o sistema pede e controla cada permissão.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ControlRow({
  icon,
  title,
  hint,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  hint: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-white/[0.07] bg-white/[0.022] px-3.5 py-3">
      <ControlLabel icon={icon} title={title} hint={hint} />
      {children}
    </div>
  );
}

function ControlLabel({
  icon,
  title,
  hint,
}: {
  icon: React.ReactNode;
  title: string;
  hint: string;
}) {
  return (
    <div className="flex min-w-0 items-center gap-2.5">
      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/[0.055] text-white/45">
        {icon}
      </span>
      <div className="min-w-0">
        <p className="text-[11px] font-bold text-white/75">{title}</p>
        <p className="mt-0.5 truncate text-[9px] text-white/42">{hint}</p>
      </div>
    </div>
  );
}
