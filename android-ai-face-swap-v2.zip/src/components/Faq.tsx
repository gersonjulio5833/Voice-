import { BookOpen, Plus, ShieldCheck, Sparkles } from "lucide-react";
import { faqs } from "@/data/content";

export function Faq() {
  return (
    <section id="faq" className="relative scroll-mt-24 py-20 sm:py-24">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      <div className="wrap">
        <div className="grid gap-10 lg:grid-cols-[0.78fr_1.22fr] lg:gap-16">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <span className="eyebrow text-electric-soft/90">
              <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-electric-soft to-aqua" />
              Perguntas frequentes
            </span>
            <h2 className="section-title mt-4">
              Sem letra miúda.
            </h2>
            <p className="body-copy mt-4 max-w-sm">
              As respostas às perguntas que realmente importam — incluindo as que são incómodas para
              qualquer promessa de face swap em chamadas de terceiros.
            </p>

            <div className="mt-7 rounded-2xl border border-mint/15 bg-mint/[0.035] p-4">
              <div className="flex items-center gap-2">
                <ShieldCheck size={14} className="text-mint" />
                <span className="text-[11px] font-bold text-white/75">Uso responsável</span>
              </div>
              <ul className="mt-2.5 space-y-1.5 text-[10px] leading-relaxed text-white/45">
                {[
                  "Usa apenas imagens de quem deu autorização.",
                  "Mantém a marca de simulação visível.",
                  "Nunca uses para fraude ou impersonação.",
                  "Não explores figuras públicas ou menores.",
                ].map((item) => (
                  <li key={item} className="flex gap-1.5">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-mint/60" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <a href="#demo" className="group mt-4 inline-flex items-center gap-2 text-[11px] font-bold text-electric-soft transition hover:text-white">
              <Sparkles size={12} />
              Voltar ao estúdio
            </a>
          </div>

          <div className="divide-y divide-white/[0.07] border-y border-white/[0.07]">
            {faqs.map((faq, i) => (
              <details key={faq.q} className="group" open={i === 0}>
                <summary className="flex cursor-pointer list-none items-start justify-between gap-4 py-5 text-left [&::-webkit-details-marker]:hidden">
                  <span className="flex gap-3">
                    <span className="mt-0.5 hidden font-mono text-[9px] text-white/20 sm:block">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="text-[12.5px] font-bold leading-snug text-white/70 transition group-hover:text-white group-open:text-white sm:text-[13.5px]">
                      {faq.q}
                    </span>
                  </span>
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border border-white/[0.08] bg-white/[0.03] text-white/45 transition group-open:rotate-45 group-open:border-electric-soft/25 group-open:bg-electric/10 group-open:text-electric-soft">
                    <Plus size={12} />
                  </span>
                </summary>
                <div className="pb-5 pl-0 pr-8 sm:pl-8">
                  <p className="text-[11.5px] leading-relaxed text-white/38">{faq.a}</p>
                </div>
              </details>
            ))}

            <div className="flex flex-col gap-3 py-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2.5">
                <BookOpen size={14} className="text-white/42" />
                <p className="text-[10.5px] leading-relaxed text-white/42">
                  Queres a arquitetura completa e os comandos de build?
                </p>
              </div>
              <a href="#projeto" className="btn-secondary !rounded-lg !px-3 !py-2 text-[10px]">
                Abrir código & APK
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
