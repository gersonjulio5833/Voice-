import { AlertTriangle, ArrowUpRight, Ban, Check, FlaskConical, Info, MonitorUp, ShieldOff, X } from "lucide-react";
import { alternatives } from "@/data/content";
import { SectionHeading, StatusPill } from "@/components/ui";
import { cn } from "@/utils/cn";

const apps = [
  {
    name: "WhatsApp",
    company: "Meta",
    color: "from-[#39d475] to-[#16a34a]",
    glow: "bg-[#25d366]/15",
    logo: <WhatsAppMark />,
  },
  {
    name: "Messenger",
    company: "Meta",
    color: "from-[#4f8dff] via-[#8b5cf6] to-[#ec4899]",
    glow: "bg-[#7c5cff]/15",
    logo: <MessengerMark />,
  },
];

const androidMatrix = [
  {
    title: "Câmara virtual pública",
    state: "Indisponível",
    tone: "danger",
    body: "O Android não expõe uma API de câmara virtual para apps de consumo escolherem o stream de outra app.",
  },
  {
    title: "Captura de ecrã",
    state: "Parcial",
    tone: "warn",
    body: "MediaProjection captura o ecrã com consentimento. Não injeta frames na câmara de outra app.",
  },
  {
    title: "Sobreposição flutuante",
    state: "Não serve",
    tone: "danger",
    body: "Um overlay fica por cima do ecrã local. A pessoa do outro lado continua a ver o vídeo original.",
  },
  {
    title: "Videochamada WebRTC própria",
    state: "Suportado",
    tone: "success",
    body: "A app controla a câmara e o frame processado. É o único caminho completo sem root.",
  },
];

export function Compatibility() {
  return (
    <section id="compatibilidade" className="relative scroll-mt-24 overflow-hidden py-20 sm:py-24">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        <div className="absolute -left-40 top-1/3 h-[460px] w-[460px] rounded-full bg-rose-500/[0.055] blur-3xl" />
        <div className="absolute -right-40 bottom-0 h-[420px] w-[420px] rounded-full bg-amber-400/[0.045] blur-3xl" />
      </div>

      <div className="wrap relative">
        <SectionHeading
          eyebrow="Compatibilidade real"
          title={
            <>
              A parte que ninguém
              <br />
              <span className="text-white/52">gosta de dizer.</span>
            </>
          }
          description="Pesquisámos o que o Android permite hoje. O resultado é claro: sem root, nenhuma app consegue substituir o vídeo da câmara usada pelo WhatsApp ou pelo Messenger. Aqui está o porquê e o que é possível construir."
          aside={
            <div className="flex items-center gap-2 rounded-full border border-rose-400/20 bg-rose-400/[0.07] px-3 py-1.5">
              <ShieldOff size={12} className="text-rose-300" />
              <span className="font-mono text-[9px] uppercase tracking-[0.12em] text-rose-200/80">
                integração não suportada
              </span>
            </div>
          }
        />

        {/* Target apps */}
        <div className="mt-10 grid gap-3.5 sm:grid-cols-2">
          {apps.map((app) => (
            <div
              key={app.name}
              className="card group relative overflow-hidden border-white/[0.07] p-5 sm:p-6"
            >
              <div className={cn("pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full blur-2xl", app.glow)} />
              <div className="relative flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className={cn("flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br text-white shadow-lg", app.color)}>
                    {app.logo}
                  </div>
                  <div>
                    <h3 className="font-display text-[15px] font-semibold text-white">{app.name}</h3>
                    <p className="mt-0.5 font-mono text-[8px] uppercase tracking-[0.14em] text-white/42">
                      {app.company} · videochamadas
                    </p>
                  </div>
                </div>
                <StatusPill tone="danger">sem suporte</StatusPill>
              </div>

              <div className="relative mt-5 space-y-2 border-t border-white/[0.07] pt-4">
                {[
                  ["Câmara controlada pela app", "Sim"],
                  ["API pública de câmara virtual", "Não"],
                  ["Injeção do nosso vídeo", "Requer root"],
                  ["Integração testada neste projeto", "Não"],
                ].map(([label, value]) => (
                  <div key={label} className="flex items-center justify-between gap-3">
                    <span className="text-[10.5px] text-white/45">{label}</span>
                    <span
                      className={cn(
                        "font-mono text-[8.5px] uppercase tracking-wider",
                        value === "Sim" ? "text-mint/75" : value === "Não" ? "text-white/32" : "text-rose-300/70"
                      )}
                    >
                      {value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Verdict */}
        <div className="gradient-border relative mt-4 overflow-hidden rounded-[1.75rem] bg-[#120d1e] p-5 sm:p-7">
          <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-amber-400/10 blur-3xl" />
          <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex max-w-2xl gap-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-amber-200/20 bg-amber-200/[0.08] text-amber-200">
                <AlertTriangle size={19} />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-[8.5px] uppercase tracking-[0.18em] text-amber-200/70">veredito técnico</span>
                  <span className="h-1 w-1 rounded-full bg-white/20" />
                  <span className="font-mono text-[8.5px] uppercase tracking-[0.12em] text-white/32">fevereiro 2026</span>
                </div>
                <h3 className="mt-2 font-display text-[1.2rem] font-semibold leading-snug tracking-tight text-white sm:text-[1.35rem]">
                  “Injetar o vídeo processado numa chamada de terceiros sem root” não é possível com APIs públicas.
                </h3>
                <p className="mt-2 text-[11.5px] leading-relaxed text-white/52">
                  Qualquer promessa em contrário exige modificar o sistema ou o processo da outra app.
                  AI Face Live recusa esse caminho: sem root, sem bootloader desbloqueado, sem
                  formatação e sem riscos para os teus dados.
                </p>
              </div>
            </div>
            <a href="#faq" className="btn-secondary shrink-0 !rounded-xl !px-4 !py-3 text-[11px]">
              Ler explicação completa
              <ArrowUpRight size={13} />
            </a>
          </div>
        </div>

        {/* Alternatives */}
        <div className="mt-12">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="mono-label">Arquiteturas alternativas</p>
              <h3 className="mt-2 font-display text-[1.35rem] font-semibold tracking-tight text-white">
                Onde o vídeo processado <span className="text-gradient">pode mesmo chegar.</span>
              </h3>
            </div>
            <span className="font-mono text-[8.5px] uppercase tracking-[0.14em] text-white/32">
              sem root · sem hooks
            </span>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {alternatives.map((alt) => {
              const tone =
                alt.status === "suportado"
                  ? "success"
                  : alt.status === "parcial"
                  ? "warn"
                  : alt.status === "externo"
                  ? "info"
                  : "danger";
              return (
                <div key={alt.title} className="card group p-5 transition hover:border-white/[0.15]">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <span
                        className={cn(
                          "flex h-8 w-8 items-center justify-center rounded-lg border",
                          alt.status === "suportado"
                            ? "border-mint/20 bg-mint/[0.08] text-mint"
                            : alt.status === "parcial"
                            ? "border-amber-200/20 bg-amber-200/[0.07] text-amber-200"
                            : alt.status === "externo"
                            ? "border-aqua/20 bg-aqua/[0.07] text-aqua"
                            : "border-rose-400/20 bg-rose-400/[0.07] text-rose-300"
                        )}
                      >
                        {alt.status === "suportado" ? (
                          <Check size={14} />
                        ) : alt.status === "parcial" ? (
                          <MonitorUp size={14} />
                        ) : alt.status === "externo" ? (
                          <MonitorUp size={14} />
                        ) : (
                          <Ban size={14} />
                        )}
                      </span>
                      <h4 className="text-[12.5px] font-bold text-white/85">{alt.title}</h4>
                    </div>
                    <StatusPill tone={tone} dot>{alt.statusLabel}</StatusPill>
                  </div>
                  <p className="mt-3 text-[11px] leading-relaxed text-white/52">{alt.body}</p>
                  <p className="mt-3 flex items-start gap-1.5 border-t border-white/[0.06] pt-3 font-mono text-[8.5px] leading-relaxed uppercase tracking-[0.08em] text-white/32">
                    <Info size={10} className="mt-0.5 shrink-0" />
                    {alt.caveat}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Matrix */}
        <div className="mt-10 overflow-hidden rounded-2xl border border-white/[0.08]">
          <div className="flex items-center justify-between gap-3 border-b border-white/[0.07] bg-white/[0.025] px-4 py-3 sm:px-5">
            <div className="flex items-center gap-2">
              <FlaskConical size={13} className="text-electric-soft" />
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/45">
                matriz de compatibilidade · capacidades Android
              </span>
            </div>
            <span className="hidden font-mono text-[8px] uppercase tracking-[0.12em] text-white/20 sm:block">
              sem root
            </span>
          </div>
          <div className="grid divide-y divide-white/[0.06] sm:grid-cols-2 sm:divide-x sm:divide-y-0 lg:grid-cols-4 lg:divide-y-0">
            {androidMatrix.map((row) => (
              <div key={row.title} className="border-b border-white/[0.06] p-4 last:border-b-0 sm:border-b-0 lg:border-r lg:last:border-r-0">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10.5px] font-bold text-white/65">{row.title}</span>
                  {row.tone === "success" ? (
                    <Check size={12} className="text-mint" />
                  ) : row.tone === "warn" ? (
                    <AlertTriangle size={12} className="text-amber-200/70" />
                  ) : (
                    <X size={12} className="text-rose-300/70" />
                  )}
                </div>
                <p className="mt-2 text-[9px] uppercase tracking-[0.1em] text-white/32">{row.state}</p>
                <p className="mt-1.5 text-[9.5px] leading-relaxed text-white/42">{row.body}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-4 flex items-start gap-2 px-1">
          <Info size={12} className="mt-0.5 shrink-0 text-white/20" />
          <p className="text-[9.5px] leading-relaxed text-white/32">
            Baseado na documentação pública do Android (Camera2, CameraX, MediaProjection e
            acessibilidade) e no comportamento conhecido de apps de terceiros. Não foi possível
            realizar uma integração real nesta sessão, pelo que não declaramos qualquer
            compatibilidade prática com WhatsApp ou Messenger.
          </p>
        </div>
      </div>
    </section>
  );
}

function WhatsAppMark() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" aria-hidden="true">
      <path
        d="M20.2 11.8a8.2 8.2 0 0 1-12.1 7.2L3.6 20.4l1.4-4.4A8.2 8.2 0 1 1 20.2 11.8Z"
        stroke="white"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path
        d="M8.9 8.1c.3-.5.6-.5.9-.5h.5c.2 0 .4.1.5.4l.6 1.4c.1.2 0 .4-.1.6l-.5.6c-.1.2-.2.3 0 .6.3.5.7 1 1.2 1.4.5.4 1 .7 1.4.9.2.1.4.1.5-.1l.6-.7c.2-.2.3-.2.5-.1l1.5.7c.2.1.3.2.3.4v.5c0 .4-.2.8-.5 1.1-.4.4-.9.6-1.5.6-.6 0-1.5-.2-2.7-.8-1.1-.5-2-1.3-2.7-2.1-.7-.9-1.1-1.8-1.1-2.4 0-.6.2-1.1.6-1.5Z"
        fill="white"
      />
    </svg>
  );
}

function MessengerMark() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" aria-hidden="true">
      <path
        d="M12 3.4c-4.9 0-8.5 3.6-8.5 8.2 0 2.5 1.1 4.7 2.8 6.1v2.9l2.7-1.5c.9.3 1.9.4 3 .4 4.9 0 8.5-3.6 8.5-8.2S16.9 3.4 12 3.4Z"
        stroke="white"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path d="m7.6 14.1 3.2-3.5 2.1 2 3.3-2-3.1 3.4-2.1-2.1-3.4 2.2Z" fill="white" />
    </svg>
  );
}
