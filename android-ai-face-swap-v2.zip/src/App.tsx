import { useState } from "react";
import type { FaceSample } from "@/data/content";
import { faces } from "@/data/content";
import { Navbar, FinalCta, Footer } from "@/components/Layout";
import { Hero } from "@/components/Hero";
import { Features } from "@/components/Features";
import { DemoStudio } from "@/components/DemoStudio";
import { Compatibility } from "@/components/Compatibility";
import { Pipeline } from "@/components/Pipeline";
import { BuildSection } from "@/components/BuildSection";
import { Faq } from "@/components/Faq";

export default function App() {
  const [activeFace, setActiveFace] = useState<FaceSample>(faces[0]);
  const [heroSwap, setHeroSwap] = useState(true);

  return (
    <div className="min-h-screen overflow-x-hidden bg-night text-white">
      <a
        href="#top"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-sm focus:font-bold focus:text-night"
      >
        Saltar para o conteúdo
      </a>

      <Navbar />

      <main>
        <Hero face={activeFace} swap={heroSwap} onSwapChange={setHeroSwap} />
        <Features />
        <div className="hairline" />
        <DemoStudio face={activeFace} setFace={setActiveFace} />
        <div className="hairline" />
        <Compatibility />
        <div className="hairline" />
        <Pipeline />
        <BuildSection />
        <Faq />
        <FinalCta />
      </main>

      <Footer />
    </div>
  );
}
