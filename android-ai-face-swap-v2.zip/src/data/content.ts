export type FaceSample = {
  id: string;
  name: string;
  tag: string;
  url: string;
  thumb: string;
  accent: string;
};

const px = (id: number, w: number, h: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const feedImage = px(31585407, 900, 1350);

export const faces: FaceSample[] = [
  {
    id: "noah",
    name: "Noah",
    tag: "Retrato frontal",
    url: px(7597466, 900, 1350),
    thumb: px(7597466, 400, 400),
    accent: "#7c5cff",
  },
  {
    id: "amara",
    name: "Amara",
    tag: "Luz natural",
    url: px(8508753, 900, 1350),
    thumb: px(8508753, 400, 400),
    accent: "#22d3ee",
  },
  {
    id: "maya",
    name: "Maya",
    tag: "Fundo claro",
    url: px(40027139, 900, 1350),
    thumb: px(40027139, 400, 400),
    accent: "#f472b6",
  },
  {
    id: "elena",
    name: "Elena",
    tag: "Expressão neutra",
    url: px(8727416, 900, 1350),
    thumb: px(8727416, 400, 400),
    accent: "#34d399",
  },
  {
    id: "daniel",
    name: "Daniel",
    tag: "Retrato estúdio",
    url: px(6338326, 900, 1350),
    thumb: px(6338326, 400, 400),
    accent: "#fb923c",
  },
  {
    id: "ines",
    name: "Inês",
    tag: "Fundo castanho",
    url: px(8727392, 900, 1350),
    thumb: px(8727392, 400, 400),
    accent: "#a78bfa",
  },
];

export const imageCredits =
  "Retratos de exemplo: Michael Obstoj, Alexandru Molnar, Ivan S, Smooth Models, Tima Miroshnichenko, ShotPot e Pexels.";

export type QualityKey = "economy" | "balanced" | "max";

export const qualityModes: Record<QualityKey, { label: string; hint: string; latency: string }> = {
  economy: { label: "Económico", hint: "720p · 24 fps alvo", latency: "~18 ms/frame" },
  balanced: { label: "Equilibrado", hint: "1080p · 30 fps alvo", latency: "~28 ms/frame" },
  max: { label: "Máximo", hint: "1080p+ · 30 fps alvo", latency: "~42 ms/frame" },
};

export const capabilities = [
  {
    icon: "gallery",
    title: "A fotografia certa",
    body: "Seleciona uma imagem da galeria, revê o recorte facial e confirma antes de ativar o efeito.",
    meta: "Foto local · sem upload",
  },
  {
    icon: "scan",
    title: "Tracking que acompanha",
    body: "Olhos, boca, sobrancelhas e inclinação da cabeça são seguidos frame a frame com landmarks faciais.",
    meta: "MediaPipe · GPU",
  },
  {
    icon: "gpu",
    title: "Renderização na GPU",
    body: "Alinhamento, warp e mistura de cor acontecem num pipeline OpenGL ES, com presets de desempenho.",
    meta: "OpenGL ES 3.0",
  },
  {
    icon: "shield",
    title: "Privacidade por desenho",
    body: "A fotografia e o vídeo ficam no dispositivo. Sem contas, sem servidores e sem telemetria de imagem.",
    meta: "On-device",
  },
  {
    icon: "sliders",
    title: "Controlo real",
    body: "Liga e desliga o efeito, escolhe a câmara, ajusta a intensidade e a qualidade de processamento.",
    meta: "Configurável",
  },
  {
    icon: "mobile",
    title: "Feito para vários Android",
    body: "Android 8.0+, CameraX e fallbacks por hardware. Não está preso a uma marca nem a um modelo.",
    meta: "minSdk 26",
  },
];

export const pipeline = [
  {
    step: "01",
    title: "Captura",
    tech: "CameraX",
    body: "Preview e ImageAnalysis em YUV_420_888. Escolha de câmara frontal/traseira e resolução adaptativa.",
    detail: "ImageProxy → frame buffer partilhado",
  },
  {
    step: "02",
    title: "Tracking facial",
    tech: "MediaPipe",
    body: "Face Landmarker em modo LIVE_STREAM devolve landmarks, blendshapes e matriz de transformação.",
    detail: "478 pontos · expressões · roll/euler",
  },
  {
    step: "03",
    title: "Face swap",
    tech: "TFLite + GPU",
    body: "Embedding da foto-fonte, alinhamento para a pose atual, inferência e correção de cor. Exige um modelo com licença adequada.",
    detail: "Modelo não incluído no protótipo",
  },
  {
    step: "04",
    title: "Composição",
    tech: "OpenGL ES",
    body: "Warp, blending e grão final para um SurfaceTexture. O frame fica disponível para preview, gravação ou videochamada interna.",
    detail: "EGL · shaders · 16:9",
  },
];

export const alternatives = [
  {
    title: "Chamada dentro da app",
    status: "suportado",
    statusLabel: "Caminho recomendado",
    body: "Com WebRTC, a app é dona da câmara e do frame. O vídeo processado pode ser enviado na própria chamada sem depender de terceiros.",
    caveat: "Não é uma chamada do WhatsApp/Messenger.",
  },
  {
    title: "Partilha de ecrã",
    status: "parcial",
    statusLabel: "Dependente da app",
    body: "MediaProjection permite capturar o ecrã. Só ajuda se a outra app tiver partilha de ecrã durante a chamada e aceitar essa fonte.",
    caveat: "O WhatsApp não oferece partilha de ecrã em chamadas 1:1 em todas as versões.",
  },
  {
    title: "Câmara virtual no PC",
    status: "externo",
    statusLabel: "Fora do Android",
    body: "No desktop, uma câmara virtual (OBS, por exemplo) pode ser escolhida por Zoom, Meet, Discord e navegador. É outra arquitetura de produto.",
    caveat: "Não resolve chamadas feitas diretamente no telemóvel.",
  },
  {
    title: "Root / hooks",
    status: "excluído",
    statusLabel: "Contra os requisitos",
    body: "Injetar frames no processo de outra app exige root, LSPosed ou ferramentas semelhantes. Tecnicamente existe; está excluído por segurança.",
    caveat: "Não será implementado nem recomendado.",
  },
];

export const stack = [
  "Kotlin",
  "Android SDK",
  "CameraX",
  "MediaPipe",
  "TensorFlow Lite",
  "OpenGL ES 3.0",
  "GitHub Actions",
  "Jetpack",
];

export const projectTree = `ai-face-live/
├── .github/
│   └── workflows/build.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/app/aifacelive/
│       │   ├── MainActivity.kt
│       │   ├── camera/CameraController.kt
│       │   ├── face/FaceLandmarkProcessor.kt
│       │   ├── swap/FaceSwapPipeline.kt
│       │   ├── render/GlesFaceRenderer.kt
│       │   └── ui/PreviewScreen.kt
│       └── res/...
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew
└── README.md`;

export const buildFiles = [
  {
    id: "workflow",
    label: "build.yml",
    path: ".github/workflows/build.yml",
    language: "yaml",
    code: `name: Build AI Face Live APK

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - uses: android-actions/setup-android@v3

      - name: Cache Gradle
        uses: actions/cache@v4
        with:
          path: ~/.gradle/caches
          key: gradle-\${{ hashFiles('**/*.gradle*') }}

      - name: Make Gradle executable
        run: chmod +x ./gradlew

      - name: Build debug APK
        run: ./gradlew :app:assembleDebug --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: ai-face-live-debug
          path: app/build/outputs/apk/debug/*.apk
          retention-days: 30`,
  },
  {
    id: "manifest",
    label: "AndroidManifest.xml",
    path: "app/src/main/AndroidManifest.xml",
    language: "xml",
    code: `<manifest
  xmlns:android="http://schemas.android.com/apk/res/android">

  <uses-feature
    android:name="android.hardware.camera.any"
    android:required="true" />

  <uses-permission
    android:name="android.permission.CAMERA" />
  <uses-permission
    android:name="android.permission.READ_MEDIA_IMAGES" />
  <uses-permission
    android:name="android.permission.READ_EXTERNAL_STORAGE"
    android:maxSdkVersion="32" />

  <application
    android:allowBackup="false"
    android:label="AI Face Live"
    android:theme="@style/Theme.AIFaceLive">

    <activity
      android:name=".MainActivity"
      android:exported="true"
      android:screenOrientation="portrait">
      <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category
          android:name="android.intent.category.LAUNCHER" />
      </intent-filter>
    </activity>
  </application>
</manifest>`,
  },
  {
    id: "gradle",
    label: "build.gradle.kts",
    path: "app/build.gradle.kts",
    language: "kotlin",
    code: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "app.aifacelive"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.aifacelive"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.9.0"
    }

    buildFeatures { compose = true }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    implementation("com.google.mediapipe:tasks-vision:0.10.21")
    implementation("org.tensorflow:tensorflow-lite-gpu:2.16.1")
    // UI, lifecycle, Compose — ver catálogo de versões no repo
}`,
  },
  {
    id: "pipeline",
    label: "FaceSwapPipeline.kt",
    path: "app/src/main/java/app/aifacelive/swap/FaceSwapPipeline.kt",
    language: "kotlin",
    code: `/**
 * Esqueleto de orquestração — NÃO é um motor completo.
 * O modelo de inferência e os shaders finais não estão incluídos.
 * Nada aqui é usado para injetar vídeo em apps de terceiros.
 */
class FaceSwapPipeline(
    private val landmarker: FaceLandmarker,
    private val sourceEmbedding: FaceEmbedding,
    private val renderer: GlesFaceRenderer
) : ImageAnalysis.Analyzer {

    override fun analyze(image: ImageProxy) {
        image.use { frame ->
            val result = landmarker.detect(
                frame.toMediaPipeImage()
            )
            val landmarks = result.faceLandmarks()
                .firstOrNull() ?: return

            // Pose + expressão atual do utilizador
            val target = FaceTarget(
                landmarks = landmarks,
                matrix = result.facialTransformationMatrixes()
                    .firstOrNull(),
                blendshapes = result.faceBlendshapes()
            )

            // O modelo TFLite com licença adequada entra aqui.
            val swapped = swapModel.infer(
                source = sourceEmbedding,
                target = target
            )

            renderer.enqueueFrame(swapped, qualityMode)
        }
    }
}`,
  },
];

export const faqs = [
  {
    q: "O AI Face Live transforma o vídeo dentro do WhatsApp ou do Messenger?",
    a: "Não. Sem root, o Android não permite que uma app substitua o stream de câmara usado por outra app. O WhatsApp e o Messenger controlam a própria câmara e não expõem uma API pública de câmara virtual. Tudo o que prometa isso sem root deve ser tratado com desconfiança. O caminho realista são chamadas dentro da própria app ou pós-processamento de vídeo.",
  },
  {
    q: "Então para que serve a app?",
    a: "Para experimentar face swap em tempo real com tracking de expressões, pré-visualizar e gravar clips, e como base para uma videochamada WebRTC em que a própria app controla a câmara. É também um projeto de referência que podes compilar e adaptar.",
  },
  {
    q: "É necessário root ou desbloquear o bootloader?",
    a: "Não. O projeto foi desenhado para funcionar com as APIs públicas do Android. Não pede root, não faz flash de firmware e não apaga dados. As permissões previstas são câmara e acesso a imagens; microfone apenas se ativares chamadas próprias.",
  },
  {
    q: "Que telemóveis são suportados?",
    a: "O alvo mínimo é Android 8.0 (API 26) com OpenGL ES 3.0 e câmara frontal. Dispositivos com menos de 3 GB de RAM devem usar o preset Económico. A compatibilidade real depende do fabricante, do ISP da câmara e do delegate GPU disponível — não existe garantia universal sem testes físicos.",
  },
  {
    q: "A app envia as minhas fotografias para a internet?",
    a: "A arquitetura apresentada processa tudo no dispositivo. A demo neste site não processa vídeo nem envia imagens: a fotografia que carregares fica apenas na memória da página e desaparece ao recarregar. Não há autenticação nem servidor nesta demo.",
  },
  {
    q: "Posso usar o rosto de qualquer pessoa?",
    a: "Só com autorização explícita de quem aparece na imagem. Não uses figuras públicas, menores ou conteúdo íntimo de terceiros. A app deve manter a marca de simulação nos clips/presenças e evitar qualquer uso fraudulento. A licença dos pesos e das imagens tem de ser verificada antes de distribuir.",
  },
  {
    q: "O APK já está pronto a instalar?",
    a: "Este site é uma demonstração interativa do produto e da arquitetura, não um APK. O workflow de GitHub Actions incluído nos ficheiros do projeto produz um APK de debug quando o código Android completo estiver no repositório. Sem pesos de modelo licenciados, o motor não produz face swap real.",
  },
  {
    q: "Como instalo um APK no telemóvel sem computador?",
    a: "Descarrega o artifact do GitHub Actions no telemóvel, extrai o APK, abre-o e permite a instalação de fontes desconhecidas para a app de ficheiros ou browser. Confirma que o APK veio do teu próprio repositório. Depois de instalado, concede câmara e fotos só quando a app pedir.",
  },
];

export const installSteps = [
  {
    n: "01",
    title: "Envia o código",
    body: "Cria um repositório e envia o projeto Android completo com o workflow na pasta .github/workflows.",
  },
  {
    n: "02",
    title: "Corre o workflow",
    body: "Em Actions, abre Build AI Face Live APK e escolhe Run workflow. O Gradle compila o APK de debug.",
  },
  {
    n: "03",
    title: "Descarrega o artifact",
    body: "No telemóvel, abre o run, descarrega o artifact ai-face-live-debug e extrai o ficheiro .apk.",
  },
  {
    n: "04",
    title: "Instala com cuidado",
    body: "Abre o APK no telemóvel, autoriza fontes desconhecidas e confirma. Desativa essa permissão depois da instalação.",
  },
];

export const downloadGuide = `# AI FACE LIVE — Guia técnico e de compilação

> Demonstração web / arquitetura. Não é um APK pré-compilado e não inclui pesos de modelos.
> A integração direta com WhatsApp/Messenger não é suportada pelo Android sem root.

## 1. Estrutura do projeto

${projectTree}

## 2. Workflow de GitHub Actions

\`\`\`yaml
${buildFiles[0].code}
\`\`\`

## 3. Manifest (permissões mínimas)

\`\`\`xml
${buildFiles[1].code}
\`\`\`

## 4. Gradle do módulo app

\`\`\`kotlin
${buildFiles[2].code}
\`\`\`

## 5. Orquestração do pipeline (esqueleto)

\`\`\`kotlin
${buildFiles[3].code}
\`\`\`

## 6. Compilar no GitHub Actions

1. Envia o projeto para um repositório GitHub.
2. O workflow \`.github/workflows/build.yml\` corre em push para main ou manualmente.
3. Abre o run em Actions e descarrega o artifact \`ai-face-live-debug\`.
4. Extrai \`app-debug.apk\` e abre-o no telemóvel.
5. Autoriza a instalação de fontes desconhecidas temporariamente.

## 7. Instalação no telemóvel

- Android 8.0 (API 26) ou superior.
- Ativa "Instalar apps desconhecidas" para o browser/gestor de ficheiros.
- O APK de debug não é assinado para distribuição na Play Store.
- Confirma sempre a origem do ficheiro.

## 8. Limitações honestas

- O Android não expõe uma câmara virtual pública. WhatsApp e Messenger não permitem substituir o stream da câmara sem root.
- MediaProjection só captura o ecrã; não injeta frames na chamada de outra app.
- O face swap em tempo real requer um modelo TFLite compatível e licenciado. Os pesos não são distribuídos neste guia.
- A qualidade e o fps variam por fabricante e GPU.
- Usa apenas rostos para os quais tens autorização e sinaliza sempre conteúdo simulado.

## 9. Segurança

- Sem root e sem desbloquear bootloader.
- Sem formatação ou eliminação de dados.
- Permissões mínimas: câmara, imagens; microfone apenas para chamadas internas.
- Nenhum upload de fotografia na arquitetura on-device.

## 10. Privacidade e uso responsável

Este projeto é demonstrativo. Não uses a tecnologia para impersonar, enganar ou criar conteúdo não consentido. Preserva marcas de água e metadados que identifiquem a simulação.
`;
