# AI FACE LIVE — protótipo web + blueprint Android

Este repositório contém a entrega **web interativa** do produto AI Face Live: uma landing
page premium e um estúdio de demonstração que percorre o fluxo da app Android (escolha de
fotografia, pré-visualização, tracking, controlos de efeito e definições).

## O que está incluído

- Interface completa em React + Vite + Tailwind CSS, em português.
- Simulador de chamada com faces de exemplo e upload local de fotografia.
- Controlos funcionais: face swap, overlay de tracking, intensidade, qualidade, câmara e espelho.
- Predefinições guardadas no `localStorage` do browser.
- Secção de compatibilidade honesta para WhatsApp / Messenger.
- Arquitetura do pipeline Android (CameraX → MediaPipe → TFLite → OpenGL ES).
- Visualizador de ficheiros com copiar/descarregar.
- Workflow de GitHub Actions e guia técnico descarregáveis.
- Guia de instalação do APK e perguntas frequentes.

## O que NÃO está incluído

- Um APK compilado. Esta sandbox não executa o Android SDK nem gera binários Android.
- Pesos de modelos de face swap. É necessário um modelo TFLite com licença compatível.
- Integração real nas chamadas do WhatsApp ou Messenger. O Android não expõe uma câmara
  virtual pública e a injeção de vídeo em apps de terceiros exige root — excluído por requisito.

## Aplicação Android (APK instalável)

O projeto Android está na pasta [`android/`](android/README.md) (Kotlin, CameraX, MediaPipe, OpenGL ES 2.0).
O workflow `.github/workflows/android-build.yml` compila o APK no GitHub Actions. Passo a passo para
compilar e instalar: [`android/README.md`](android/README.md).

Este site é apenas a demonstração/documentação do produto; o APK real vem da pasta `android/`.

## Desenvolvimento

```bash
npm install
npm run dev
```

## Build de produção

```bash
npm run build
```

O resultado é gerado em `dist/index.html` (bundle único).

## Estrutura do frontend

```text
src/
├── App.tsx
├── index.css
├── components/
│   ├── Brand.tsx
│   ├── BuildSection.tsx
│   ├── Compatibility.tsx
│   ├── DemoStudio.tsx
│   ├── Faq.tsx
│   ├── Features.tsx
│   ├── Hero.tsx
│   ├── Layout.tsx
│   ├── PhoneMockup.tsx
│   ├── Pipeline.tsx
│   └── ui.tsx
└── data/content.ts
```

## Privacidade e uso responsável

A demo não processa vídeo, não envia imagens e não faz chamadas. Usa apenas imagens para
as quais tenhas autorização. Não utilizes esta tecnologia para impersonação, fraude ou
conteúdo enganoso. Mantém sempre a marca de simulação.
