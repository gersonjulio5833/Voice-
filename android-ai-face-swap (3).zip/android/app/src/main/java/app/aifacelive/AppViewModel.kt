package app.aifacelive

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewModelScope
import app.aifacelive.capture.SavedSnapshot
import app.aifacelive.capture.SnapshotSaver
import app.aifacelive.engine.EngineStats
import app.aifacelive.engine.FaceSwapEngine
import app.aifacelive.face.Delaunay
import app.aifacelive.face.SourcePhoto
import app.aifacelive.face.StillFaceDetector
import app.aifacelive.settings.AppSettings
import app.aifacelive.settings.SettingsStore
import app.aifacelive.util.CheckResult
import app.aifacelive.util.CheckStatus
import app.aifacelive.util.Compatibility
import app.aifacelive.util.Images
import app.aifacelive.util.hasCameraPermission
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/** Fotografia escolhida pelo utilizador antes de ser confirmada. */
sealed interface Candidate {
    data object None : Candidate
    data object Loading : Candidate
    class Ready(val photo: SourcePhoto) : Candidate
    class Failed(val reason: String) : Candidate
}

private class NoFaceException : Exception("Sem rosto")

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val settingsStore = SettingsStore(appContext)

    val settings: StateFlow<AppSettings> = settingsStore.state
    val engine = FaceSwapEngine(appContext)
    val stats: StateFlow<EngineStats> = engine.stats

    private val _source = MutableStateFlow<SourcePhoto?>(null)
    val source: StateFlow<SourcePhoto?> = _source.asStateFlow()

    private val _candidate = MutableStateFlow<Candidate>(Candidate.None)
    val candidate: StateFlow<Candidate> = _candidate.asStateFlow()

    private val _swapOn = MutableStateFlow(true)
    val swapOn: StateFlow<Boolean> = _swapOn.asStateFlow()

    private val _snapshot = MutableStateFlow<SavedSnapshot?>(null)
    val lastSnapshot: StateFlow<SavedSnapshot?> = _snapshot.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _compatResults = MutableStateFlow<List<CheckResult>>(emptyList())
    val compatResults: StateFlow<List<CheckResult>> = _compatResults.asStateFlow()

    private val _compatRunning = MutableStateFlow(false)
    val compatRunning: StateFlow<Boolean> = _compatRunning.asStateFlow()

    private val detectorMutex = Mutex()
    private var detector: StillFaceDetector? = null

    private val sourceFile: File get() = File(appContext.filesDir, "source_face.jpg")
    private val candidateFile: File get() = File(appContext.cacheDir, "candidate_face.jpg")

    init {
        // Recupera a última fotografia confirmada (se existir).
        viewModelScope.launch(Dispatchers.IO) {
            if (sourceFile.exists()) {
                try {
                    val photo = analyzePhoto(sourceFile, "Fotografia guardada")
                    _source.value = photo
                    engine.setSource(photo)
                } catch (_: Exception) {
                    // Ficheiro inválido: o utilizador escolhe outra fotografia.
                }
            }
        }
    }

    // ---------------- Fotografia de origem ----------------

    fun stagePhoto(uri: Uri) {
        _candidate.value = Candidate.Loading
        viewModelScope.launch(Dispatchers.IO) {
            try {
                copyUriTo(uri, candidateFile)
                val photo = analyzePhoto(candidateFile, "Fotografia selecionada")
                _candidate.value = Candidate.Ready(photo)
            } catch (_: NoFaceException) {
                _candidate.value = Candidate.Failed(
                    "Não encontrámos nenhum rosto nesta fotografia. Escolhe uma imagem frontal, com boa luz e uma só pessoa.",
                )
            } catch (e: Exception) {
                _candidate.value = Candidate.Failed("Não foi possível usar esta imagem: ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    fun confirmCandidate() {
        val ready = _candidate.value as? Candidate.Ready ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                candidateFile.copyTo(sourceFile, overwrite = true)
                _source.value = ready.photo.copyWithLabel("Fotografia confirmada")
                engine.setSource(_source.value)
                _candidate.value = Candidate.None
                _message.value = "Fotografia confirmada."
            } catch (e: Exception) {
                _message.value = "Não foi possível guardar a fotografia: ${e.message}"
            }
        }
    }

    fun cancelCandidate() {
        _candidate.value = Candidate.None
    }

    private suspend fun analyzePhoto(file: File, label: String): SourcePhoto = withContext(Dispatchers.IO) {
        val bitmap: Bitmap = Images.decodeOriented(file, MAX_SOURCE_SIDE)
        val landmarks = detectFace(bitmap) ?: throw NoFaceException()
        val triangles = Delaunay.triangulateLandmarks(landmarks, bitmap.width, bitmap.height)
        SourcePhoto(bitmap, landmarks, triangles, label)
    }

    private suspend fun detectFace(bitmap: Bitmap): FloatArray? = detectorMutex.withLock {
        val current = detector ?: StillFaceDetector.create(appContext).also { detector = it }
        current.detect(bitmap)
    }

    private fun copyUriTo(uri: Uri, target: File) {
        val input = appContext.contentResolver.openInputStream(uri)
            ?: throw IOException("Sem acesso à imagem selecionada")
        input.use { source -> target.outputStream().use { source.copyTo(it) } }
    }

    // ---------------- Câmara e pré-visualização ----------------

    fun startCamera(owner: LifecycleOwner) {
        val s = settings.value
        engine.configure(s.acceleration, s.mirror)
        if (!appContext.hasCameraPermission()) return
        engine.bind(owner, s.quality, s.lens) { error -> _message.value = error }
    }

    fun stopCamera() {
        engine.unbind()
    }

    fun setSwapOn(on: Boolean) {
        _swapOn.value = on
        engine.setSwapEnabled(on)
    }

    fun captureSnapshot() {
        engine.renderer.requestSnapshot { bitmap ->
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    _snapshot.value = SnapshotSaver.save(appContext, bitmap)
                } catch (e: Exception) {
                    _message.value = "Não foi possível guardar: ${e.message}"
                }
            }
        }
    }

    fun consumeSnapshot() {
        _snapshot.value = null
    }

    fun consumeMessage() {
        _message.value = null
    }

    fun showMessage(text: String) {
        _message.value = text
    }

    // ---------------- Definições ----------------

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        settingsStore.update(transform)
    }

    // ---------------- Compatibilidade ----------------

    fun runCompatibilityChecks() {
        if (_compatRunning.value) return
        viewModelScope.launch(Dispatchers.IO) {
            _compatRunning.value = true
            val results = mutableListOf<CheckResult>()
            try {
                results += checkGl()
                results += checkCameras()
                results += checkHardware()
                results += checkModel()
                results += checkSourceFace()
                results += checkRenderer()
            } finally {
                _compatResults.value = results
                _compatRunning.value = false
            }
        }
    }

    private fun checkGl(): CheckResult {
        val version = Compatibility.glEsVersion(appContext)
        return if (version >= 2f) {
            CheckResult("OpenGL ES", CheckStatus.PASS, "Versão ${"%.1f".format(version)} · requisito mínimo 2.0")
        } else {
            CheckResult("OpenGL ES", CheckStatus.FAIL, "Versão ${"%.1f".format(version)} · são necessárias 2.0 ou superior")
        }
    }

    private fun checkCameras(): List<CheckResult> {
        val (front, back) = Compatibility.cameraFacing(appContext)
        val permission = appContext.hasCameraPermission()
        return listOf(
            CheckResult(
                "Câmara frontal",
                if (front) CheckStatus.PASS else CheckStatus.FAIL,
                if (front) "Disponível" else "Não encontrada",
            ),
            CheckResult(
                "Câmara traseira",
                if (back) CheckStatus.PASS else CheckStatus.WARN,
                if (back) "Disponível" else "Não encontrada · usa apenas a frontal",
            ),
            CheckResult(
                "Permissão da câmara",
                if (permission) CheckStatus.PASS else CheckStatus.WARN,
                if (permission) "Concedida" else "Não concedida · concede em Definições",
            ),
        )
    }

    private fun checkHardware(): List<CheckResult> {
        val ram = Compatibility.totalRamGb(appContext)
        val cores = Runtime.getRuntime().availableProcessors()
        return listOf(
            CheckResult(
                "Memória",
                if (ram >= 3.0) CheckStatus.PASS else CheckStatus.WARN,
                "%.1f GB · recomendado 3 GB ou mais".format(ram),
            ),
            CheckResult(
                "Processador",
                if (cores >= 4) CheckStatus.PASS else CheckStatus.WARN,
                "$cores núcleos · recomendado 4 ou mais",
            ),
        )
    }

    private suspend fun checkModel(): CheckResult {
        val start = System.nanoTime()
        return try {
            detectorMutex.withLock {
                if (detector == null) detector = StillFaceDetector.create(appContext)
            }
            val ms = (System.nanoTime() - start) / 1_000_000
            CheckResult("Modelo MediaPipe", CheckStatus.PASS, "Carregado em $ms ms")
        } catch (e: Exception) {
            CheckResult("Modelo MediaPipe", CheckStatus.FAIL, "Erro ao carregar: ${e.message}")
        }
    }

    private suspend fun checkSourceFace(): CheckResult {
        val photo = _source.value
            ?: return CheckResult("Deteção na fotografia", CheckStatus.WARN, "Escolhe uma fotografia para testar")
        val found = runCatching { detectFace(photo.bitmap) != null }.getOrDefault(false)
        return if (found) {
            CheckResult("Deteção na fotografia", CheckStatus.PASS, "Rosto encontrado · 478 pontos")
        } else {
            CheckResult("Deteção na fotografia", CheckStatus.FAIL, "Rosto não detetado na fotografia atual")
        }
    }

    private fun checkRenderer(): CheckResult {
        val name = engine.renderer.glRendererName
        return if (name != "—") {
            CheckResult("Renderer GPU", CheckStatus.PASS, name)
        } else {
            CheckResult("Renderer GPU", CheckStatus.WARN, "Abre a pré-visualização e volta a executar os testes")
        }
    }

    override fun onCleared() {
        engine.shutdown()
        detector?.close()
        super.onCleared()
    }

    private companion object {
        const val MAX_SOURCE_SIDE = 1024
    }
}

/** Cópia do objeto com nova etiqueta (sem reprocessar a imagem). */
private fun SourcePhoto.copyWithLabel(newLabel: String): SourcePhoto =
    SourcePhoto(bitmap, landmarks, triangles, newLabel)
