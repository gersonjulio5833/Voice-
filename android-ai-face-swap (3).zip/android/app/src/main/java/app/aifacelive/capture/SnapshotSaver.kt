package app.aifacelive.capture

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Resultado de um snapshot: URI partilhável e local onde ficou guardado. */
data class SavedSnapshot(val shareUri: Uri, val location: String)

/**
 * Guarda um snapshot do ecrã com marca de simulação.
 * Android 10+: MediaStore (Imagens › AI Face Live), sem permissões de armazenamento.
 * Android 8–9: pasta privada da app (sem permissão de armazenamento).
 */
object SnapshotSaver {

    private const val QUALITY = 92

    fun save(context: Context, frame: Bitmap): SavedSnapshot {
        val stamped = stamp(frame)
        val name = "AIFaceLive_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"

        val shareDir = File(context.cacheDir, "shared").apply { mkdirs() }
        val shareFile = File(shareDir, name)
        FileOutputStream(shareFile).use { stamped.compress(Bitmap.CompressFormat.JPEG, QUALITY, it) }

        val location = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveToMediaStore(context, name, stamped)
        } else {
            saveToAppPictures(context, name, stamped)
        }
        stamped.recycle()

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", shareFile)
        return SavedSnapshot(uri, location)
    }

    /** Abre o seletor do Android para enviar a imagem a qualquer app (WhatsApp, Messenger, etc.). */
    fun shareChooser(uri: Uri): Intent {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("snapshot", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(send, "Partilhar snapshot (simulação)")
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun saveToMediaStore(context: Context, name: String, bitmap: Bitmap): String {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Face Live")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Não foi possível criar o ficheiro na galeria")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("Sem acesso de escrita à galeria")
            out.use { bitmap.compress(Bitmap.CompressFormat.JPEG, QUALITY, it) }
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return "Galeria › Imagens › AI Face Live"
    }

    private fun saveToAppPictures(context: Context, name: String, bitmap: Bitmap): String {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
        dir.mkdirs()
        FileOutputStream(File(dir, name)).use { bitmap.compress(Bitmap.CompressFormat.JPEG, QUALITY, it) }
        return "Android/data/${context.packageName}/files/Pictures"
    }

    /** Marca de água obrigatória: identifica a imagem como simulação. */
    private fun stamp(source: Bitmap): Bitmap {
        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val text = "AI Face Live · SIMULAÇÃO"
        val textSize = out.height * 0.032f
        val pad = textSize * 0.6f
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.textSize = textSize
            color = Color.WHITE
            typeface = Typeface.DEFAULT_BOLD
        }
        val left = out.width * 0.04f
        val bottom = out.height * 0.97f
        val top = bottom - textSize - pad
        val boxRight = left + textPaint.measureText(text) + pad * 2
        val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(180, 6, 4, 14) }
        canvas.drawRoundRect(RectF(left, top, boxRight, bottom), pad, pad, boxPaint)
        canvas.drawText(text, left + pad, bottom - pad * 0.55f, textPaint)
        return out
    }
}
