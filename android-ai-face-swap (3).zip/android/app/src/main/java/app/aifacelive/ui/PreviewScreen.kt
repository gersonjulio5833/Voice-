package app.aifacelive.ui

import android.content.Intent
import android.opengl.GLSurfaceView
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.aifacelive.AppViewModel
import app.aifacelive.capture.SnapshotSaver
import app.aifacelive.settings.Acceleration
import app.aifacelive.util.openAppSettings

@Composable
fun PreviewScreen(
    vm: AppViewModel,
    onBack: () -> Unit,
    onChangePhoto: () -> Unit,
) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val stats by vm.stats.collectAsStateWithLifecycle()
    val source by vm.source.collectAsStateWithLifecycle()
    val swapOn by vm.swapOn.collectAsStateWithLifecycle()
    val snapshot by vm.lastSnapshot.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val camera = rememberCameraPermission()

    // Superfície GL: o renderer desenha câmara + rosto deformado.
    val glView = remember(vm) {
        GLSurfaceView(context).apply {
            setEGLContextClientVersion(2)
            setRenderer(vm.engine.renderer)
            renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        }
    }

    DisposableEffect(owner, glView) {
        val renderer = vm.engine.renderer
        renderer.onNeedsRender = { glView.requestRender() }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> glView.onResume()
                Lifecycle.Event.ON_PAUSE -> glView.onPause()
                else -> Unit
            }
        }
        // addObserver sincroniza automaticamente com o estado atual (ex.: já RESUMED).
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            renderer.onNeedsRender = null
            glView.onPause()
        }
    }

    LaunchedEffect(camera.granted, settings.quality, settings.lens, settings.acceleration, settings.mirror) {
        if (camera.granted) vm.startCamera(owner)
    }
    DisposableEffect(Unit) {
        onDispose { vm.stopCamera() }
    }

    LaunchedEffect(message) {
        message?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            vm.consumeMessage()
        }
    }
    LaunchedEffect(snapshot) {
        snapshot?.let {
            Toast.makeText(context, "Guardado em ${it.location}", Toast.LENGTH_LONG).show()
            context.startActivity(SnapshotSaver.shareChooser(it.shareUri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            vm.consumeSnapshot()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (camera.granted) {
            AndroidView(factory = { glView }, modifier = Modifier.fillMaxSize())
        } else {
            CameraPermissionPrompt(onRequest = camera.request, onSettings = { context.openAppSettings() })
        }

        // Gradientes para legibilidade
        Box(
            Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Brush.verticalGradient(listOf(Color(0xE606040E), Color.Transparent))),
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(300.dp)
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF506040E)))),
        )

        // Barra superior
        Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
            AppTopBar(
                title = "Pré-visualização",
                onBack = onBack,
                trailing = { SimulationBadge() },
            )
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                StatusChip(
                    text = if (stats.faceDetected) "Rosto detetado" else "Sem rosto",
                    color = if (stats.faceDetected) AiSuccess else AiWarning,
                )
                StatusChip(
                    text = "%.0f fps · %.0f ms".format(stats.fps, stats.latencyMs),
                    color = AiSecondary,
                )
                StatusChip(
                    text = if (stats.acceleration == Acceleration.GPU) "GPU" else "CPU",
                    color = AiTertiary,
                )
            }
            stats.error?.let { error ->
                Text(
                    error,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp),
                    color = Color(0xFFFFD6DD),
                    fontSize = 12.sp,
                )
            }
        }

        if (settings.showHud && camera.granted) {
            BlendshapeHud(
                values = stats.blendshapes,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 12.dp),
            )
        }

        // Painel inferior
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(16.dp),
        ) {
            if (source == null) {
                EmptyPhotoPanel(onChangePhoto = onChangePhoto)
            } else {
                ControlPanel(
                    label = source?.label ?: "",
                    swapOn = swapOn,
                    onSwapChange = vm::setSwapOn,
                    onChangePhoto = onChangePhoto,
                    onCapture = vm::captureSnapshot,
                    captureEnabled = camera.granted,
                )
            }
        }
    }
}

@Composable
private fun ControlPanel(
    label: String,
    swapOn: Boolean,
    onSwapChange: (Boolean) -> Unit,
    onChangePhoto: () -> Unit,
    onCapture: () -> Unit,
    captureEnabled: Boolean,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xE6120E22))
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (swapOn) "Face swap ativo" else "Face swap desligado",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                )
                Text(
                    if (swapOn) "A fotografia segue o teu rosto · $label" else "Mostra apenas a câmara original",
                    color = AiTextMuted,
                    fontSize = 11.sp,
                )
            }
            Switch(
                checked = swapOn,
                onCheckedChange = onSwapChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = AiPrimary,
                    uncheckedTrackColor = AiSurfaceVariant,
                ),
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GhostButton(text = "Alterar foto", onClick = onChangePhoto, modifier = Modifier.weight(1f))
            GradientButton(
                text = "Guardar",
                onClick = onCapture,
                modifier = Modifier.weight(1f),
                enabled = captureEnabled,
                icon = Icons.Filled.Save,
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Simulação · a imagem guardada tem marca de água",
            color = AiTextMuted,
            fontSize = 10.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun EmptyPhotoPanel(onChangePhoto: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xE6120E22))
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.Face, contentDescription = null, tint = AiTertiary, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(8.dp))
        Text("Ainda não há fotografia", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text("Escolhe uma foto para ativar o efeito.", color = AiTextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        GradientButton("Escolher foto", onClick = onChangePhoto, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun CameraPermissionPrompt(onRequest: () -> Unit, onSettings: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E1248), AiBackground)))
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Filled.CameraAlt, contentDescription = null, tint = AiSecondary, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(16.dp))
        Text("A câmara é necessária", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "A câmara é usada só para a pré-visualização, no próprio telemóvel. Nada é enviado para a internet.",
            color = AiTextMuted,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(24.dp))
        GradientButton("Conceder permissão", onClick = onRequest, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        GhostButton("Abrir definições da app", onClick = onSettings, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun BlendshapeHud(values: Map<String, Float>, modifier: Modifier = Modifier) {
    val rows = listOf(
        "Boca" to (values["jawOpen"] ?: 0f),
        "Olhos" to ((values["eyeBlinkLeft"] ?: 0f) + (values["eyeBlinkRight"] ?: 0f)) / 2f,
        "Sorriso" to ((values["mouthSmileLeft"] ?: 0f) + (values["mouthSmileRight"] ?: 0f)) / 2f,
        "Sobrancelhas" to (values["browInnerUp"] ?: 0f),
    )
    Column(
        modifier = modifier
            .width(122.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x99060410))
            .padding(10.dp),
    ) {
        Text("EXPRESSÕES", color = AiTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        rows.forEach { (label, value) ->
            val v = value.coerceIn(0f, 1f)
            Text("$label  ${(v * 100).toInt()}%", color = Color.White, fontSize = 10.sp)
            Spacer(Modifier.height(3.dp))
            LinearProgressIndicator(
                progress = { v },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = AiSecondary,
                trackColor = Color(0x22FFFFFF),
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}
